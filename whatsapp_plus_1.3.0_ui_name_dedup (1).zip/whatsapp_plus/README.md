# Whatsapp Plus (Perfex CRM Module)
- Author: Iteally
- Version: 1.0.2
- Date: 2025-08-20

Includes:
- v23.0 Graph API
- Robust webhook (supports both entry/changes and field/value sample)
- Debug log at `modules/whatsapp_plus/storage/webhook.log`
- Inbox view (threads + conversation)
- CSRF-safe forms
