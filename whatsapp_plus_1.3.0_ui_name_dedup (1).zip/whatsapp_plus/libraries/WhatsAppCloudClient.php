<?php
defined('BASEPATH') or exit('No direct script access allowed');

class WhatsAppCloudClient
{
    private $accessToken;
    private $phoneNumberId;
    private $graphVersion;

    public function __construct($accessToken = null, $phoneNumberId = null, $graphVersion = null)
    {
        $CI = &get_instance();
        // Helper'e bağımlılığı kaldır: Perfex option API'sini doğrudan kullan
        $this->accessToken   = $accessToken   !== null ? $accessToken   : (function_exists('get_option') ? get_option('wp_access_token')    : '');
        $this->phoneNumberId = $phoneNumberId !== null ? $phoneNumberId : (function_exists('get_option') ? get_option('wp_phone_number_id') : '');
        $this->graphVersion  = $graphVersion  !== null ? $graphVersion  : ($CI->config->item('wp_graph_api_version') ?: 'v20.0');
    }

    private function endpoint($path)
    {
        return "https://graph.facebook.com/{$this->graphVersion}/{$this->phoneNumberId}/{$path}";
    }

    private function request($method, $url, $payload = null)
    {
        $ch = curl_init($url);
        $headers = ['Authorization: Bearer ' . $this->accessToken, 'Content-Type: application/json'];
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        if ($payload !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        }
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        return [$code, $res, $err];
    }

    public function sendText($to, $text)
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to'   => $to,
            'type' => 'text',
            'text' => ['preview_url' => true, 'body' => $text],
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }
}
