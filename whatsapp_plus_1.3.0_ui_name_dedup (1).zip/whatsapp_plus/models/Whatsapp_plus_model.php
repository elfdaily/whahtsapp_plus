<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Whatsapp_plus_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
        if (function_exists('whatsapp_plus_install')) {
            whatsapp_plus_install();
        }
    }

    /** Tek kayıt ekle (gelen/giden) */
    public function log_message($data)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            whatsapp_plus_install();
        }
        if (!isset($data['account_id']) || $data['account_id'] === null) {
            $data['account_id'] = 0;
        }
        if (isset($data['phone'])) {
            $data['phone_e164'] = function_exists('wp_normalize_phone') ? wp_normalize_phone($data['phone']) : $data['phone'];
        }
        $this->db->insert(db_prefix() . 'whatsapp_plus_messages', $data);
        $ins_id = $this->db->insert_id();
        if (!empty($data['phone_e164'])) {
            $this->upsert_contact($data['phone_e164'], isset($data['contact_name']) ? $data['contact_name'] : null);
        }
        return $ins_id;
    }

    /** Kişi adını güncelle/ekle */
    public function upsert_contact($phone_e164, $name = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_contacts')) {
            return;
        }
        $now = date('Y-m-d H:i:s');
        $row = $this->db->where('phone_e164', $phone_e164)->get(db_prefix() . 'whatsapp_plus_contacts')->row_array();
        if ($row) {
            $upd = ['updated_at' => $now];
            if ($name && (empty($row['name']) || $row['name'] !== $name)) {
                $upd['name'] = $name;
            }
            if (!empty($upd)) {
                $this->db->where('id', $row['id'])->update(db_prefix() . 'whatsapp_plus_contacts', $upd);
            }
        } else {
            $this->db->insert(db_prefix() . 'whatsapp_plus_contacts', [
                'phone_e164' => $phone_e164,
                'name'       => $name,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }

    /** Son konuşma listesi (normalize edilerek tekilleştirilmiş) */
    public function list_threads($limit = 200)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            return [];
        }
        $tbl = db_prefix() . 'whatsapp_plus_messages';
        $ct  = db_prefix() . 'whatsapp_plus_contacts';

        // Son N mesajı çek, PHP tarafında normalize ederek tekilleştir
        $N = max($limit * 5, 500);
        $this->db->order_by('id', 'DESC');
        $this->db->limit($N);
        $rows = $this->db->get($tbl)->result_array();

        $map = [];
        foreach ($rows as $r) {
            $key = !empty($r['phone_e164']) ? $r['phone_e164'] : (function_exists('wp_normalize_phone') ? wp_normalize_phone($r['phone']) : $r['phone']);
            if (!isset($map[$key]) || $r['id'] > $map[$key]['id']) {
                $map[$key] = $r;
                $map[$key]['phone_e164'] = $key;
            }
        }
        // id'ye göre sırala (desc)
        uasort($map, function($a,$b){ return ($a['id'] < $b['id']) ? 1 : -1; });
        $threads = array_slice(array_values($map), 0, $limit);

        // İsimleri iliştir
        if ($this->db->table_exists($ct)) {
            $phones = array_map(function($x){ return $x['phone_e164']; }, $threads);
            if (!empty($phones)) {
                $this->db->where_in('phone_e164', $phones);
                $crows = $this->db->get($ct)->result_array();
                $cmap = [];
                foreach ($crows as $c) { $cmap[$c['phone_e164']] = $c['name']; }
                foreach ($threads as &$t) {
                    if (isset($cmap[$t['phone_e164']])) $t['contact_name'] = $cmap[$t['phone_e164']];
                }
            }
        }
        return $threads;
    }

    /** Bir numaranın tüm konuşması (kronolojik) */
    public function get_conversation($phone, $limit = 200)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            return [];
        }
        $pkey = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone;
        $this->db->group_start();
        $this->db->where('phone_e164', $pkey);
        $this->db->or_where('phone', $pkey);
        $this->db->group_end();
        $this->db->order_by('id', 'DESC');
        $this->db->limit($limit);
        $rows = $this->db->get(db_prefix() . 'whatsapp_plus_messages')->result_array();
        return array_reverse($rows);
    }

    /** Basit log satırı ekle (DB) */
    public function log_line($source, $tag, $text, $meta = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            whatsapp_plus_install();
        }
        $data = [
            'source'    => $source,
            'tag'       => $tag,
            'text'      => $text,
            'meta_json' => is_string($meta) ? $meta : json_encode($meta),
            'created_at'=> date('Y-m-d H:i:s'),
        ];
        $this->db->insert(db_prefix() . 'whatsapp_plus_logs', $data);
        return $this->db->insert_id();
    }

    /** Son X log satırı (en yeni önce) */
    public function list_logs($limit = 1000)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            return [];
        }
        $this->db->order_by('id', 'DESC');
        $this->db->limit((int)$limit);
        return $this->db->get(db_prefix() . 'whatsapp_plus_logs')->result_array();
    }

    /** Logları temizle */
    public function clear_logs()
    {
        if ($this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            $this->db->truncate(db_prefix() . 'whatsapp_plus_logs');
        }
    }
}
