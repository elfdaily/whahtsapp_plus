<?php
defined('BASEPATH') or exit('No direct script access allowed');
/* Menü öğeleri whatsapp_plus.php içinde kaydediliyor */
