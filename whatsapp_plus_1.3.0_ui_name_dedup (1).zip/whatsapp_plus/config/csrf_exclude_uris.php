<?php
defined('BASEPATH') or exit('No direct script access allowed');
$config['csrf_exclude_uris'] = ['whatsapp_plus/webhook'];
