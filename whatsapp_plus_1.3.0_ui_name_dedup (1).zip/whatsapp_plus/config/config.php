<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['module_name']    = 'whatsapp_plus';
$config['module_version'] = '1.0.1';
$config['wp_graph_api_version'] = 'v23.0';
