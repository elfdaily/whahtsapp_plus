<?php
defined('BASEPATH') or exit('No direct script access allowed');
$routes->add('whatsapp_plus/webhook', 'whatsapp_plus/webhook/index');
$routes->add('whatsapp_plus/poll', 'whatsapp_plus/whatsapp_plus/poll');
$routes->add('whatsapp_plus/typing', 'whatsapp_plus/whatsapp_plus/typing');
