<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Webhook extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->database();
    }

    public function index(){
        if ($this->input->server('REQUEST_METHOD') === 'GET') {
            $mode      = $this->input->get('hub_mode');
            $token     = $this->input->get('hub_verify_token');
            $challenge = $this->input->get('hub_challenge');
            if ($mode === 'subscribe' && $token === get_option('wp_verify_token')) {
                header('Content-Type: text/plain'); echo $challenge; return;
            }
            show_404();
        }

        // POST
        $raw  = file_get_contents('php://input');
        $json = json_decode($raw, true);
        $inserted = 0;

        if (isset($json['entry'])) {
            foreach ($json['entry'] as $entry) {
                foreach (($entry['changes'] ?? []) as $change) {
                    $value = $change['value'] ?? [];
                    // Gelen mesajlar
                    $contactName = null; if (!empty($value['contacts'][0]['profile']['name'])) { $contactName = $value['contacts'][0]['profile']['name']; }
                    foreach (($value['messages'] ?? []) as $msg) {
                        if (($msg['type'] ?? '') === 'text') {
                            $from = $msg['from'] ?? '';
                            $body = $msg['text']['body'] ?? '';
                            $this->whatsapp_plus_model->log_line('webhook','MESSAGE_IN','insert', ['from'=>$from]);
                            $this->whatsapp_plus_model->log_message([
                                'account_id'    => 0,
                                'direction'     => 'in',
                                'phone'         => $from,
                                'type'          => 'text',
                                'body'          => $body,
                                'status'        => 'received',
                                'wa_message_id' => $msg['id'] ?? null,
                                'created_at'    => date('Y-m-d H:i:s'),
                            ]);
                            $inserted++;
                        }
                    }
                    // Durum güncellemeleri
                    foreach (($value['statuses'] ?? []) as $st) {
                        $id   = $st['id'] ?? null;
                        $stat = $st['status'] ?? '';
                        if ($id) {
                            $this->db->where('wa_message_id', $id);
                            $update = ['status' => $stat];
                            if ($stat === 'delivered') $update['delivered_at'] = date('Y-m-d H:i:s');
                            if ($stat === 'read')      $update['read_at']      = date('Y-m-d H:i:s');
                            $this->db->update(db_prefix().'whatsapp_plus_messages', $update);
                            $this->whatsapp_plus_model->log_line('webhook','STATUS','update', ['wa_message_id'=>$id,'status'=>$stat]);
                        }
                    }
                }
            }
        }

        $this->wp_debug(['inserted'=>$inserted, 'raw'=>$json]);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status'=>'ok','inserted'=>$inserted]);
    }

    private function wp_debug($data){
        $dir = __DIR__ . '/../storage';
        if(!is_dir($dir)) @mkdir($dir, 0775, true);
        $file = $dir . '/webhook.log';
        @file_put_contents($file, '['.date('c').'] '.(is_string($data)?$data:json_encode($data)).PHP_EOL, FILE_APPEND);
        $this->whatsapp_plus_model->log_line('webhook', 'DEBUG', 'webhook event', is_string($data)?$data:json_encode($data));
    }
}
