<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Tools extends AdminController
{
    const LOG_MAX_BYTES = 1048576; // 1 MB

    public function __construct()
    {
        parent::__construct();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->database();
    }

    private function log_path()
    {
        $dir = __DIR__ . '/../storage';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        return $dir . '/webhook.log';
    }

    private function log_write($line)
    {
        $file = $this->log_path();
        if (@file_exists($file) && @filesize($file) > self::LOG_MAX_BYTES) {
            @rename($file, $file . '.1');
            @file_put_contents($file, '[' . date('c') . "] [ROTATE] eski log .1'e taşındı\n");
        }
        @file_put_contents($file, '[' . date('Y-m-d H:i:sP') . '] ' . $line . PHP_EOL, FILE_APPEND);
    }

    private function db_log($tag, $text, $meta = null, $source = 'tools')
    {
        // Güvenlik: meta JSON'a dönsün
        $this->whatsapp_plus_model->log_line($source, $tag, $text, $meta);
    }

    /** Yardımcı: son wa_message_id (outbound öncelikli). Yoksa auto-seed oluşturur. */
    private function get_or_seed_last_wa_id()
    {
        $tbl = db_prefix() . 'whatsapp_plus_messages';
        $row = $this->db->select('wa_message_id')
                        ->where('wa_message_id IS NOT NULL', null, false)
                        ->where('direction', 'out')
                        ->order_by('id', 'DESC')->limit(1)
                        ->get($tbl)->row_array();
        if (!$row) {
            $row = $this->db->select('wa_message_id')
                            ->where('wa_message_id IS NOT NULL', null, false)
                            ->order_by('id', 'DESC')->limit(1)
                            ->get($tbl)->row_array();
        }
        $waid = $row['wa_message_id'] ?? null;
        if (!$waid) {
            $waid = 'wamid.TEST' . time();
            $this->db->insert($tbl, [
                'account_id'    => 0,
                'direction'     => 'out',
                'phone'         => '+900000000000',
                'type'          => 'text',
                'body'          => 'outbound seed for status tests',
                'status'        => 'sent',
                'wa_message_id' => $waid,
                'created_at'    => date('Y-m-d H:i:s'),
                'sent_at'       => date('Y-m-d H:i:s'),
            ]);
            $this->log_write('[SEED] outbound message inserted for status tests — wa_id=' . $waid);
            $this->db_log('SEED', 'outbound message inserted for status tests', ['wa_id'=>$waid]);
        }
        return $waid;
    }

    /** PING */
    public function ping()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $this->log_write('ping');
        $this->db_log('PING', 'ping');
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true]);
    }

    /** SEED: DB'ye örnek inbound mesaj ekler */
    public function seed()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $phone = $this->input->get('phone') ?: '+900000000000';
        $body  = $this->input->get('body') ?: 'Seed message';
        $this->whatsapp_plus_model->log_message([
            'account_id'    => 0,
            'direction'     => 'in',
            'phone'         => $phone,
            'type'          => 'text',
            'body'          => $body,
            'status'        => 'received',
            'wa_message_id' => 'seed-' . time(),
            'meta_json'     => null,
            'created_at'    => date('Y-m-d H:i:s'),
            'received_at'   => date('Y-m-d H:i:s'),
        ]);
        $this->log_write('seed->' . $phone);
        $this->db_log('SEED', 'seed->'.$phone, ['phone'=>$phone]);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => true]);
    }

    /** Test payload (field/value) */
    public function post_fv()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $payload = [
            'field' => 'messages',
            'value' => [
                'messages' => [[
                    'id'        => 'wamid.HBG' . time(),
                    'from'      => '905551112233',
                    'timestamp' => (string) time(),
                    'type'      => 'text',
                    'text'      => ['body' => 'fv test ' . date('H:i:s')],
                ]],
            ],
        ];
        $this->log_write('[INFO] POST(FV) tetiklendi — tools URL: ' . current_url());
        $this->db_log('INFO', 'POST(FV) tetiklendi', ['tools_url'=>current_url()]);
        $this->log_write('[INFO] Webhook URL: ' . site_url('whatsapp_plus/webhook'));
        $this->db_log('INFO', 'Webhook URL', ['url'=>site_url('whatsapp_plus/webhook')]);
        $this->log_write('[PAYLOAD] ' . json_encode($payload));
        $this->db_log('PAYLOAD', 'FV payload', $payload);

        $url = site_url('whatsapp_plus/webhook');
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['entry' => [['changes' => [$payload]]]]));
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        $inserted = @json_decode($res,true)['inserted'] ?? null;
        $this->log_write('[RESP] HTTP ' . $code . ' — inserted=' . ($inserted ?? 'null') . ', err=' . ($err ?: ''));
        $this->db_log('RESP', 'HTTP response', ['code'=>$code,'inserted'=>$inserted,'err'=>$err]);
        $this->log_write('[RESP-BODY] ' . $res);
        $this->db_log('RESP-BODY', 'body', $res);

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $code===200, 'code'=>$code, 'err'=>$err, 'res'=>$res]);
    }

    /** Tam WA payload (object: whatsapp_business_account) */
    public function post_wa()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $payload = [
            'object' => 'whatsapp_business_account',
            'entry' => [[
                'changes' => [[
                    'field' => 'messages',
                    'value' => [
                        'messaging_product' => 'whatsapp',
                        'metadata' => [
                            'display_phone_number' => '16505551111',
                            'phone_number_id'      => '123456123',
                        ],
                        'contacts' => [[
                            'profile' => ['name' => 'Test User'],
                            'wa_id'   => '905551112233',
                        ]],
                        'messages' => [[
                            'from'      => '905551112233',
                            'id'        => 'wamid.ABG' . time(),
                            'timestamp' => (string) time(),
                            'type'      => 'text',
                            'text'      => ['body' => 'wa entry test ' . date('H:i:s')],
                        ]],
                    ],
                ]],
            ]],
        ];
        $this->log_write('[INFO] POST(WA/entry) tetiklendi — tools URL: ' . current_url());
        $this->db_log('INFO', 'POST(WA/entry) tetiklendi', ['tools_url'=>current_url()]);
        $this->log_write('[INFO] Webhook URL: ' . site_url('whatsapp_plus/webhook'));
        $this->db_log('INFO', 'Webhook URL', ['url'=>site_url('whatsapp_plus/webhook')]);
        $this->log_write('[PAYLOAD] ' . json_encode($payload));
        $this->db_log('PAYLOAD', 'WA payload', $payload);

        $url = site_url('whatsapp_plus/webhook');
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        $inserted = @json_decode($res,true)['inserted'] ?? null;
        $this->log_write('[RESP] HTTP ' . $code . ' — inserted=' . ($inserted ?? 'null') . ', err=' . ($err ?: ''));
        $this->db_log('RESP', 'HTTP response', ['code'=>$code,'inserted'=>$inserted,'err'=>$err]);
        $this->log_write('[RESP-BODY] ' . $res);
        $this->db_log('RESP-BODY', 'body', $res);

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $code===200, 'code'=>$code, 'err'=>$err, 'res'=>$res]);
    }

    /** STATUS delivered: */
    public function status_delivered()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $waid = $this->get_or_seed_last_wa_id();
        $payload = [
            'object' => 'whatsapp_business_account',
            'entry'  => [[
                'changes' => [[
                    'field' => 'messages',
                    'value' => [
                        'statuses' => [[
                            'id'        => $waid,
                            'status'    => 'delivered',
                            'timestamp' => (string) time(),
                        ]],
                    ],
                ]],
            ]],
        ];
        $this->log_write('[INFO] STATUS(delivered) — wa_id=' . $waid);
        $this->db_log('STATUS', 'delivered', ['wa_id'=>$waid]);
        $url = site_url('whatsapp_plus/webhook');
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        $this->log_write('[RESP] HTTP ' . $code . ' (status delivered) err=' . ($err ?: ''));
        $this->db_log('RESP', 'status delivered', ['code'=>$code,'err'=>$err]);
        $this->log_write('[RESP-BODY] ' . $res);
        $this->db_log('RESP-BODY', 'body', $res);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>$code===200,'wa_id'=>$waid]);
    }

    /** STATUS read: */
    public function status_read()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $waid = $this->get_or_seed_last_wa_id();
        $payload = [
            'object' => 'whatsapp_business_account',
            'entry'  => [[
                'changes' => [[
                    'field' => 'messages',
                    'value' => [
                        'statuses' => [[
                            'id'        => $waid,
                            'status'    => 'read',
                            'timestamp' => (string) time(),
                        ]],
                    ],
                ]],
            ]],
        ];
        $this->log_write('[INFO] STATUS(read) — wa_id=' . $waid);
        $this->db_log('STATUS', 'read', ['wa_id'=>$waid]);
        $url = site_url('whatsapp_plus/webhook');
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        $this->log_write('[RESP] HTTP ' . $code . ' (status read) err=' . ($err ?: ''));
        $this->db_log('RESP', 'status read', ['code'=>$code,'err'=>$err]);
        $this->log_write('[RESP-BODY] ' . $res);
        $this->db_log('RESP-BODY', 'body', $res);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>$code===200,'wa_id'=>$waid]);
    }

    /** Log içeriğini döndür (AJAX) – DB'den okur */
    public function get_log()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        $rows = $this->whatsapp_plus_model->list_logs(1000);
        $buf = '';
        foreach (array_reverse($rows) as $r) {
            $ts  = $r['created_at'];
            $tag = $r['tag'];
            $txt = $r['text'];
            $buf .= '['.$ts.'] '.($tag ? '['.$tag.'] ' : '').$txt."\n";
        }
        header('Content-Type: text/plain; charset=utf-8');
        echo $buf;
    }

    /** Log temizle (AJAX) */
    public function clear()
    {
        if (!is_staff_logged_in()) show_error('Forbidden', 403);
        @file_put_contents($this->log_path(), '');
        $this->whatsapp_plus_model->clear_logs();
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>true]);
    }
}
