<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Whatsapp_plus extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->helper('whatsapp_plus/whatsapp_plus');
        $this->load->library('whatsapp_plus/WhatsAppCloudClient');
    }

    public function index()
    {
        return $this->messages();
    }

    public function messages()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) {
            access_denied('whatsapp_plus');
        }
        $data['title']   = _l('whatsapp_plus_messages');
        $data['threads'] = $this->whatsapp_plus_model->list_threads(400);

        $active = $this->input->get('phone');
        $data['active_phone'] = $active;
        $norm = $active ? (function_exists('wp_normalize_phone') ? wp_normalize_phone($active) : $active) : null;
        $data['conversation'] = $norm ? $this->whatsapp_plus_model->get_conversation($norm, 400) : [];

        // aktif kişi adı
        $data['active_contact_name'] = $active;
        if ($norm && !empty($data['threads'])) {
            foreach ($data['threads'] as $t) {
                $pkey = !empty($t['phone_e164']) ? $t['phone_e164'] : $t['phone'];
                if ($pkey === $norm) {
                    $data['active_contact_name'] = !empty($t['contact_name']) ? $t['contact_name'] : $pkey;
                    break;
                }
            }
        }

        $this->load->view('whatsapp_plus/messages', $data);
    }

    /** AJAX: sohbeti yenile */
    public function poll()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) {
            wp_json_response(['success' => false, 'message' => 'forbidden'], 403);
        }
        $phone = $this->input->get('phone');
        $phone = $phone ? (function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone) : null;
        $rows  = $phone ? $this->whatsapp_plus_model->get_conversation($phone, 400) : [];
        wp_json_response(['success' => true, 'messages' => $rows]);
    }

    /** AJAX: yazıyor bilgisi (UI simülasyon) */
    public function typing()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) {
            wp_json_response(['success' => false], 403);
        }
        wp_json_response(['success' => true]);
    }

    /** POST: mesaj gönder */
    public function send()
    {
        if (!has_permission('whatsapp_plus', '', 'create')) {
            access_denied('whatsapp_plus');
        }
        $to   = $this->input->post('to');
        $text = $this->input->post('text');
        if (!$to || !$text) {
            wp_json_response(['success' => false, 'message' => 'Missing parameters'], 422);
        }
        list($code, $res, $err) = $this->whatsappcloudclient->sendText($to, $text);
        $status = ($code === 200 ? 'sent' : 'error');
        $wa_id = null;
        $decoded = json_decode($res, true);
        if (is_array($decoded) && isset($decoded['messages'][0]['id'])) {
            $wa_id = $decoded['messages'][0]['id'];
        }
        $this->whatsapp_plus_model->log_message([
            'account_id'    => 0,
            'direction'     => 'out',
            'phone'         => $to,
            'type'          => 'text',
            'body'          => $text,
            'status'        => $status,
            'wa_message_id' => $wa_id,
            'error'         => $err ?: ($code !== 200 ? $res : null),
            'created_at'    => date('Y-m-d H:i:s'),
            'sent_at'       => ($code === 200 ? date('Y-m-d H:i:s') : null),
        ]);
        if ($this->input->is_ajax_request()) {
            wp_json_response(['success' => $code === 200, 'code' => $code, 'response' => json_decode($res, true), 'error' => $err]);
        } else {
            if ($code === 200) {
                set_alert('success', _l('whatsapp_plus_sent_ok'));
            } else {
                set_alert('danger', _l('whatsapp_plus_sent_fail') . ' ' . $res);
            }
            redirect(admin_url('whatsapp_plus?phone=' . rawurlencode($to)));
        }
    }

    /** Ayarlar (GET/POST) */
    public function settings()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) {
            access_denied('whatsapp_plus');
        }
        if ($this->input->method(true) === 'POST') {
            if (!has_permission('whatsapp_plus', '', 'edit')) {
                access_denied('whatsapp_plus');
            }
            update_option('wp_access_token', $this->input->post('wp_access_token', false));
            update_option('wp_waba_id', $this->input->post('wp_waba_id', false));
            update_option('wp_phone_number_id', $this->input->post('wp_phone_number_id', false));
            update_option('wp_verify_token', $this->input->post('wp_verify_token', false));
            set_alert('success', _l('updated_successfully'));
            redirect(admin_url('whatsapp_plus/settings'));
        }
        $data = [
            'title'              => _l('settings'),
            'wp_access_token'    => get_option('wp_access_token'),
            'wp_waba_id'         => get_option('wp_waba_id'),
            'wp_phone_number_id' => get_option('wp_phone_number_id'),
            'wp_verify_token'    => get_option('wp_verify_token'),
        ];
        $this->load->view('whatsapp_plus/settings', $data);
    }

    /** Log ve sağlık kontrolü */
    public function logs()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) {
            access_denied('whatsapp_plus');
        }
        $data['title'] = _l('logs');
        $file = __DIR__ . '/../storage/webhook.log';
        $data['log_text'] = @is_file($file) ? @file_get_contents($file) : 'Log bulunamadı.';
        $this->load->view('whatsapp_plus/log', $data);
    }
}
