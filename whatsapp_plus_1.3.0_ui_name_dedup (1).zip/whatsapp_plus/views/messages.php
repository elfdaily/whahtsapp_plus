<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
  /* WhatsApp Web benzeri basit tema */
  .wa-wrap{height:calc(100vh - 160px);display:flex;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;background:#fff}
  .wa-left{width:32%;min-width:280px;border-right:1px solid #e5e7eb;background:#f8fafc;display:flex;flex-direction:column}
  .wa-left .wa-head{padding:12px 14px;font-weight:600;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;gap:8px}
  .wa-left .wa-list{overflow:auto}
  .wa-chat{flex:1;display:flex;flex-direction:column;background:#e5ddd5}
  .wa-chat .wa-top{background:#f0f2f5;border-bottom:1px solid #e5e7eb;padding:10px 14px;display:flex;align-items:center;gap:10px}
  .wa-chat .wa-top .wa-title{font-weight:600}
  .wa-chat .wa-body{flex:1;overflow:auto;padding:18px;background:#efeae2; background-image: radial-gradient(rgba(0,0,0,0.03) 1px, transparent 0), radial-gradient(rgba(0,0,0,0.03) 1px, transparent 0); background-position: 0 0, 12px 12px; background-size: 24px 24px  ;}
  .wa-msg{margin:6px 0;display:flex}
  .wa-msg .bubble{max-width:70%;padding:8px 10px;border-radius:8px;position:relative;background:#fff}
  .wa-msg.out{justify-content:flex-end}
  .wa-msg.out .bubble{background:#d9fdd3}
  .wa-meta{font-size:11px;opacity:.7;margin-left:6px;display:inline-flex;align-items:center;gap:6px}
  .wa-checks{font-family:Arial; font-size:13px}
  .wa-input{background:#f0f2f5;border-top:1px solid #e5e7eb;padding:10px}
  .wa-input form{display:flex;gap:8px}
  .wa-input textarea{height:44px;resize:none}
  .wa-thread{display:flex;gap:10px;align-items:center;padding:10px 12px;border-bottom:1px solid #eef2f7;cursor:pointer}
  .wa-thread:hover{background:#eef2f7}
  .wa-thread.active{background:#e7f3ff}
  .wa-thread .t-phone{font-weight:600}
  .wa-thread .t-time{margin-left:auto;font-size:12px;opacity:.6}
  .wa-empty{display:flex;align-items:center;justify-content:center;color:#777;flex:1}
  .wa-typing{font-size:12px;opacity:.75;margin-left:6px}
</style>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="wa-wrap">
          <div class="wa-left">
            <div class="wa-head">
              <i class="fa fa-whatsapp"></i> <?php echo _l('whatsapp_plus_messages'); ?>
            </div>
            <div class="wa-list">
              <?php if (empty($threads)): ?>
                <div class="p-3 text-muted"><?php echo _l('whatsapp_plus_no_threads'); ?></div>
              <?php else: ?>
                <?php foreach($threads as $t): $t_phone = $t['phone_e164'] ?? $t['phone']; $t_name = !empty($t['contact_name']) ? $t['contact_name'] : $t_phone; ?>
                  <?php $isActive = ($active_phone && $active_phone == $t['phone']); ?>
                  <a class="wa-thread <?php echo $isActive ? 'active' : ''; ?>" href="<?php echo admin_url('whatsapp_plus?phone='.rawurlencode($t['phone'])); ?>">
                    <i class="fa fa-phone"></i>
                    <span class="t-phone"><?php echo html_escape($t_name); ?></span>
                    <span class="t-time"><?php echo _dt($t['created_at']); ?></span>
                  </a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="wa-chat">
            <?php if (empty($active_phone)): ?>
              <div class="wa-empty"><?php echo _l('whatsapp_plus_no_thread_selected'); ?></div>
            <?php else: ?>
              <div class="wa-top">
                <i class="fa fa-phone"></i>
                <div class="wa-title"><?php echo html_escape($active_contact_name); ?></div>
                <div id="typing" class="wa-typing" style="display:none">yazıyor…</div>
              </div>
              <div id="waBody" class="wa-body">
                <?php foreach($conversation as $m): ?>
                  <div class="wa-msg <?php echo $m['direction']=='out'?'out':'in'; ?>">
                    <div class="bubble">
                      <div><?php echo nl2br(html_escape($m['body'])); ?></div>
                      <div class="wa-meta">
                        <span><?php echo _dt($m['created_at']); ?></span>
                        <?php if($m['direction']=='out'): ?>
                          <span class="wa-checks">
                            <?php
                              $status = $m['status'] ?? '';
                              echo $status==='read' ? '✔✔' : ($status==='delivered' ? '✔✔' : '✔');
                            ?>
                          </span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
              <div class="wa-input">
                <?php echo form_open(admin_url('whatsapp_plus/send'), ['id'=>'sendForm']); ?>
                  <input type="hidden" name="to" value="<?php echo html_escape($active_contact_name); ?>"/>
                  <textarea class="form-control" name="text" placeholder="<?php echo _l('message'); ?>"></textarea>
                  <button class="btn btn-success"><i class="fa fa-paper-plane"></i> <?php echo _l('send'); ?></button>
                <?php echo form_close(); ?>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  var phone = <?php echo json_encode($active_phone ?: null); ?>;
  if(!phone) return;
  var bodyEl = document.getElementById('waBody');
  // Basit poll
  function poll(){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '<?php echo admin_url('whatsapp_plus/poll?phone='); ?>'+encodeURIComponent(phone), true);
    xhr.onreadystatechange = function(){
      if(xhr.readyState===4 && xhr.status===200){
        try{
          var res = JSON.parse(xhr.responseText);
          if(res && res.success){
            render(res.messages||[]);
          }
        }catch(e){}
      }
    };
    xhr.send();
  }
  function render(list){
    if(!bodyEl) return;
    bodyEl.innerHTML = '';
    list.forEach(function(m){
      var wrap = document.createElement('div');
      wrap.className = 'wa-msg '+(m.direction==='out'?'out':'in');
      var bubble = document.createElement('div');
      bubble.className = 'bubble';
      var text = document.createElement('div');
      text.innerHTML = (m.body||'').replace(/\n/g,'<br>');
      var meta = document.createElement('div');
      meta.className = 'wa-meta';
      var when = document.createElement('span');
      when.textContent = m.created_at;
      meta.appendChild(when);
      if(m.direction==='out'){
        var checks = document.createElement('span');
        checks.className = 'wa-checks';
        var s = (m.status||'');
        checks.textContent = (s==='read'?'✔✔':(s==='delivered'?'✔✔':'✔'));
        meta.appendChild(checks);
      }
      bubble.appendChild(text);
      bubble.appendChild(meta);
      wrap.appendChild(bubble);
      bodyEl.appendChild(wrap);
    });
    bodyEl.scrollTop = bodyEl.scrollHeight;
  }
  setInterval(poll, 4000);

  // Yazıyor... simülasyonu: textarea focus + yazma
  var typingEl = document.getElementById('typing');
  var ta = document.querySelector('#sendForm textarea');
  if(ta){
    var tm;
    ta.addEventListener('input', function(){
      typingEl.style.display='inline';
      clearTimeout(tm);
      tm = setTimeout(function(){ typingEl.style.display='none'; }, 1200);
    });
  }
})();
</script>
<?php init_tail(); ?>
