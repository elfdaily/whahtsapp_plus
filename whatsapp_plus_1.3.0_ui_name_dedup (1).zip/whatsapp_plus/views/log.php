<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin">WhatsApp Plus — Log & Test</h4>
            <hr/>
            <div class="row">
              <div class="col-md-6">
                <div class="mbot15">
                  <button id="btnPing"  class="btn btn-default">PING</button>
                  <button id="btnPostFv" class="btn btn-primary">POST (FV)</button>
                  <button id="btnPostWa" class="btn btn-info">POST (WA/entry)</button>
                  <button id="btnSeed"   class="btn btn-warning">SEED → DB</button>
                  <button id="btnDelivered" class="btn btn-success">STATUS delivered</button>
                  <button id="btnRead" class="btn btn-success">STATUS read</button>
                  <button id="btnClear"  class="btn btn-danger pull-right">Temizle</button>
                </div>
                <h5>Son Log</h5>
                <pre id="logBox" style="max-height:420px;overflow:auto;background:#111;color:#9f9;padding:10px;border-radius:4px;"><?php echo html_escape($log_text ?? ''); ?></pre>
              </div>
              <div class="col-md-6">
                <h5>Nasıl test ederim?</h5>
                <p><strong>Ayarlar</strong> ekranından Access Token, WABA ID, Phone Number ID ve Verify Token gir.</p>
                <p><strong>Webhook URL</strong>’ini Meta’da doğrula (GET doğrulaması).</p>
                <p>Bu sayfada <strong>PING</strong> ile yazma denemesi yap. Sonra <strong>POST (FV)</strong> ve <strong>POST (WA)</strong> ile örnek payload gönder; hem loga düşer hem DB’ye satır eklenir.</p>
                <p><strong>SEED → DB</strong> ile elle bir inbound mesaj oluştur, Mesajlar ekranına düşer.</p>
                <p><em>Not:</em> Webhook uçları ve test araçları CSRF’siz GET/POST olarak çalışır.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  function adminUrl(path){ return <?php echo json_encode(admin_url('')); ?> + path; }
  function siteUrl(path){  return <?php echo json_encode(site_url(''));  ?> + path; }
  var logBox = document.getElementById('logBox');
  function refreshLog(){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', adminUrl('whatsapp_plus/tools/get_log'), true);
    xhr.onload = function(){ if(this.status===200){ logBox.textContent = this.responseText; logBox.scrollTop = logBox.scrollHeight; } };
    xhr.send();
  }
  function post(url){
    var xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
    xhr.onload = function(){ refreshLog(); };
    xhr.send('t='+(Date.now()));
  }
  function get(url){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.onload = function(){ refreshLog(); };
    xhr.send();
  }
  document.getElementById('btnPing').onclick   = function(){ get(adminUrl('whatsapp_plus/tools/ping')); };
  document.getElementById('btnPostFv').onclick = function(){ get(adminUrl('whatsapp_plus/tools/post_fv')); };
  document.getElementById('btnPostWa').onclick = function(){ get(adminUrl('whatsapp_plus/tools/post_wa')); };
  document.getElementById('btnSeed').onclick   = function(){ get(adminUrl('whatsapp_plus/tools/seed')); };
  document.getElementById('btnDelivered').onclick = function(){ get(adminUrl('whatsapp_plus/tools/status_delivered')); };
  document.getElementById('btnRead').onclick      = function(){ get(adminUrl('whatsapp_plus/tools/status_read')); };
  document.getElementById('btnClear').onclick  = function(){ get(adminUrl('whatsapp_plus/tools/clear')); setTimeout(refreshLog, 300); };
  // İlk yüklemede logu getir
  setTimeout(refreshLog, 200);
})();
</script>
<?php init_tail(); ?>
