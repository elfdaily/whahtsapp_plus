<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="panel_s">
      <div class="panel-body">
        <h4><?php echo _l('settings'); ?></h4>
        <?php echo form_open(admin_url('whatsapp_plus/settings')); ?>
          <div class="form-group">
            <label>Access Token</label>
            <input class="form-control" name="wp_access_token" value="<?php echo html_escape($wp_access_token); ?>" required>
          </div>
          <div class="form-group">
            <label>WABA ID</label>
            <input class="form-control" name="wp_waba_id" value="<?php echo html_escape($wp_waba_id); ?>" required>
          </div>
          <div class="form-group">
            <label>Phone Number ID</label>
            <input class="form-control" name="wp_phone_number_id" value="<?php echo html_escape($wp_phone_number_id); ?>" required>
          </div>
          <div class="form-group">
            <label>Verify Token (Webhook doğrulama için)</label>
            <input class="form-control" name="wp_verify_token" value="<?php echo html_escape($wp_verify_token); ?>">
          </div>
          <button class="btn btn-success"><?php echo _l('submit'); ?></button>
        <?php echo form_close(); ?>
        <hr/>
        <p><strong>Webhook URL:</strong> <code><?php echo site_url('whatsapp_plus/webhook'); ?></code></p>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
