<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Idempotent installer – tablo yoksa oluşturur; eksik sütunları ekler.
 * DB silindiğinde admin panel her açıldığında tekrar çalışır.
 */
function whatsapp_plus_install()
{
    $CI = &get_instance();
    $db = $CI->db;
    $prefix = db_prefix();

    // Logs
    if (!$db->table_exists($prefix . 'whatsapp_plus_logs')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_logs` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `source` VARCHAR(32) NOT NULL,      -- tools | webhook | system
            `tag` VARCHAR(32) NULL,             -- INFO | PAYLOAD | RESP | etc
            `text` TEXT NULL,
            `meta_json` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_logs');
        $ensure = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_logs` ADD COLUMN {$sql}");
            }
        };
        $ensure('meta_json', " `meta_json` MEDIUMTEXT NULL AFTER `text`");
    }

    // Contacts
    if (!$db->table_exists($prefix . 'whatsapp_plus_contacts')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_contacts` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `phone_e164` VARCHAR(32) NOT NULL,
            `name` VARCHAR(191) NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NULL,
            UNIQUE KEY `uniq_phone` (`phone_e164`),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_contacts');
        $ensureC = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD COLUMN {$sql}");
            }
        };
        $ensureC('name', " `name` VARCHAR(191) NULL AFTER `phone_e164`");
        $ensureC('updated_at', " `updated_at` DATETIME NULL AFTER `created_at`");
        try { $db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD UNIQUE KEY `uniq_phone` (`phone_e164`)"); } catch (Exception $e) {}
    }

    // Accounts
    if (!$db->table_exists($prefix . 'whatsapp_plus_accounts')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_accounts` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT 'default',
            `waba_id` VARCHAR(191) NULL,
            `phone_number_id` VARCHAR(191) NULL,
            `access_token` TEXT NULL,
            `verify_token` VARCHAR(191) NULL,
            `status` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    }

    // Messages
    if (!$db->table_exists($prefix . 'whatsapp_plus_messages')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_messages` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `account_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `direction` ENUM('in','out') NOT NULL,
            `phone` VARCHAR(32) NOT NULL,
            `phone_e164` VARCHAR(32) NULL,
            `type` VARCHAR(32) NOT NULL DEFAULT 'text',
            `body` MEDIUMTEXT NULL,
            `wa_message_id` VARCHAR(128) NULL,
            `status` VARCHAR(32) NULL,              -- sent, delivered, read, error, received
            `error` TEXT NULL,
            `meta_json` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            `received_at` DATETIME NULL,
            `sent_at` DATETIME NULL,
            `delivered_at` DATETIME NULL,
            `read_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            INDEX (`phone`), INDEX(`phone_e164`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        // Eksik kolonları ekle
        $fields = $db->list_fields($prefix . 'whatsapp_plus_messages');
        $ensure = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_messages` ADD COLUMN {$sql}");
            }
        };
        $ensure('phone_e164',  " `phone_e164` VARCHAR(32) NULL AFTER `phone`");
        $ensure('status',       " `status` VARCHAR(32) NULL AFTER `wa_message_id`");
        $ensure('error',        " `error` TEXT NULL AFTER `status`");
        $ensure('meta_json',    " `meta_json` MEDIUMTEXT NULL AFTER `error`");
        $ensure('received_at',  " `received_at` DATETIME NULL AFTER `created_at`");
        $ensure('delivered_at', " `delivered_at` DATETIME NULL AFTER `sent_at`");
        $ensure('read_at',      " `read_at` DATETIME NULL AFTER `delivered_at`");
    }

    // Ayarlar (Perfex options)
    add_option('wp_access_token',   get_option('wp_access_token') ?: '');
    add_option('wp_waba_id',        get_option('wp_waba_id') ?: '');
    add_option('wp_phone_number_id',get_option('wp_phone_number_id') ?: '');
    add_option('wp_verify_token',   get_option('wp_verify_token') ?: '');
}

function whatsapp_plus_uninstall()
{
    delete_option('wp_access_token');
    delete_option('wp_waba_id');
    delete_option('wp_phone_number_id');
    delete_option('wp_verify_token');
}
