<?php
defined('BASEPATH') or exit('No direct script access allowed');

function wp_option($k, $d = '')
{
    $v = function_exists('get_option') ? get_option($k) : '';
    return $v === '' ? $d : $v;
}
function wp_admin_view($view, $data = [])
{
    $CI = &get_instance();
    $CI->load->view('whatsapp_plus/' . $view, $data);
}
function wp_json_response($arr, $code = 200)
{
    header('Content-Type: application/json; charset=utf-8', true, $code);
    echo json_encode($arr);
    exit;
}

function wp_normalize_phone($s){
    $s = trim((string)$s);
    if ($s==='') return '';
    $has_plus = substr($s,0,1) === '+';
    $digits = preg_replace('/\D+/', '', $s);
    if ($digits==='') return '';
    if (!$has_plus && strpos($digits,'00')===0){ $digits = substr($digits,2); $has_plus = true; }
    return ($has_plus?'+' : '+') . $digits;
}
