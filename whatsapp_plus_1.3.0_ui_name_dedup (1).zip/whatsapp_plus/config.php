<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Dual manifest for Perfex module listing compatibility.
 * Some builds expect $module[..], others $config[..]. We populate both.
 */

/* Array style expected by many Perfex builds */
$module = [
    'module_name' => 'whatsapp_plus',
    'name'        => 'WhatsApp Plus',
    'description' => 'WhatsApp Business (Cloud API) integration for Perfex CRM',
    'version'     => '1.1.1',
    'author'      => 'Iteally',
];

/* Also provide the $config keys used by other builds */
$config['name']           = $module['name'];
$config['module_name']    = $module['module_name'];
$config['description']    = $module['description'];
$config['version']        = $module['version'];
$config['module_version'] = $module['version'];
$config['author']         = $module['author'];
$config['is_default']     = false;
