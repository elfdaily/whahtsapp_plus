# Whatsapp Plus (Perfex CRM Module)
- Author: Iteally
- Version: 4.0.0
- Date: 2025-08-20

Includes:
- v23.0 Graph API
- Robust webhook (supports both entry/changes and field/value sample)
- Debug log at `modules/whatsapp_plus/storage/webhook.log`
- Inbox view (threads + conversation)
- CSRF-safe forms


## v1.4.4 - Media & Events (2025-08-22)
- Mesaj kutusuna **+** menüsü eklendi: Resim, Belge, Ses dosyası, Ses kaydı ve ICS Etkinlik gönderimi.
- WhatsApp Cloud API ile **image/document/audio** gönderimi ve **(varsa)** arama butonu (interactive/call).
- Sunucu tarafında ICS üretimi ile **takvim etkinliği** gönderme.
- Yüklenen dosyalar `modules/whatsapp_plus/storage/media/YYYY/MM/` dizininde saklanır.
- Yeni tablo: `{db_prefix}whatsapp_plus_media`.
- `WhatsAppCloudClient` kütüphanesine `uploadMedia`, `sendImageById`, `sendDocumentById`, `sendAudioById`, `sendCallButton` metotları eklendi.


## v1.4.5 - Hotfix (CompileError)
- `controllers/Whatsapp_plus.php` içinde yinelenen erişim belirleyicisi düzeltildi.
- Fonksiyon bildirimi şimdi tek `public function send()` olarak derleniyor.


## v1.4.6 - Hotfix 2 (Model ParseError)
- `models/Whatsapp_plus_model.php` içindeki `get_media_by_message()` sınıf kapsamı içine taşındı.
- Dosya sonundaki kapanış süslü parantezleri normalize edildi.


## v1.4.7 - Hotfix 3 (Client ParseError & multipart)
- `WhatsAppCloudClient.php` içinde constructor sonrası fazla `}` kaldırıldı.
- `request()` imzası `$opts = []` ve **multipart/form-data** desteği ile güncellendi.


## v1.4.8 - Hotfix 4 (Client unexpected $res)
- `WhatsAppCloudClient.php` baştan yazıldı (constructor, endpoint, request (multipart), uploadMedia ve media gönderim metotları temizlendi).


## v1.4.9 - UI Fixes
- File input görünürlük sorunu giderildi (sert gizleme).
- Mesaj çubuğu hizalama: 40px yükseklik, otomatik boyutlanan textarea.
- Dropdown ve buton boyutları düzenlendi.


## v1.4.10 - Composer & Attachments UI
- Composer flex düzeni (yan yana + buton, metin, gönder).
- Dropdown **dropup** olarak açılıyor; taşma yok.
- Mesaj balonlarında medya önizleme: resimler küçük görsel, ses `audio` oynatıcı, doküman kartı.
- Güvenli indirme endpoint'i: `/whatsapp_plus/download/{id}` (izin kontrolü).


## v1.4.11 - Hotfix 5 (Model public token)
- `get_media()` metodu sınıf sonuna, kapanış süslüsünden **önce** taşındı.
- Model dosyasının kapanışları normalize edildi.


## v1.4.12 - Hotfix 6 (Model brace)
- Model dosyasındaki açık kalan sınıf süslüsü kapatıldı.
