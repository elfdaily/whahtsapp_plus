<?php
defined('BASEPATH') or exit('No direct script access allowed');
function whatsapp_plus_admin_head(){
    echo '<style>.wp-badge{display:inline-block;padding:2px 6px;border-radius:4px;background:#25D366;color:#fff;font-size:11px;margin-left:6px}</style>';
}
function whatsapp_plus_admin_footer(){}
