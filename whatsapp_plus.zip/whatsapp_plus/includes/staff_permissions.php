<?php
defined('BASEPATH') or exit('No direct script access allowed');
hooks()->add_filter('staff_permissions', function($permissions){
    $permissions['whatsapp_plus'] = [
        'name' => _l('whatsapp_plus_permission'),
        'capabilities' => [
            'view'   => _l('permission_view'),
            'create' => _l('permission_create'),
            'edit'   => _l('permission_edit'),
            'delete' => _l('permission_delete'),
        ]
    ];
    return $permissions;
});
