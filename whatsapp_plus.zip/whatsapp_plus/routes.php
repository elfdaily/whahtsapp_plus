<?php
defined('BASEPATH') or exit('No direct script access allowed');
$routes->add('whatsapp_plus/webhook', 'whatsapp_plus/webhook/index');
$routes->add('whatsapp_plus/poll', 'whatsapp_plus/whatsapp_plus/poll');
$routes->add('whatsapp_plus/typing', 'whatsapp_plus/whatsapp_plus/typing');


$routes->add('whatsapp_plus/toggle_message_important', 'whatsapp_plus/whatsapp_plus/toggle_message_important');
$routes->add('whatsapp_plus/toggle_thread_important', 'whatsapp_plus/whatsapp_plus/toggle_thread_important');
$routes->add('whatsapp_plus/important_threads', 'whatsapp_plus/whatsapp_plus/important_threads');


$routes->add('whatsapp_plus/download/(:num)', 'whatsapp_plus/whatsapp_plus/download_media/$1');

$routes->add('whatsapp_plus/qr_webhook', 'whatsapp_plus/qr_webhook/index');

$routes->add('whatsapp_plus/send', 'whatsapp_plus/whatsapp_plus/send');
$routes->add('whatsapp_plus/send_qr', 'whatsapp_plus/whatsapp_plus/send_qr');
$routes->add('whatsapp_plus/status_updates', 'whatsapp_plus/whatsapp_plus/status_updates');

$routes->add('whatsapp_plus/status_poll', 'whatsapp_plus/whatsapp_plus/status_poll');

$routes->add('whatsapp_plus/accounts', 'whatsapp_plus/whatsapp_plus/accounts');
$routes->add('whatsapp_plus/account_save', 'whatsapp_plus/whatsapp_plus/account_save');
$routes->add('whatsapp_plus/account_delete/(:num)', 'whatsapp_plus/whatsapp_plus/account_delete/$1');
