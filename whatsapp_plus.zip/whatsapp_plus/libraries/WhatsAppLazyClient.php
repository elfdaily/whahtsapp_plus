<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * WhatsAppLazyClient
 * Basit HTTP istemcisi (wa-lazy / QR tabanlı gateway) için.
 * Ayarlar: wp_qr_api_url, wp_qr_api_key, wp_qr_device, wp_qr_send_text_path, wp_qr_send_media_path
 * Ek: wp_qr_payload_mode = 'json' ise Dayxen formatında JSON gönderir.
 */
class WhatsAppLazyClient
{

    public function __construct(array $cfg = null)
    {
        if ($cfg) {
            $this->cfg = $cfg;
            $this->apiUrl       = rtrim(($cfg['api_url'] ?? get_option('wp_qr_api_url')), '/');
            $this->apiKey       = $cfg['api_key'] ?? get_option('wp_qr_api_key');
            $this->device       = $cfg['device']  ?? get_option('wp_qr_device');
            $this->sendTextPath = $cfg['send_text_path']  ?? (get_option('wp_qr_send_text_path') ?: '/api/send-message');
            $this->sendMediaPath= $cfg['send_media_path'] ?? (get_option('wp_qr_send_media_path') ?: '/api/send-media');
            $this->payloadMode  = $cfg['payload_mode'] ?? (get_option('wp_qr_payload_mode') ?: 'json');

        // Auto-adjust defaults for Dayxen/wa-lazy when not explicitly set
        if (stripos((string)$this->apiUrl, 'dayxen') !== false || stripos((string)$this->apiUrl, 'wa-api') !== false || stripos((string)$this->apiUrl, 'wa-lazy') !== false) {
            if ($this->sendTextPath === '/api/send-text') { $this->sendTextPath = '/api/send-message'; }
            if (empty($this->payloadMode) || $this->payloadMode === 'form') { $this->payloadMode = 'json'; }
            if (empty($this->sendMediaPath)) { $this->sendMediaPath = '/api/send-media'; }
        }

        } else {
            // Backward compatible (global options)
            $this->apiUrl       = rtrim(get_option('wp_qr_api_url'), '/');
            $this->apiKey       = get_option('wp_qr_api_key');
            $this->device       = get_option('wp_qr_device');
            $this->sendTextPath = get_option('wp_qr_send_text_path') ?: '/api/send-message';
            $this->sendMediaPath= get_option('wp_qr_send_media_path') ?: '/api/send-media';
            $this->payloadMode  = get_option('wp_qr_payload_mode') ?: 'json';
        }
    }
    
    private $cfg = null;
    private $apiUrl;
    private $apiKey;
    private $device;
    private $sendTextPath;
    private $sendMediaPath;
    private $payloadMode; // 'form' (default) or 'json'

    public function isConfigured()
    {
        return !empty($this->apiUrl) && !empty($this->apiKey) && !empty($this->sendTextPath);
    }

    /** Text mesaj gönderimi */
    public function sendText($to, $message, $device = null)
    {
        if ($this->payloadMode === 'json') {
            // Dayxen formatı
            $payload = [
                'api_key'  => $this->apiKey,
                'receiver' => $to,
                'data'     => ['message' => $message],
            ];
        } else {
            // Generic gateway
            $payload = [
                'api_key'    => $this->apiKey,
                'device'     => $device ?: $this->device,
                'destination'=> $to,
                'message'    => $message,
            ];
        }
        $url = $this->apiUrl . $this->sendTextPath;
        return $this->post($url, $payload);
    }

    /**
     * Medya gönderimi
     * JSON modunda (Dayxen) URL tabanlı medya beklenir: data: { url, media_type, caption }
     * form modunda mevcut eski davranış korunur (dosya upload).
     */
    public function sendMedia($to, $filePathOrUrl, $mime = null, $caption = '', $mediaType = 'image')
    {
        if ($this->payloadMode === 'json') {
            $payload = [
                'api_key'  => $this->apiKey,
                'receiver' => $to,
                'data'     => [
                    'url'        => $filePathOrUrl, // burada URL beklenir
                    'media_type' => $mediaType,
                    'caption'    => $caption,
                ],
            ];
        } else {
            // Eski form-encoded/multipart gönderim
            $payload = [
                'api_key'    => $this->apiKey,
                'device'     => $this->device,
                'destination'=> $to,
                'caption'    => $caption,
            ];
            if (is_file($filePathOrUrl)) {
                // try CURLFile
                if (class_exists('CURLFile')) {
                    $payload['file'] = new CURLFile($filePathOrUrl, $mime ?: null, basename($filePathOrUrl));
                } else {
                    $payload['file'] = '@' . realpath($filePathOrUrl);
                }
            } else {
                // file is URL
                $payload['url'] = $filePathOrUrl;
            }
        }
        $url = $this->apiUrl . $this->sendMediaPath;
        return $this->post($url, $payload);
    }

    /** Low-level POST */
    private function post($url, $data)
    {
        $ch = curl_init($url);
        $headers = ['Accept: application/json'];
        if ($this->payloadMode === 'json') {
            $headers[] = 'Content-Type: application/json';
            $postfields = json_encode($data, JSON_UNESCAPED_UNICODE);
        } else {
            $postfields = $data;
        }
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $postfields,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT    => 60,
        ]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return [
            'ok' => ($err === '' || $err === null) && $status >= 200 && $status < 300,
            'status' => $status,
            'error' => $err ?: null,
            'raw' => $raw,
            'json' => json_decode($raw, true)
        ];
    }
}