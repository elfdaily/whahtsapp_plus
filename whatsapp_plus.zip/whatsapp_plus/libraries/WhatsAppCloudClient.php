<?php
defined('BASEPATH') or exit('No direct script access allowed');

class WhatsAppCloudClient
{
    private $accessToken;
    private $phoneNumberId;
    private $graphVersion;

    public function __construct($accessToken = null, $phoneNumberId = null, $graphVersion = null)
    {
        $CI = &get_instance();
        // Perfex options / config fallback
        $this->accessToken   = $accessToken   !== null ? $accessToken   : (function_exists('get_option') ? get_option('wp_access_token')    : '');
        $this->phoneNumberId = $phoneNumberId !== null ? $phoneNumberId : (function_exists('get_option') ? get_option('wp_phone_number_id') : '');
        $this->graphVersion  = $graphVersion  !== null ? $graphVersion  : ($CI->config->item('wp_graph_api_version') ?: 'v20.0');
    }

    private function endpoint($path)
    {
        return "https://graph.facebook.com/{$this->graphVersion}/{$this->phoneNumberId}/{$path}";
    }

    private function request($method, $url, $payload = null, $opts = [])
    {
        $ch = curl_init($url);
        $multipart = isset($opts['multipart']) ? (bool)$opts['multipart'] : false;

        $headers = ['Authorization: Bearer ' . $this->accessToken];
        if (!$multipart) {
            $headers[] = 'Content-Type: application/json';
        }

        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        if ($method === 'POST' || $method === 'PUT') {
            if ($multipart) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            } else {
                if ($payload !== null) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                }
            }
        }

        $res  = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        return [$code, $res, $err];
    }

    public function sendText($to, $text)
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'text',
            'text' => ['body' => $text],
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }

    public function uploadMedia($filePath, $mime = null)
    {
        if (!is_readable($filePath)) {
            return [0, null, 'File not readable'];
        }
        $cfile = class_exists('CURLFile')
            ? new CURLFile($filePath, $mime ?: mime_content_type($filePath), basename($filePath))
            : '@' . $filePath;

        $payload = [
            'messaging_product' => 'whatsapp',
            'file' => $cfile,
        ];
        if ($mime) { $payload['type'] = $mime; }

        return $this->request('POST', $this->endpoint('media'), $payload, ['multipart' => true]);
    }

    public function sendImageById($to, $mediaId, $caption = '')
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'image',
            'image' => ['id' => $mediaId, 'caption' => $caption],
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }

    public function sendDocumentById($to, $mediaId, $filename = null, $caption = '')
    {
        $doc = ['id' => $mediaId];
        if ($filename) { $doc['filename'] = $filename; }
        if ($caption)  { $doc['caption'] = $caption; }

        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'document',
            'document' => $doc,
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }

    public function sendAudioById($to, $mediaId)
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'audio',
            'audio' => ['id' => $mediaId],
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }

    /** Experimental: call button (if API allows) */
    public function sendCallButton($to, $displayText, $phoneNumber, $bodyText = 'Telefon ile iletişime geçmek için aşağıdaki butona tıklayın.')
    {
        $payload = [
            'messaging_product' => 'whatsapp',
            'to' => $to,
            'type' => 'interactive',
            'interactive' => [
                'type' => 'button',
                'body' => ['text' => $bodyText],
                'action' => [
                    'buttons' => [[
                        'type' => 'call',
                        'text' => $displayText ?: 'Ara',
                        'phone_number' => $phoneNumber,
                    ]],
                ],
            ],
        ];
        return $this->request('POST', $this->endpoint('messages'), $payload);
    }
}
