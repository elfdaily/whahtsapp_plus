<?php
/**
 * WhatsApp Plus — MediaSaver Patch (v1.0)
 * 
 * Drop-in helper to save incoming media (data_uri OR url) into
 * modules/whatsapp_plus/storage/media/YYYY/MM/ and update DB row.
 *
 * Usage (inside your webhook controller, AFTER you insert media row):
 *   require_once __DIR__ . '/../libraries/MediaSaver.php';
 *   WpPlusMediaSaver::saveFromRequest($this->db, $media_row_id, __DIR__ . '/..');
 *
 * Works with CodeIgniter $this->db (query builder) OR a PDO instance.
 */
class WpPlusMediaSaver
{
    /**
     * Save media coming via current request and update tblwhatsapp_plus_media.
     *
     * @param mixed  $db           CodeIgniter DB object OR PDO instance
     * @param int    $mediaRowId   tblwhatsapp_plus_media.id (just inserted)
     * @param string $moduleRoot   Absolute path to modules/whatsapp_plus
     * @return array|null          ['file_path','mime','size','sha1'] on success, null otherwise
     */
    public static function saveFromRequest($db, $mediaRowId, $moduleRoot)
    {
        try {
            // 1) Collect request payload (form or json)
            $raw = file_get_contents('php://input');
            $json = json_decode($raw, true);
            $in   = is_array($json) ? $json : $_POST;

            $mediaType = self::pick($in, ['media_type','type']);
            $filename  = self::pick($in, ['filename','name'], 'file.bin');
            $caption   = self::pick($in, ['caption'], '');
            $url       = self::pick($in, ['url','mediaUrl']);
            $dataUri   = self::pick($in, ['data_uri','dataUri','base64']);

            // 2) Decode data: prefer data_uri, fallback to url
            $mime = null; $bin = null;
            if ($dataUri) {
                if (preg_match('#^data:([^;]+);base64,(.+)$#', $dataUri, $m)) {
                    $mime = $m[1];
                    $bin  = base64_decode($m[2]);
                } else {
                    // handle "base64,AAAA..." or raw base64
                    $dataUri = preg_replace('#^base64,#i', '', $dataUri);
                    $bin = base64_decode($dataUri);
                }
            }

            if (!$bin && $url) {
                // Robust curl download (follows redirects)
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 5,
                    CURLOPT_CONNECTTIMEOUT => 10,
                    CURLOPT_TIMEOUT        => 30,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_USERAGENT      => 'whatsapp-plus/1.0'
                ]);
                $bin  = curl_exec($ch);
                $ct   = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                if (!empty($ct)) $mime = $ct;
                curl_close($ch);
                if ($bin === false || strlen($bin) === 0) $bin = null;
            }

            if (!$bin) {
                self::appendLog($moduleRoot, "NO_BIN for mediaRowId={$mediaRowId} (url={$url})");
                return null;
            }

            // 3) Determine MIME if missing
            if (!$mime && function_exists('finfo_open')) {
                $fi = finfo_open(FILEINFO_MIME_TYPE);
                $mime = @finfo_buffer($fi, $bin) ?: 'application/octet-stream';
                @finfo_close($fi);
            }
            if (!$mime) $mime = 'application/octet-stream';

            // 4) Build filename safely
            $base = pathinfo($filename, PATHINFO_FILENAME);
            $ext  = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            if (!$ext && strpos($mime, '/')) { $ext = explode('/', $mime)[1]; }
            if (!$ext) $ext = 'bin';
            $safeBase  = preg_replace('/[^a-zA-Z0-9._-]/', '_', $base ?: 'file');
            $finalName = $safeBase . '.' . $ext;

            // 5) Ensure target dir
            $dir = rtrim($moduleRoot, '/').'/storage/media/'.date('Y').'/'.date('m').'/';
            if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

            $uniq = uniqid('', true);
            $full = $dir . $uniq . '-' . $finalName;
            if (@file_put_contents($full, $bin) === false) {
                self::appendLog($moduleRoot, "WRITE_FAIL {$full}");
                return null;
            }
            @chmod($full, 0664);

            $size = @filesize($full) ?: null;
            $sha1 = @sha1_file($full) ?: null;
            $rel  = 'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/'.basename($full);

            // 6) Update DB
            self::updateMediaRow($db, $mediaRowId, [
                'file_path' => $rel,
                'mime'      => $mime,
                'size'      => $size,
                'sha1'      => $sha1,
            ]);

            self::appendLog($moduleRoot, "OK mediaRowId={$mediaRowId} path={$rel} mime={$mime} size={$size}");
            return ['file_path'=>$rel,'mime'=>$mime,'size'=>$size,'sha1'=>$sha1];

        } catch (Throwable $e) {
            self::appendLog($moduleRoot, "ERROR ".$e->getMessage());
            return null;
        }
    }

    private static function updateMediaRow($db, $id, array $data)
    {
        // CodeIgniter Query Builder?
        if (is_object($db) && method_exists($db, 'where') && method_exists($db, 'update')) {
            $db->where('id', $id)->update('tblwhatsapp_plus_media', $data);
            return;
        }
        // PDO?
        if ($db instanceof PDO) {
            $st = $db->prepare("UPDATE tblwhatsapp_plus_media SET file_path=?, mime=?, size=?, sha1=? WHERE id=?");
            $st->execute([$data['file_path'],$data['mime'],$data['size'],$data['sha1'],$id]);
            return;
        }
        // Fallback: try mysqli connection living under $db->conn_id (CI3)
        if (is_object($db) && property_exists($db, 'conn_id') && $db->conn_id instanceof mysqli) {
            $mysqli = $db->conn_id;
            $stmt = $mysqli->prepare("UPDATE tblwhatsapp_plus_media SET file_path=?, mime=?, size=?, sha1=? WHERE id=?");
            $stmt->bind_param('ssssi', $data['file_path'],$data['mime'],$data['size'],$data['sha1'],$id);
            $stmt->execute();
            $stmt->close();
            return;
        }
        // Last resort: do nothing
    }

    private static function pick($arr, $keys, $default=null) {
        foreach ((array)$keys as $k) {
            if (is_array($arr) && array_key_exists($k, $arr) && $arr[$k] !== '' && $arr[$k] !== null) return $arr[$k];
        }
        return $default;
    }

    private static function appendLog($moduleRoot, $line) {
        $log = rtrim($moduleRoot, '/').'/storage/webhook.log';
        @file_put_contents($log, date('c').' '.$line.PHP_EOL, FILE_APPEND);
    }
}
