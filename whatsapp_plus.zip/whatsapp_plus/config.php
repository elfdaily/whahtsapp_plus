<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Module manifest for Perfex.
 * We provide both $module[...] and $config[...] for compatibility.
 */

$__version = @file_get_contents(__DIR__ . '/VERSION');
$__version = $__version ? trim($__version) : '3.3.6';

/* Array style expected by many Perfex builds */
$module = [
    'module_name' => 'whatsapp_plus',
    'name'        => 'WhatsApp Plus',
    'description' => 'WhatsApp Business (Cloud API) integration for Perfex CRM',
    'version'     => $__version,
    'author'      => 'Iteally',
];

/* Also provide the $config keys used by other builds */
$config['name']           = $module['name'];
$config['module_name']    = $module['module_name'];
$config['description']    = $module['description'];
$config['version']        = $module['version'];
$config['module_version'] = $module['version'];
$config['author']         = $module['author'];
$config['is_default']     = false;
