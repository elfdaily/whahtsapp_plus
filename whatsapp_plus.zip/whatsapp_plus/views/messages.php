

<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>


<?php init_head(); ?>
<script id="wa-json-guard-336">
(function(){
  if (window.__waJSONGuard__) return;
  window.__waJSONGuard__ = true;

  var origJson = Response.prototype.json;
  Response.prototype.json = async function(){
    // clone'u en başta al ki bir şey patlarsa fallback için body kalsın
    var clone = null; try{ clone = this.clone(); }catch(_){}
    try{
      // içerik tipi JSON ise normal dene
      return await origJson.call(this);
    }catch(err){
      try{
        var txt = clone ? await clone.text() : '';
        // login / HTML / hata sayfası -> sessizce boş obje dön
        if (/<!doctype|<html|<div|<form/i.test(txt)) {
          // oturum düştüyse yenile
          if (/login|giri[sş]|password/i.test(txt)) { setTimeout(function(){ location.reload(); }, 800); }
          console.warn('[WA] Non-JSON response from', this.url, txt.slice(0,200));
          return {};
        }
        // JSON gibi duruyorsa yine de dene
        txt = (txt||'').trim();
        if (txt.startsWith('{') || txt.startsWith('[')) {
          try { return JSON.parse(txt); } catch(e){}
        }
      }catch(_){}
      return {};
    }
  };
})();
</script>

<?php $___isGroup = (isset($active_phone) && is_string($active_phone) && strpos($active_phone,'g:')===0); ?>
<?php $___showSender = true; ?>
<?php ?>
<?php ?>

<style id="waPlus-header-guard">
/* v1.4.3: prevent header icon flicker on whatsapp_plus page only */
#header .fa-regular.fa-square-check.fa-lg.tw-shrink-0{line-height:1;vertical-align:middle;transform:none;margin:0;display:inline-block}
</style>

<script>
  // Global DOM helpers (injected by v2.3.7 fix)
  window.qs  = window.qs  || function(sel, ctx){ return (ctx||document).querySelector(sel); };
  window.qsa = window.qsa || function(sel, ctx){ return Array.prototype.slice.call((ctx||document).querySelectorAll(sel)); };

  // Extra aliases for NodeList selection (do NOT override jQuery's $)
  window.$all = window.$all || function(sel, ctx){ return Array.prototype.slice.call((ctx||document).querySelectorAll(sel)); };
  window.$$   = window.$$   || window.$all;
</script>

<script>
// v1.4.3 – Safe CSRF stub (no jQuery/$ override)
(function(w){
  try{
    w.csrf_jquery_ajax_setup = w.csrf_jquery_ajax_setup || function(){
      try{
        if (w.jQuery && w.jQuery.ajaxSetup){
          var data = (w.csrfData && w.csrfData.formatted) ? w.csrfData.formatted : {};
          w.jQuery.ajaxSetup({ data: data });
        }
      }catch(e){}
    };
  }catch(e){}
})(window);
</script>

<?php
if (!function_exists('wa_friendly_time')){
  function wa_friendly_time($ts){
    try {
      if (is_numeric($ts)) { $dt = new DateTime('@'.$ts); $dt->setTimezone(new DateTimeZone(date_default_timezone_get())); }
      else { $dt = new DateTime($ts); }
    } catch (Exception $e) { return htmlspecialchars((string)$ts); }
    $now = new DateTime('now', $dt->getTimezone());
    $diff = $now->getTimestamp() - $dt->getTimestamp();
    if ($diff >= 0 && $diff < 60) return 'şimdi';
    if ($diff < 0 && $diff > -86400) return 'Yarın '.$dt->format('H:i');
    $today = $now->format('Y-m-d');
    $yesterday = (clone $now)->modify('-1 day')->format('Y-m-d');
    $tomorrow = (clone $now)->modify('+1 day')->format('Y-m-d');
    $day = $dt->format('Y-m-d');
    if ($day === $today) return 'Bugün '.$dt->format('H:i');
    if ($day === $yesterday) return 'Dün '.$dt->format('H:i');
    if ($day === $tomorrow) return 'Yarın '.$dt->format('H:i');
    if ($now->format('Y') === $dt->format('Y')) return $dt->format('d.m H:i');
    return $dt->format('Y-m-d H:i');
  }
}
?>

<div id="waPlus">

<style>#waPlus .wa-star-btn{margin-left:auto; cursor:pointer; opacity:.6}#waPlus .wa-star-btn.active{opacity:1;color:#f59e0b}#waPlus .wa-star-msg{position:absolute; top:6px; right:6px; cursor:pointer; opacity:.7}#waPlus .wa-star-msg.active{opacity:1}#waPlus /* Mobile responsive for WhatsApp Plus (scoped) */
@media (max-width: 991px){
  #waPlus .wa-wrap{height:auto;flex-direction:column;}#waPlus .wa-left{width:100%;min-width:0;max-height:48vh;}#waPlus .wa-left .wa-list{max-height:calc(48vh - 88px);overflow:auto;}#waPlus .wa-body{max-height:56vh;overflow:auto;}#waPlus .wa-top{position:sticky;top:0;background:#fff;z-index:2;}
}


.wa-sender{font-size:12px;opacity:.75;margin:0 0 4px 0;}
</style>

<style>
  /* v1.5.1 bubble/meta fixes & composer */
  #waPlus .wa-attachments{margin:6px 0 0;display:grid;grid-template-columns:1fr;gap:8px}
  #waPlus .wa-att{background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:6px}
  #waPlus .wa-att--image{padding:6px;background:#00000008}
  #waPlus .wa-att--image img{display:block;max-width:340px;width:100%;height:auto;border-radius:12px}
  #waPlus .wa-cap{margin-top:6px;font-size:13px;line-height:1.35;color:#0f172a}
  
/* v1.5.3 caption/layout hardening */
#waPlus .wa-att--image{display:block!important;padding:0!important;background:transparent!important}
#waPlus .wa-att--image a{display:block!important}
#waPlus .wa-att--image img{display:block!important;float:none!important;max-width:100%!important;width:100%!important;height:auto!important;border-radius:12px}
#waPlus .wa-cap{display:block!important;clear:both!important;margin:8px 0 0!important;padding:0!important;background:transparent!important;white-space:pre-wrap!important;word-break:break-word!important;overflow-wrap:anywhere!important}
#waPlus .bubble{overflow:visible}
/* v1.5.5 bubble sizing + meta block layout */
#waPlus .message .bubble, 
#waPlus .bubble{display:inline-block;width:auto;max-width:520px;vertical-align:top}
@media (min-width: 992px){
  #waPlus .message .bubble, 
  #waPlus .bubble{max-width:460px}
}
#waPlus .wa-attachments + .wa-text{margin-top:8px}
#waPlus .wa-cap{display:block;clear:both;margin:8px 0 0!important}
#waPlus .wa-meta{position:static;text-align:right;margin-top:6px;display:block;color:#6b7280;font-size:12px}
#waPlus .bubble{padding-bottom:0}

/* v1.5.4 meta right & bubble width */
#waPlus .bubble{position:relative;padding-bottom:18px}
@media (min-width: 992px){
  #waPlus .bubble{max-width: 460px}
}
#waPlus .wa-text{white-space:pre-wrap;word-break:break-word;margin:8px 0 0;font-size:14px;line-height:1.38}
#WA_META_ABS{position:absolute;right:10px;bottom:6px;margin-top:0;display:flex;gap:6px;align-items:center;color:#6b7280;font-size:12px;z-index:1}
#waPlus .wa-checks{opacity:.9}
#waPlus .wa-checks.read{color:#34B7F1;}
/* Doc & audio card polish */
#waPlus .wa-att--doc{display:flex;align-items:center;gap:8px;background:#eef2ff;border:1px solid #e0e7ff;border-radius:12px;padding:10px}
#waPlus .wa-att--doc a{text-decoration:none;display:flex;align-items:center}
#waPlus .wa-att__name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px}
#waPlus .wa-att--audio{background:#f1f5f9;border:1px solid #e5e7eb;border-radius:12px;padding:10px}


  #waPlus .wa-meta{margin-top:6px;position:relative;z-index:1}
  #waPlus .wa-inside{position:relative;overflow:visible;display:flex;align-items:center;gap:8px;background:#2228310D;border:1px solid #e5e7eb;border-radius:22px;padding:6px 10px}
  #waPlus .wa-input-text{height:32px;max-height:120px;border:none;background:transparent;box-shadow:none!important;resize:none;overflow:auto;padding-left:74px}
  
/* mic inside (next to +) */
#waPlus .wa-mic-inside{position:absolute;left:44px;top:50%;transform:translateY(-50%);width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:none;background:transparent;color:#0f172a}
#waPlus .wa-mic-inside:hover{background:rgba(15,23,42,.06)}

  #waPlus .wa-plus-inside{position:absolute;left:10px;top:50%;transform:translateY(-50%);width:24px;height:24px;border-radius:50%;background:#e2e8f0;display:flex;align-items:center;justify-content:center;font-weight:700;cursor:pointer;user-select:none}
  #waPlus .wa-inside-menu{position:absolute;bottom:42px;left:4px;min-width:240px;z-index:1060;display:none;background:#fff;border:1px solid #e5e7eb;border-radius:10px;box-shadow:0 10px 24px rgba(0,0,0,.07);padding:6px 0}
  #waPlus .wa-inside-menu.show{display:block}
  #waPlus .wa-inside-menu .dropdown-item{padding:8px 12px;color:#0f172a;text-decoration:none;display:block}
  #waPlus .wa-inside-menu .dropdown-item:hover{background:#f1f5f9}
  #waPlus .wa-input, #waPlus .wa-wrap, #waPlus .wa-chat{overflow:visible !important}
</style>

<style>
  /* Composer */
  #waPlus .wa-inside{position:relative;overflow:visible;display:flex;align-items:center;gap:8px;background:#2228310D;border:1px solid #e5e7eb;border-radius:22px;padding:6px 10px}
  #waPlus .wa-input-text{height:32px;max-height:120px;border:none;background:transparent;box-shadow:none!important;resize:none;overflow:auto;padding-left:74px}
  #waPlus .wa-input-text:focus{outline:none;box-shadow:none}
  #waPlus .wa-send-btn{height:32px;padding:0 10px;display:inline-flex;align-items:center}
  #waPlus .wa-plus-inside{position:absolute;left:10px;top:50%;transform:translateY(-50%);width:24px;height:24px;border-radius:50%;background:#e2e8f0;display:flex;align-items:center;justify-content:center;font-weight:700;cursor:pointer;user-select:none}
  #waPlus .wa-inside-menu{position:absolute;bottom:42px;left:4px;min-width:240px;z-index:1060;display:none;background:#fff;border:1px solid #e5e7eb;border-radius:10px;box-shadow:0 10px 24px rgba(0,0,0,.07);padding:6px 0}
  #waPlus .wa-inside-menu.show{display:block}
  #waPlus .wa-inside-menu .dropdown-item{padding:8px 12px;color:#0f172a;text-decoration:none;display:block}
  #waPlus .wa-inside-menu .dropdown-item:hover{background:#f1f5f9}
  #waPlus .wa-input, #waPlus .wa-wrap, #waPlus .wa-chat{overflow:visible !important}

  /* Bubble: image/doc/audio on top, text below */
  #waPlus .wa-attachments{margin:6px 0 0;display:grid;grid-template-columns:1fr;gap:8px}
  #waPlus .wa-att{background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:6px}
  #waPlus .wa-att--image{padding:6px;background:#00000008}
  #waPlus .wa-att--image img{display:block;max-width:340px;width:100%;height:auto;border-radius:12px}
  #waPlus .wa-cap{margin-top:6px;font-size:13px;line-height:1.35;color:#0f172a}
  
/* v1.5.3 caption/layout hardening */
#waPlus .wa-att--image{display:block!important;padding:0!important;background:transparent!important}
#waPlus .wa-att--image a{display:block!important}
#waPlus .wa-att--image img{display:block!important;float:none!important;max-width:100%!important;width:100%!important;height:auto!important;border-radius:12px}
#waPlus .wa-cap{display:block!important;clear:both!important;margin:8px 0 0!important;padding:0!important;background:transparent!important;white-space:pre-wrap!important;word-break:break-word!important;overflow-wrap:anywhere!important}
#waPlus .bubble{overflow:visible}
/* v1.5.5 bubble sizing + meta block layout */
#waPlus .message .bubble, 
#waPlus .bubble{display:inline-block;width:auto;max-width:520px;vertical-align:top}
@media (min-width: 992px){
  #waPlus .message .bubble, 
  #waPlus .bubble{max-width:460px}
}
#waPlus .wa-attachments + .wa-text{margin-top:8px}
#waPlus .wa-cap{display:block;clear:both;margin:8px 0 0!important}
#waPlus .wa-meta{position:static;text-align:right;margin-top:6px;display:block;color:#6b7280;font-size:12px}
#waPlus .bubble{padding-bottom:0}

/* v1.5.4 meta right & bubble width */
#waPlus .bubble{position:relative;padding-bottom:18px}
@media (min-width: 992px){
  #waPlus .bubble{max-width: 460px}
}
#waPlus .wa-text{white-space:pre-wrap;word-break:break-word;margin:8px 0 0;font-size:14px;line-height:1.38}
#WA_META_ABS{position:absolute;right:10px;bottom:6px;margin-top:0;display:flex;gap:6px;align-items:center;color:#6b7280;font-size:12px;z-index:1}
#waPlus .wa-checks{opacity:.9}
#waPlus .wa-checks.read{color:#34B7F1;}
/* Doc & audio card polish */
#waPlus .wa-att--doc{display:flex;align-items:center;gap:8px;background:#eef2ff;border:1px solid #e0e7ff;border-radius:12px;padding:10px}
#waPlus .wa-att--doc a{text-decoration:none;display:flex;align-items:center}
#waPlus .wa-att__name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:260px}
#waPlus .wa-att--audio{background:#f1f5f9;border:1px solid #e5e7eb;border-radius:12px;padding:10px}


  #waPlus .wa-att--doc .wa-att__icon{font-size:18px;opacity:.75;margin-right:6px}
  #waPlus .wa-att--audio audio{width:100%;max-width:260px;display:block}
</style>

<style>
  /* Inside-icon composer */
  #waPlus .wa-inside{position:relative;overflow:visible;display:flex;align-items:center;gap:8px;background:#f1f5f9;border:1px solid #e5e7eb;border-radius:22px;padding:6px 10px}
  #waPlus .wa-input-text{height:32px;max-height:120px;border:none;background:transparent;box-shadow:none!important;resize:none;overflow:auto;padding-left:74px}
  #waPlus .wa-plus-inside{position:absolute;left:10px;top:50%;transform:translateY(-50%);width:24px;height:24px;border-radius:50%;background:#e2e8f0;display:flex;align-items:center;justify-content:center;font-weight:700;cursor:pointer;line-height:1}
  #waPlus .wa-inside-menu{position:absolute;bottom:42px;left:4px;min-width:240px;z-index:1060}
  #waPlus .wa-input, #waPlus .wa-wrap, #waPlus .wa-chat{overflow:visible !important}
  #waPlus .wa-inside-menu{display:none}
  #waPlus .wa-inside-menu.show{display:block}

</style>

<style>
  /* Pill-like composer */
  #waPlus .wa-bar{display:flex;align-items:center;gap:8px;background:#f1f5f9;border:1px solid #e5e7eb;border-radius:22px;padding:6px 8px;overflow:visible}
  #waPlus .wa-plus-btn{width:28px;height:28px;line-height:28px;border-radius:50%;border:none;background:#e2e8f0;display:inline-flex;align-items:center;justify-content:center;font-weight:600}
  #waPlus .wa-plus-btn span{display:inline-block;font-size:18px;margin-top:-2px}
  #waPlus .wa-input-text{height:32px;max-height:120px;border:none;background:transparent;box-shadow:none!important;resize:none;overflow:auto}
  #waPlus .wa-input-text:focus{outline:none;box-shadow:none}
  #waPlus .wa-send-btn{height:32px;padding:0 10px;display:inline-flex;align-items:center}
  #waPlus .wa-input{position:relative;overflow:visible}
  #waPlus .wa-composer .dropdown-menu{min-width:240px;z-index: 1060}
  #waPlus .wa-wrap, #waPlus .wa-chat, #waPlus .wa-input{overflow:visible !important}
</style>

<style>
  /* Composer inline layout */
  #waPlus .wa-composer{display:flex;align-items:center;gap:8px}
  #waPlus .wa-composer textarea.form-control{height:40px;max-height:160px;resize:none;overflow:auto}
  #waPlus .wa-composer .btn{height:40px;display:inline-flex;align-items:center}
  #waPlus .wa-composer .dropdown-menu{min-width:240px}
  /* Attachments inside bubbles */
  #waPlus .wa-attachments{margin-top:6px;display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:6px}
  #waPlus .wa-att{background:#f8fafc;border:1px solid #e5e7eb;border-radius:10px;padding:6px;display:flex;align-items:center;gap:8px;text-decoration:none;color:#0f172a}
  #waPlus .wa-att:hover{background:#eef2ff}
  #waPlus .wa-att--image{padding:0;overflow:hidden}
  #waPlus .wa-att--image img{display:block;max-width:240px;height:auto;border-radius:10px}
  #waPlus .wa-att--doc .wa-att__icon{font-size:18px;opacity:.8}
  #waPlus .wa-att--audio audio{width:220px;display:block}
</style>

<style>#waPlus /* Whatsapp Plus scoped styles to avoid global collisions */
#waPlus .wa-tabs .tab{border:none;background:#f1f5f9;color:#334155;border-radius:999px;padding:6px 12px;font-weight:600;cursor:pointer}#waPlus .wa-tabs .tab.active{background:#e2e8f0}#waPlus .wa-tabs .tab .tab-badge{margin-left:6px;background:#22c55e;color:#fff;border-radius:999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .wa-top{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#ece7df;border-bottom:1px solid #e5e7eb}#waPlus .wa-top-left{display:flex;align-items:center;gap:10px}#waPlus .wa-top .wa-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;background:#e2e8f0;color:#334155}#waPlus .wa-top .wa-title{font-weight:700}#waPlus .wa-body-search-inline{display:flex;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid #eef2f7;background:#fafafa}#waPlus .wa-thread.unread .t-title{font-weight:800}#waPlus .t-badge{display:inline-block;margin-left:8px;border-radius:9999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .t-badge-green{background:#22c55e;color:#fff}
</style>

<?php $__rt_mode = get_option('wp_realtime_mode') ?: 'sse'; $__rt_poll = (int)(get_option('wp_poll_interval_sec') ?: 3); ?>
<?php if (!function_exists('wp_avatar_letter')) { function wp_avatar_letter($name,$phone){ $s=trim($name?:$phone); $ch=mb_substr($s,0,1,'UTF-8'); return mb_strtoupper($ch,'UTF-8'); } } ?>
<style>#waPlus /* WhatsApp Web benzeri basit tema */
  .wa-wrap{height:calc(100vh - 160px);display:flex;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;background:#fff}#waPlus .wa-left{width:32%;min-width:280px;border-right:1px solid #e5e7eb;background:#f8fafc;display:flex;flex-direction:column}#waPlus .wa-left .wa-head{padding:12px 14px;font-weight:600;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;gap:8px}#waPlus .wa-left .wa-list{overflow:auto}#waPlus .wa-thread{display:flex;align-items:center;gap:12px;padding:10px 12px;border-bottom:1px solid #eef2f7;text-decoration:none}#waPlus .wa-thread.active{background:#e8f0fe}#waPlus .wa-thread .t-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;background:#e2e8f0;color:#334155}#waPlus .wa-thread .t-wrap{flex:1;min-width:0}#waPlus .wa-thread .t-title{font-weight:600}#waPlus .wa-thread.unread .t-title{font-weight:800}#waPlus .wa-thread.unread{background:#fff7ed}#waPlus .wa-thread .t-sub{font-size:12px;color:#64748b;margin-top:2px}#waPlus .wa-thread .t-sub .fa{margin-right:6px}#waPlus .wa-thread .t-last{font-size:12px;color:#94a3b8;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#waPlus .wa-thread .t-time{font-size:12px;color:#94a3b8;white-space:nowrap}#waPlus .wa-left .wa-search{padding:10px 12px;border-bottom:1px solid #eef2f7}#waPlus .wa-body-search{display:flex;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid #eef2f7}#waPlus .t-badge{display:inline-block;margin-left:8px;background:#ef4444;color:#fff;border-radius:9999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .wa-thread{display:flex;align-items:flex-start;gap:8px;padding:10px 12px;border-bottom:1px solid #eef2f7}#waPlus .wa-thread .t-wrap{flex:1;min-width:0}#waPlus .wa-thread .t-title{font-weight:600}#waPlus .wa-thread.unread .t-title{font-weight:800}#waPlus .wa-thread.unread{background:#fff7ed}#waPlus .wa-thread .t-sub{font-size:12px;color:#64748b;margin-top:2px}#waPlus .wa-thread .t-sub .fa{margin-right:6px}#waPlus .wa-thread .t-last{font-size:12px;color:#94a3b8;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#waPlus .wa-thread .t-time{font-size:12px;color:#94a3b8;white-space:nowrap}#waPlus .wa-left .wa-search{padding:10px 12px;border-bottom:1px solid #eef2f7}#waPlus .wa-body-search{display:flex;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid #eef2f7}#waPlus .t-badge{display:inline-block;margin-left:8px;background:#ef4444;color:#fff;border-radius:9999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .wa-thread .wa-sub{font-size:12px;color:#64748b;margin-top:2px}#waPlus .wa-thread .wa-last{font-size:12px;color:#94a3b8;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#waPlus .wa-chat{flex:1;display:flex;flex-direction:column;background:#e5ddd5}#waPlus .wa-chat .wa-top{display:flex;align-items:center;gap:12px;}#waPlus .wa-top .wa-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;background:#e2e8f0;color:#334155}#waPlus .wa-top .wa-title{font-weight:700}#waPlus .wa-top .wa-subtitle{font-size:12px;color:#64748b}#waPlus .wa-top{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:#ece7df;border-bottom:1px solid #e5e7eb}#waPlus .wa-top-left{display:flex;align-items:center;gap:10px}#waPlus .wa-top .wa-avatar{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;background:#e2e8f0;color:#334155}#waPlus .wa-top .wa-title{font-weight:700}#waPlus .wa-top-actions .btn.btn-icon{padding:6px 8px}#waPlus .wa-body-search-inline{display:flex;gap:6px;align-items:center;padding:8px 12px;border-bottom:1px solid #eef2f7;background:#fafafa}#waPlus .wa-tabs{display:flex;gap:8px;padding:8px 12px;border-bottom:1px solid #eef2f7;background:#fafafa}#waPlus .wa-tabs .tab{border:none;background:#f1f5f9;color:#334155;border-radius:999px;padding:6px 12px;font-weight:600;cursor:pointer}#waPlus .wa-tabs .tab.active{background:#e2e8f0}#waPlus .wa-tabs .tab .tab-badge{margin-left:6px;background:#22c55e;color:#fff;border-radius:999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .t-badge{display:inline-block;margin-left:8px;border-radius:9999px;padding:0 8px;font-size:11px;line-height:18px}#waPlus .t-badge-green{background:#22c55e;color:#fff}#waPlus .wa-top .wa-subtitle .fa{margin-right:6px}#waPlus background:#f0f2f5;border-bottom:1px solid #e5e7eb;padding:10px 14px;display:flex;align-items:center;gap:10px}
  .wa-chat .wa-top .wa-title{font-weight:600}#waPlus .wa-chat .wa-body{flex:1;overflow:auto;padding:18px;background:#efeae2; background-image: radial-gradient(rgba(0,0,0,0.03) 1px, transparent 0), radial-gradient(rgba(0,0,0,0.03) 1px, transparent 0); background-position: 0 0, 12px 12px; background-size: 24px 24px  ;}#waPlus .wa-msg{margin:6px 0;display:flex}#waPlus .wa-msg .bubble{max-width:70%;padding:8px 10px;border-radius:8px;position:relative;background:#fff}#waPlus .wa-msg.out{justify-content:flex-end}#waPlus .wa-msg.out .bubble{background:#d9fdd3}#waPlus .wa-meta{font-size:11px;opacity:.7;margin-left:6px;display:inline-flex;align-items:center;gap:6px}#waPlus .wa-checks{font-family:Arial; font-size:13px}#waPlus .wa-input{background:#f0f2f5;border-top:1px solid #e5e7eb;padding:10px}#waPlus .wa-input form{display:flex;gap:8px}#waPlus .wa-input textarea{height:44px;resize:none}#waPlus .wa-thread{display:flex;gap:10px;align-items:center;padding:10px 12px;border-bottom:1px solid #eef2f7;cursor:pointer}#waPlus .wa-thread:hover{background:#eef2f7}#waPlus .wa-thread.active{background:#e7f3ff}#waPlus .wa-thread .t-phone{font-weight:600}#waPlus .wa-thread .t-time{margin-left:auto;font-size:12px;opacity:.6}#waPlus .wa-empty{display:flex;align-items:center;justify-content:center;color:#777;flex:1}#waPlus .wa-typing{font-size:12px;opacity:.75;margin-left:6px}

/* v1.5.7 image max-height + caption spacing */
#waPlus .wa-att--image img{max-width:100%!important;width:auto!important;height:auto!important;max-height:420px!important;border-radius:12px}
@media (max-width: 576px){
  #waPlus .wa-att--image img{max-height:300px!important}
}
#waPlus .wa-attachments + .wa-cap{margin-top:8px!important}

/* v1.5.8 alignment + bubble width clamp */
#waPlus .wa-msg{padding:6px 16px; display:flex}
#waPlus .wa-msg.in{justify-content:flex-start}
#waPlus .wa-msg.out{justify-content:flex-end}
#waPlus .wa-msg .bubble{display:inline-block;width:auto;max-width:min(65vw, 460px);margin:0 10px;vertical-align:top}
#waPlus .wa-attachments + .wa-cap{margin-top:8px!important}

/* composer queue badges */
#waPlus .wa-queue{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
#waPlus .wa-chip{display:inline-flex;align-items:center;gap:6px;background:#e5f0ff;border:1px solid #cfe0ff;border-radius:999px;padding:4px 8px;font-size:12px}
#waPlus .wa-chip .x{cursor:pointer;opacity:.7}

/* v1.5.9 edge spacing symmetry */
#waPlus .wa-chat{padding-left:16px;padding-right:16px}
#waPlus .wa-msg.in .bubble{margin-left:6px;margin-right:10px}
#waPlus .wa-msg.out .bubble{margin-right:6px;margin-left:10px}

/* queue status line */
#waPlus .wa-status{font-size:12px;color:#475569;margin-top:6px}

/* v1.6.0 attachments grid responsive */
#waPlus .wa-attachments{display:block}
#waPlus .wa-attachments--single{display:inline-block;max-width:100%}
#waPlus .wa-attachments--grid{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;max-width:100%}
@media (max-width: 900px){
  #waPlus .wa-attachments--grid{grid-template-columns:repeat(2,1fr)}
}
#waPlus .wa-attachments--grid .wa-att{margin:0}
#waPlus .wa-attachments--grid .wa-att--image img{width:100%!important;height:auto!important;max-height:260px!important;object-fit:cover;border-radius:12px}

/* status visibility */
#waPlus .wa-status{display:block;font-size:12px;color:#475569;margin-top:6px}

/* v1.6.5 meta bottom-right & spacing */
#waPlus .wa-meta{display:block!important;clear:both!important;text-align:right!important;margin-top:8px!important;line-height:1.2!important;font-size:12px}
#waPlus .wa-attachments + .wa-meta,
#waPlus .wa-cap + .wa-meta,
#waPlus .wa-text + .wa-meta{margin-top:8px!important}
#waPlus .wa-attachments--single{display:block!important}
</style>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="wa-wrap">
          <div class="wa-left">
  <div id="waTabs" class="wa-tabs">    <button data-filter="all" class="tab active">Tümü</button>    <button data-filter="unread" class="tab">Okunmamış      <span class="tab-badge"><?php $u=0; foreach($threads as $_t){ if(!empty($_t['unread'])) $u+=$_t['unread']; } echo $u; ?></span>    </button>  </div>
          <div class="wa-search">
            <input id="waListSearch" type="text" class="form-control" placeholder="Ara: isim / numara..."/>
          </div>
    <?php if (!empty($accounts)): ?>
      <div class="wa-acc" style="padding:8px 12px;">
        <label style="font-size:12px;color:#64748b;margin-right:6px;">Hesap:</label>
        <select id="waAccount" class="form-control" style="display:inline-block;width:auto;max-width:280px;">
          <?php foreach($accounts as $a): ?>
            <option value="<?= (int)$a['id'] ?>" <?= (!empty($active_acc) && $a['id']==$active_acc)?'selected':'' ?>>
              <?= html_escape($a['label'] ?: ($a['qr_device'] ?: ('Hesap #'.$a['id']))) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <script>
        document.addEventListener('DOMContentLoaded', function(){
          var sel=document.getElementById('waAccount'); if(!sel) return;
          sel.addEventListener('change', function(){
            var url=new URL(window.location.href);
            url.searchParams.set('acc', this.value);
            window.location.href=url.toString();
          });
        });
        </script>
      </div>
    <?php endif; ?>
    
            <div class="wa-head">
              <i class="fa fa-whatsapp"></i> <?php echo _l('whatsapp_plus_messages'); ?>
            </div>
            <div class="wa-list">
              <?php if (empty($threads)): ?>
                <div class="p-3 text-muted"><?php echo _l('whatsapp_plus_no_threads'); ?></div>
              <?php else: ?>
                <?php foreach($threads as $t): $t_phone = $t['phone_e164'] ?? $t['phone']; $t_name = !empty($t['contact_name']) ? $t['contact_name'] : $t_phone; ?>
                  <?php $isActive = ($active_phone && ($active_phone == $t_phone || $active_phone == $t['phone'])); ?>
                  <a class="wa-thread <?php echo ($isActive ? 'active ' : '') . (!empty($t['unread']) ? 'unread' : ''); ?>" href="<?php echo admin_url('whatsapp_plus?acc='.(int)($active_acc ?: 0).'&phone='.rawurlencode($t_phone)); ?>"><div class="t-avatar"><?php echo html_escape(wp_avatar_letter($t_name, $t_phone)); ?></div><div class="t-wrap"><div class="t-title"><?php echo html_escape($t_name); ?><?php if(!empty($t['unread'])): ?><span class="t-badge t-badge-green"><?php echo (int)$t['unread']; ?></span><?php endif; ?></div><div class="t-sub"><i class="fa fa-phone"></i> <?php echo html_escape($t_phone); ?></div><div class="t-last"><?php echo html_escape(isset($t["last_body"]) && $t["last_body"]!==null ? mb_strimwidth($t["last_body"],0,80,"…","UTF-8") : ""); ?></div></div><div class="t-time"><?php echo _dt($t["created_at"]); ?></div></a>
                <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>

          <div class="wa-chat">
            <?php if (empty($active_phone)): ?>
              <div class="wa-empty"><?php echo _l('whatsapp_plus_no_thread_selected'); ?></div>
            <?php else: ?>
              <div class="wa-top">  <div class="wa-top-left">    <div class="wa-avatar"><?php echo html_escape(wp_avatar_letter($active_contact_name, $active_phone)); ?></div>    <div class="wa-top-info">      <div class="wa-title"><?php echo html_escape(!empty($active_contact_name)?$active_contact_name:($active_phone ?: "")); ?></div>      <div class="wa-subtitle"><i class="fa fa-phone"></i> <?php echo html_escape($active_phone ?: ""); ?></div>    </div>  </div>  <div class="wa-top-actions">    <button id="waToggleSearch" type="button" class="btn btn-light btn-icon" title="Ara"><i class="fa fa-search"></i></button>  </div></div><div class="wa-body-search-inline" id="waBodySearchInline" style="display:none;">  <input id="waBodySearch" type="text" class="form-control" placeholder="Sohbette ara...">  <button id="waBodyFind" class="btn btn-light btn-icon"><i class="fa fa-search"></i></button>  <button id="waBodyClear" class="btn btn-light btn-icon"><i class="fa fa-times"></i></button></div>
              <div class="wa-body-search" style="display:none">
                <input id="waBodySearch" type="text" class="form-control" placeholder="Sohbette ara..."/> <button id="waBodyFind" class="btn btn-light"><i class="fa fa-search"></i></button> <button id="waBodyClear" class="btn btn-light"><i class="fa fa-times"></i></button>
              </div>
              <div id="waBody" class="wa-body">
              <?php foreach ($conversation as $m) { ?>
  <div class="wa-msg <?php echo ((($m['direction'] ?? '') === 'out') ? 'out' : 'in'); ?>" data-id="<?php echo (int)($m['id'] ?? 0); ?>">
    <div class="bubble">
      <?php
      // Gönderen etiketi
      $meta = json_decode($m['meta_json'] ?? 'null', true);
      if (!is_array($meta)) { $meta = []; }
      $senderPhone = $meta['sender_e164'] ?? ($m['sender'] ?? ($m['phone_e164'] ?? ($m['phone'] ?? '')));
      $senderName  = $meta['sender_name'] ?? ($m['sender_name'] ?? ($m['contact_name'] ?? ''));
      $senderLabel = '';
      if (($m['direction'] ?? 'in') === 'in') {
        if (!empty($___isGroup)) {
          $base = ($senderName !== '') ? $senderName : $senderPhone;
          $senderLabel = trim($base . ($senderPhone ? ' ('.$senderPhone.')' : ''));
        } else {
          $senderLabel = ($senderName !== '') ? $senderName : ($active_contact_name ?? '');
        }
      }
      if ($senderLabel !== '') {
        echo '<div class="wa-sender">'.html_escape($senderLabel).'</div>';
      }

      // Medyalar
      $CI =& get_instance();
      $CI->load->model('whatsapp_plus/Whatsapp_plus_model');
      $__media = $CI->Whatsapp_plus_model->get_media_by_message((int)($m['id'] ?? 0));
      if (!is_array($__media)) { $__media = []; }

      if (count($__media) > 0) {
        echo '<div class="wa-attachments wa-attachments--single">';
        foreach ($__media as $__f) {
          $__raw  = (string)($__f['file_path'] ?? '');
          $__url  = (string)($__f['url'] ?? '');
          $__path = $__raw !== '' ? base_url($__raw) : ($__url ?: '');
          $__type = strtolower((string)($__f['type'] ?? ''));
          $__mime = strtolower((string)($__f['mime'] ?? ''));
          $__name = trim((string)($__f['filename'] ?? ''));
          if ($__name === '') {
            $p = $__raw !== '' ? $__raw : $__url;
            $__name = $p ? basename(parse_url($p, PHP_URL_PATH) ?: $p) : 'dosya';
          }

          if (strpos($__type,'image') !== false || strpos($__mime,'image/') === 0) {
            echo '<div class="wa-att wa-att--image">';
            if ($__path !== '') {
              echo '<a href="'.html_escape($__path).'" download="'.html_escape($__name).'"><img src="'.html_escape($__path).'" alt="'.html_escape($__name).'"></a>';
            } else {
              echo '<div class="wa-att wa-att--missing">Dosya bulunamadı</div>';
            }
            echo '</div>';
          } else {
            echo '<div class="wa-att wa-att--doc">';
            if ($__path !== '') {
              echo '<a href="'.html_escape($__path).'" download="'.html_escape($__name).'"><span class="wa-att__icon"><i class="fa fa-file-text-o"></i></span><span class="wa-att__name">'.html_escape($__name).'</span></a>';
            } else {
              echo '<div class="wa-att__name">'.html_escape($__name).'</div>';
            }
            echo '</div>';
          }
        }
        echo '</div>';

        // Caption: medya varsa body/caption tek yerde
        $caption = trim((string)($m['body'] ?? ''));
        if ($caption === '') {
          foreach ($__media as $__f_cap) {
            if (!empty($__f_cap['caption'])) { $caption = (string)$__f_cap['caption']; break; }
          }
        }
        if ($caption !== '') {
          echo '<div class="wa-cap">'.nl2br(html_escape($caption)).'</div>';
        }
      } else {
        // Medya yoksa normal metin
        if (!empty($m['body'])) {
          echo '<div class="wa-text">'.nl2br(html_escape($m['body'])).'</div>';
        }
      }
      ?>
      <div class="wa-meta">
        <span><?php echo _dt($m['created_at']); ?></span>
        <?php if ((($m['direction'] ?? '') === 'out')) { $st = $m['status'] ?? ''; ?>
          <span class="wa-checks <?php echo ($st === 'read') ? 'read' : ''; ?>">
            <?php echo ($st === 'read') ? '✔✔' : (($st === 'delivered') ? '✔✔' : '✔'); ?>
          </span>
        <?php } ?>
      </div>
    </div>
  </div>
<?php } ?>

              </div>
              
              
<div class="wa-input">
  <?php echo form_open_multipart(admin_url('whatsapp_plus/send'), ['id'=>'waSendForm','class'=>'wa-composer wa-bar wa-inside']); ?>

    <div class="wa-plus-inside" id="waPlusAddBtn" aria-haspopup="true" aria-expanded="false">+</div>
    <button type="button" class="wa-mic-inside" id="waHoldVoiceBtn" title="Basılı tutup ses gönder"><i class="fa fa-microphone"></i></button>

    <div class="wa-inside-menu" id="waPlusMenu">
      <a class="dropdown-item wa-choose" data-type="image" href="#">Resim yükle</a>
      <a class="dropdown-item wa-choose" data-type="document" href="#">Belge yükle</a>
      <a class="dropdown-item wa-choose" data-type="audio" href="#">Ses dosyası</a>
      <a class="dropdown-item wa-voice"  data-type="voice" href="#">Ses kaydı yap</a>
      <div class="dropdown-divider"></div>
      <a class="dropdown-item wa-event" data-type="event" href="#">Etkinlik oluştur (ICS)</a>
    </div>

    <input type="hidden" name="to" value="<?php echo html_escape($active_phone); ?>"/>
    <input type="hidden" name="attachment_type" id="waAttachType" value="none"/>
    <input type="hidden" name="caption" id="waCaption"/>

    <textarea class="form-control wa-input-text flex-grow-1" name="text" rows="1" placeholder="<?php echo _l('message'); ?>" id="waSendInput"></textarea>
    <button class="btn btn-success wa-send-btn" type="submit" id="waSendBtn"><i class="fa fa-paper-plane"></i> <?php echo _l('send'); ?></button>
    <input type="file" name="attachment" id="waAttachment" multiple style="display:none !important" multiple/>

  <input type="hidden" name="account_id" value="<?= (int)($active_acc ?? 0) ?>"/>
  <?php echo form_close(); ?>
    <div id="waStatus" class="wa-status muted"></div>
    <div id="waQueue" class="wa-queue mt-1"></div>
  <small class="text-muted d-block mt-2 support-note">Destek: resim, belge, ses dosyası, ses kaydı ve ICS etkinlik paylaşımı. Yüklenen dosyalar <code>modules/whatsapp_plus/storage/media</code> altında saklanır.</small>
</div>


              <script>
              (function(){
                var root = document.getElementById('waPlus') || document;
                function qs(s){ return root.querySelector(s); }
                var attach = qs('#waAttachment');
                var typeEl = qs('#waAttachType');
                var captionEl = qs('#waCaption');
                var callEl = qs('#waCallEnabled');
                var form = qs('#waSendForm');

                // Choose handlers
                root.querySelectorAll('.wa-choose').forEach(function(a){
                 a.addEventListener('click', function(e){
                  e.preventDefault();
                  var t = this.getAttribute('data-type') || 'document';
                  typeEl.value = t;
                  if (t === 'image'){ attach.setAttribute('accept','image/*'); }
                  else if (t === 'audio' || t === 'voice'){ attach.setAttribute('accept','audio/*'); }
                  else { attach.removeAttribute('accept'); }
                  attach.click();
                });
              });

                // Event creation (ICS)
                var eventBtn = root.querySelector('.wa-event');
                if (eventBtn){
                  eventBtn.addEventListener('click', function(e){
                    e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      });
                }
                root.querySelector('#waEventSendBtn')?.addEventListener('click', function(){
                  typeEl.value = 'event';
                  captionEl.value = qs('#waEventCaption').value || '';
                  try{ window.onbeforeunload = null; if (window.jQuery) jQuery(window).off('beforeunload'); }catch(e){}; form.submit();
                });

                // Voice record (simple MediaRecorder)
                var voiceBtn = root.querySelector('.wa-voice');
                if (voiceBtn && navigator.mediaDevices && window.MediaRecorder){
                  voiceBtn.addEventListener('click', async function(e){
                    e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      var rec = new MediaRecorder(stream);
                      var chunks = [];
                      rec.ondataavailable = e => chunks.push(e.data);
                      rec.onstop = e => {
                        var blob = new Blob(chunks, { type: 'audio/webm' });
                        var file = new File([blob], 'voice_note.webm', { type: 'audio/webm' });
                        var dt = new DataTransfer();
                        dt.items.add(file);
                        attach.files = dt.files;
                        try{ window.onbeforeunload = null; if (window.jQuery) jQuery(window).off('beforeunload'); }catch(e){}; form.submit();
                      };
                      rec.start();
                      setTimeout(()=>{ rec.stop(); stream.getTracks().forEach(t=>t.stop()); }, 5000);
                      alert('Ses kaydı başladı (5 sn). Kayıt otomatik bitecek.');
                    } catch(err){
                      alert('Mikrofon izni gerekli: ' + err);
                    }
                  });
                }

                
  // Auto-size textarea up to its max-height
  var ta = qs('textarea[name="text"]');
  if (ta){
    ta.addEventListener('input', function(){
      this.style.height = '40px';
      this.style.height = Math.min(this.scrollHeight, 140) + 'px';
    });
  }

                // On file selected, submit immediately
                
                
                // Submit handler: if attachment selected and text typed, use it as caption (like WhatsApp)
                form.addEventListener('submit', function(e){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
                  try{ window.onbeforeunload = null; if (window.jQuery) jQuery(window).off('beforeunload'); }catch(err){}
                  var t = typeEl.value;
                  var ta = qs('textarea[name="text"]');
                  if (t && t !== 'none' && ta && ta.value.trim() !== ''){
                    captionEl.value = ta.value.trim();
                    // keep textarea content (optional). If you don't want duplicate log, you can clear: ta.value = '';
                  }
                });


                // Toggle inside dropdown manually to avoid positioning issues
                var plusInside = qs('#waPlusAddBtn');
                var menuInside = root.querySelector('.wa-inside-menu');
                if (plusInside && menuInside){
                  plusInside.addEventListener('click', function(e){
                    e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      });
                  document.addEventListener('click', function(e){
                    if (!menuInside.contains(e.target) && e.target !== plusInside){
                      menuInside.classList.remove('show');
                    }
                  });
                }

                // On file selected, DO NOT auto-submit; let user press Send
                if (attach){
                  attach.addEventListener('change', function(){
                    // nothing; preview could be added here if needed
                  });
                }

              })();
              </script>

            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>





<script>
(function(){
  var root = document.getElementById('waPlus'); if(!root) return;

  // Prevent hash-only anchors inside waPlus from changing URL or interfering with CRM
  root.addEventListener('click', function(e){
    var a = e.target.closest('a');
    if (!a) return;
    var href = (a.getAttribute('href')||'').trim();
    if (href === '' || href === '#'){
      e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      return false;
    }
  });
  function qs(s){ return root.querySelector(s); }
  function qsa(s){ return Array.prototype.slice.call(root.querySelectorAll(s)); }

  // Tabs & list search
  var tabs = qsa('#waTabs .tab');
  function applyFilter(){
    var active = qs('#waTabs .tab.active'); var mode = active ? active.getAttribute('data-filter') : 'all';
    qsa('.wa-thread').forEach(function(el){ var unread = el.classList.contains('unread'); el.style.display = (mode==='all'||(mode==='unread'&&unread)) ? '' : 'none'; });
  }
  tabs.forEach(function(t){ t.addEventListener('click', function(){ tabs.forEach(function(x){x.classList.remove('active');}); this.classList.add('active'); applyFilter(); }); });
  applyFilter();
  var listInput = qs('#waListSearch'); if(listInput){ listInput.addEventListener('input', function(){ var q=this.value.toLowerCase(); qsa('.wa-thread').forEach(function(el){ el.style.display = el.innerText.toLowerCase().indexOf(q)>=0 ? '' : 'none'; }); }); }

  // Toggle inline search
  var toggle = qs('#waToggleSearch'), inlineBox = qs('#waBodySearchInline');
  if (toggle && inlineBox){ toggle.addEventListener('click', function(){ var show = inlineBox.style.display==='none'||!inlineBox.style.display; inlineBox.style.display = show ? 'flex' : 'none'; if(show){ var inp = qs('#waBodySearch'); if(inp) inp.focus(); } }); }

  // Body search
  function clearMarks(){ qsa('#waBody mark').forEach(function(m){ m.outerHTML=m.textContent; }); }
  function doSearch(){ var input=qs('#waBodySearch'); var q=input?input.value.trim():''; clearMarks(); if(!q) return; var first=null, re=new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'); qsa('#waBody .wa-msg .bubble').forEach(function(b){ var txt=b.textContent; if(!re.test(txt)) return; b.innerHTML = txt.replace(re,'<mark>$1</mark>'); if(!first) first=b; }); if(first){ first.scrollIntoView({behavior:'smooth', block:'center'}); } }
  var bodyFind=qs('#waBodyFind'), bodyClear=qs('#waBodyClear'), bodyInput=qs('#waBodySearch');
  if(bodyFind) bodyFind.addEventListener('click', doSearch);
  if(bodyInput) bodyInput.addEventListener('keydown', function(e){ if(e.key==='Enter') doSearch(); });
  if(bodyClear) bodyClear.addEventListener('click', function(){ if(bodyInput) bodyInput.value=''; clearMarks(); });

  // --- Polling-only realtime (stable) ---
  var body=qs('#waBody'); if(!body) return;
  var activePhone = '<?php echo html_escape($active_phone); ?>';
  var pollEvery = (parseInt('<?php echo (int)(get_option('wp_poll_interval_sec') ?: 3); ?>',10)||3)*1000;
  var seen = new Set(); qsa('#waBody .wa-msg').forEach(function(el){ var id=parseInt(el.getAttribute('data-id')||'0',10); if(id>0) seen.add(id); });
  function lastId(){ var max=0; seen.forEach(function(v){ if(v>max) max=v; }); return max; }
  function appendMsg(m){
    if(!m || !m.id){ return; }
  var existing = document.querySelector('#waBody .wa-msg[data-id="'+m.id+'"]');
  if(existing){
    existing.classList.remove('pending');
    var meta = existing.querySelector('.wa-meta');
    if (meta) { var tks = meta.querySelector('.wa-checks') || meta.querySelector('.wa-tick') || meta.lastElementChild;
    if (tks) { window.__waSetChecks__(tks, m.status || 'sent'); }
    }
// allow attachments refresh if provided as simple html
    if(m.attachments_html){
       var at = existing.querySelector('.wa-attachments');
       if(at){ at.outerHTML = m.attachments_html; } else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){}
         var bub = existing.querySelector('.bubble'); if(bub){ var tmp=document.createElement('div'); tmp.innerHTML=m.attachments_html; if(tmp.firstElementChild){ bub.insertBefore(tmp.firstElementChild, bub.lastElementChild); }}
       }
    }
    return;
  }
  seen.add(m.id);
    seen.add(m.id);
    var wrap=document.createElement('div'); wrap.className='wa-msg '+(m.direction==='out'?'out':'in'); wrap.setAttribute('data-id', m.id);
    try{ if(window.__waPending__ && window.__waPending__.map[m.id]){ window.__waPending__.remove(window.__waPending__.map[m.id]); delete window.__waPending__.map[m.id]; } }catch(e){}
    var bubble=document.createElement('div'); bubble.className='bubble';
    // Sender label (live): groups => Name (+90...), singles => Name
    try{
      if(m.direction==='in'){
        var metaJson=null; try{ metaJson = m.meta_json ? JSON.parse(m.meta_json) : null; }catch(e){}
        var senderPhone = (metaJson && metaJson.sender_e164) || m.sender || null;
        var senderName  = (metaJson && metaJson.sender_name) || m.sender_name || m.contact_name || '';
        var isGroup = (typeof activePhone==='string' && activePhone.indexOf('g:')===0);
        var label = '';
        if(isGroup){ label = (senderName || senderPhone) + (senderPhone ? ' ('+senderPhone+')' : ''); }
        else { label = senderName || ''; }
        if(label){ var lab=document.createElement('div'); lab.className='wa-sender'; lab.textContent=label; bubble.appendChild(lab); }
      }
    }catch(e){}
    var d1=document.createElement('div'); var __t=(m&&typeof m.body==='string')?m.body:((m&&m.body!=null)?'':'' ); d1.textContent=(m.has_caption? '': __t);
    if(m.attachments_html){ try{ var tmp=document.createElement('div'); tmp.innerHTML=m.attachments_html; bubble.appendChild(tmp.firstElementChild); }catch(e){} }
    var meta=document.createElement('div'); meta.className='wa-meta';
    var sp=document.createElement('span'); sp.textContent=m.created_at_fmt || m.created_at; meta.appendChild(sp);
    if (m.direction === 'out') { var c = document.createElement('span'); c.className = 'wa-checks';  window.__waSetChecks__(c, m.status || 'sent'); meta.appendChild(c); }
bubble.appendChild(d1); bubble.appendChild(meta); wrap.appendChild(bubble); body.appendChild(wrap); body.scrollTop = body.scrollHeight;
  }
  function pollOnce(){
    var url = '<?php echo admin_url("whatsapp_plus/poll_messages"); ?>?acc=<?php echo (int)($active_acc ?? 0); ?>&phone='+encodeURIComponent(activePhone)+'&after_id='+lastId();
    fetch(url,{credentials:'same-origin'}).then(function(r){ return r.json(); }).then(function(res){ 
(res.messages||[]).forEach(appendMsg);
// Apply late-arriving media attachments
if(res.media_updates && Array.isArray(res.media_updates)){
  res.media_updates.forEach(function(mu){
    try{
      var msgEl = document.querySelector('.wa-msg[data-id="'+mu.id+'"] .bubble');
      if(msgEl && mu.attachments_html){
        if(!msgEl.querySelector('.wa-attachments')){
          var tmp = document.createElement('div');
          tmp.innerHTML = mu.attachments_html;
          if(tmp.firstElementChild){ msgEl.insertBefore(tmp.firstElementChild, msgEl.firstChild); }
        }
        if(mu.has_caption){
          var t = msgEl.querySelector('.wa-text');
          if(t){ t.textContent=''; }
        }
      }
    }catch(e){}
  });
}
 }).catch(function(){});
  }
  setInterval(pollOnce, pollEvery);

  // --- AJAX SEND ---
  var form = qs('#waSendForm'), inputMsg = qs('#waSendInput'), btn = qs('#waSendBtn');
  if(form && inputMsg){
    form.addEventListener('submit', function(e){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
      e.preventDefault();
      var txt = (inputMsg && inputMsg.value) ? inputMsg.value.trim() : '';

      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      if(!txt) return;
      if(btn){ btn.disabled=true; }
      var data = new FormData(form);
      fetch(form.action, {method:'POST', body:data, credentials:'same-origin'}).then(function(r){ return r.json(); }).then(function(res){
        if(btn){ btn.disabled=false; }
        if(res && res.ok){
          try{ window.__waStatus__&&__waStatus__.set('Gönderildi ✓','ok'); __waStatus__.hide(1500);}catch(e){}
          if(res.message && window.__waPending__){ window.__waPending__.map[res.message.id] = pendingEl; if(pendingEl){ /* keep until real bubble arrives */ } }
          inputMsg.value=''; // append immediately (optimistic)
          if(res.message){ appendMsg(res.message); }
          // fallback: poll once
          pollOnce();
        } else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){}
          // optional: show toast
        }
      }).catch(function(){ if(btn){ btn.disabled=false; } try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){} }).finally(function(){ try{ /* safety */ if(window.__waStatus__) __waStatus__.hide(3000); }catch(e){} });
    });
  }
})();
</script>

<script>
(function(){
  var root = document.getElementById('waPlus') || document;
  function qs(s){ return root.querySelector(s); }
  function qsa(s){ return Array.prototype.slice.call(root.querySelectorAll(s)); }
  function ensureDataPhones(){
    qsa('.wa-thread').forEach(function(el){
      if(!el.getAttribute('data-phone')){
        var sub = el.querySelector('.t-sub'); if(sub){ var m=(sub.textContent||'').match(/[+\d]+/); if(m){ el.setAttribute('data-phone', m[0]); } }
      }
    });
  }
  function renderThread(t){
    var list = qs('.wa-list'); if(!list) return;
    var phone = (t.phone_e164||t.phone||'').toString();
    if(!phone) return;
    ensureDataPhones();
    var sel = '.wa-thread[data-phone="'+phone+'"]';
    var el = root.querySelector(sel);
    if(!el){
      el = document.createElement('a');
      el.className='wa-thread';
      el.setAttribute('data-phone', phone);
      el.href = '<?php echo admin_url("whatsapp_plus?phone="); ?>'+encodeURIComponent(phone);
      el.innerHTML = '<div class="t-avatar">+</div><div class="t-wrap"><div class="t-title"></div><div class="t-sub"><i class="fa fa-phone"></i> '+phone+'</div><div class="t-last"></div></div><div class="t-time"></div>';
      list.insertBefore(el, list.firstChild);
    }
    var name = (t.contact_name||phone).toString();
    if (typeof t.id !== 'undefined') { el.setAttribute('data-id', parseInt(t.id||0,10)); }
    var unread = parseInt(t.unread||0,10);
    var lastBody = (t.last_body||'').toString();
    var createdAt = (t.created_at_fmt||t.created_at||'').toString();
    var title = el.querySelector('.t-title');
    if(title){
      title.textContent = name;
      var b = title.querySelector('.t-badge'); if(b) b.remove();
      if(unread>0){ var bb=document.createElement('span'); bb.className='t-badge t-badge-green'; bb.textContent = unread; title.appendChild(bb); el.classList.add('unread'); } else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){} el.classList.remove('unread'); }
    }
    var last = el.querySelector('.t-last'); if(last) last.textContent = lastBody;
    var time = el.querySelector('.t-time'); if(time) time.textContent = createdAt;
    // Keep unread on top
    sortListUnreadFirst();
    enforceCurrentFilter();
  }
  function pollThreads(){
    fetch('<?php echo admin_url("whatsapp_plus/poll_threads"); ?>?acc=<?php echo (int)($active_acc ?? 0); ?>', {credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(res){ (res.threads||[]).forEach(renderThread); })
      .catch(function(){});
  }
  var body = qs('#waBody');
  if(body){
    var obs = new MutationObserver(function(){ pollThreads(); });
    obs.observe(body, {childList:true});
  }
  var interval = (parseInt('<?php echo (int)(get_option("wp_poll_interval_sec") ?: 3); ?>',10)||3)*1000;
  setInterval(pollThreads, Math.max(interval, 3000));
  setTimeout(pollThreads, 500);
})();
</script>


<script>
(function(){
  function qs(s,c){ return (c||document).querySelector(s); }
  function qsa(s,c){ return Array.prototype.slice.call((c||document).querySelectorAll(s)); }

  function normPhone(x){
    try { x = decodeURIComponent(x || ''); } catch(e){}
    if (!x) return '';
    return (''+x).replace(/\s+/g,'').replace(/^00/, '+'); // basic normalize
  }

  var base = (typeof admin_url !== 'undefined') ? admin_url : '/';

  // CSRF token (Perfex/CI)
  var csrfName = '<?php echo $this->security->get_csrf_token_name(); ?>';
  var csrfHash = '<?php echo $this->security->get_csrf_hash(); ?>';

  function api(u){ return base.replace(/\/$/,'') + '/' + u.replace(/^\//,''); }

  // add Önemliler tab
  var tabs = qs('#waTabs');
  if (tabs && !qs('button[data-filter="important"]', tabs)){
    var btn = document.createElement('button');
btn.setAttribute('data-filter','important');
btn.innerHTML = 'Önemliler <span class="badge" id="waImportantCount">0</span>';
var firstBtn = qsa('#waTabs button')[0]; if (firstBtn) { btn.className = firstBtn.className; }
tabs.appendChild(btn);
  }

  // fetch important threads and decorate list
  var importantSet = new Set();
  function loadImportant(){
    return fetch(api('whatsapp_plus/important_threads')).then(r=>r.json()).then(function(res){
      importantSet = new Set(res.phones||[]);
      decorateThreads();
      updateImpCount();
    }).catch(function(){});
  }

  function updateImpCount(){
    var el = qs('#waImportantCount');
    if (el){
      el.textContent = qsa('.wa-thread[data-important="1"]').length;
    }
  }

  function decorateThreads(){
    qsa('.wa-thread').forEach(function(a){
      var phone = a.getAttribute('data-phone') || a.getAttribute('href') || '';
var p = (phone||'').replace(/.*phone=([^&]+)/,'$1');
if (!p && a.dataset && a.dataset.phone_e164) p = a.dataset.phone_e164;
p = normPhone(p);
      var isImp = importantSet.has(p);
      a.setAttribute('data-important', isImp ? '1':'0');
      // add star if missing
      if (!qs('.wa-star-btn', a)){
        var star = document.createElement('i');
        star.className = 'fa fa-star wa-star-btn' + (isImp ? ' active' : '');
        star.title = isImp ? 'Önemli işaretli' : 'Önemli olarak işaretle';
        star.addEventListener('click', function(ev){
          ev.preventDefault(); ev.stopPropagation();
          var wanted = star.classList.contains('active') ? 0 : 1;
          fetch(api('whatsapp_plus/toggle_thread_important'), {
            method:'POST',
            headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
            body: 'phone=' + encodeURIComponent(normPhone(p)) + '&important=' + wanted + '&' + encodeURIComponent(csrfName) + '=' + encodeURIComponent(csrfHash)
          }).then(function(r){ try { return r.json(); } catch(e){ return {}; } }).then(function(){
            if (wanted){ star.classList.add('active'); a.setAttribute('data-important','1'); importantSet.add(normPhone(p)); }
            else { star.classList.remove('active'); a.setAttribute('data-important','0'); importantSet.delete(normPhone(p)); }
            
            updateImpCount();
            // If current tab is "important", enforce filtering after toggle
            var activeTab = qs('#waTabs button.active');
            if (activeTab && activeTab.getAttribute('data-filter')==='important'){
              a.style.display = a.getAttribute('data-important')==='1' ? '' : 'none';
            }
            // force redisplay after any async list re-render
            setTimeout(function(){ decorateThreads(); updateImpCount(); }, 300);
          });
        });
        // place star at end of thread row
        a.appendChild(star);
      } else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){}
        var star = qs('.wa-star-btn', a);
        if (isImp) star.classList.add('active'); else star.classList.remove('active');
      }
      if (qs('#waTabs button.active') && qs('#waTabs button.active').getAttribute('data-filter')==='important'){
        a.style.display = isImp ? '' : 'none';
      }
    });
  }

  // observe list mutations to decorate dynamically
  var list = qs('.wa-list');
  if (list){
    var mo = new MutationObserver(function(){ decorateThreads(); updateImpCount(); });
    mo.observe(list, {childList:true, subtree:true});
  }
  loadImportant();

  // Wire up tab switching (existing buttons use data-filter). We add behavior for important
  var tabsEl = qs('#waTabs');
  if (tabsEl){
    tabsEl.addEventListener('click', function(e){
      var btn = e.target.closest('button[data-filter]'); if (!btn) return;
      qsa('#waTabs button').forEach(function(b){ b.classList.remove('active'); }); btn.classList.add('active');
      var filter = btn.getAttribute('data-filter');
if (filter === 'important'){
  qsa('.wa-thread').forEach(function(a){ a.style.display = (a.getAttribute('data-important')==='1') ? '' : 'none'; });
} else if (filter === 'unread'){
  qsa('.wa-thread').forEach(function(a){ a.style.display = a.classList.contains('unread') ? '' : 'none'; });
} else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){}
  qsa('.wa-thread').forEach(function(a){ a.style.display=''; });
}
    });
  }

  // (message-level important removed as requested)
})();

// --- v1.5.8 Multi-attach UI & send queue ---
(function(){
  var form = qs('#waSendForm');
  var input = qs('#waAttachment');
  var typeEl = qs('#waAttachType');
  var queue = qs('#waQueue');
  setAccept(typeEl && typeEl.value ? typeEl.value : 'document');
  function setAccept(t){
    if (!input) return;
    if (t==='image'){ input.accept='image/*'; input.multiple=true; }
    else if (t==='audio'){ input.accept='audio/*'; input.multiple=true; }
    else { input.accept='*/*'; input.multiple=true; }
  }
  $all('.wa-choose').forEach(function(a){
    a.addEventListener('click', function(e){
      e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      input && input.click();
    });
  });
  // show badges on file select
  if (input){
    input.addEventListener('change', function(){
      if (!queue) return;
      queue.innerHTML = '';
      var status = qs('#waStatus');
      if (status) status.textContent = '';
      var files = input.files || [];
      if (!files.length){
        if (status) status.textContent='';
        return;
      }
      Array.prototype.forEach.call(files, function(f, idx){
        if (status){ status.textContent = files.length + ' öğe seçildi'; }
        var chip = document.createElement('span');
        chip.className = 'wa-chip';
        var type = (typeEl.value==='image' || f.type.indexOf('image/')===0) ? 'Resim' :
                   (typeEl.value==='audio' || f.type.indexOf('audio/')===0) ? 'Ses' : 'Dosya';
        chip.innerHTML = '<span>'+type+': '+(f.name||('Seçim '+(idx+1)))+'</span>';
        queue.appendChild(chip);
      });
    });
  }
  // multi-send when multiple images selected
  if (form && input){
    form.addEventListener('submit', function(ev){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
      var status = qs('#waStatus');
      var files = input.files || [];
      var multiImages = (files.length>1) && (typeEl.value==='image');
      if (!multiImages){ if (status) status.textContent = (input.files && input.files.length>0) ? (input.files.length+' öğe gönderiliyor...') : 'Gönderiliyor...'; return; } // normal submit
      ev.preventDefault();
      // Send each image with same caption/text
      var textEl = qs('textarea[name="text"]');
      var caption = textEl ? textEl.value : '';
      var toEl = qs('input[name="to"]');
      var to = toEl ? toEl.value : '';
      (async function(){
        
for (var i=0;i<files.length;i++){
          var fd = new FormData();
          var csrf = readCsrf();
          fd.append(csrf.name, csrf.value);
          fd.append('to', to);
          fd.append('attachment_type', typeEl ? (typeEl.value||'document') : 'document');
          fd.append('attachment', files[i], files[i].name);
          if (caption) fd.append('caption', caption);
          fd.append('text','');
          try{
            if (status) status.textContent = 'Gönderiliyor ' + (i+1) + '/' + files.length + '...';
            var resp = await fetch(form.action, {
              method:'POST',
              body:fd,
              credentials:'same-origin',
              cache:'no-store',
              headers:{'X-Requested-With':'XMLHttpRequest'}
            });
            await new Promise(function(r){ setTimeout(r, 350); });
            try{
              var newCsrf = readCsrf(); refreshHiddenCsrf(newCsrf.value);
            }catch(_){ }
          }catch(e){ console.error(e); }
        }
})();
    });
  }
})();</script>

<?php init_tail(); ?>



<script>
// v1.6.4 robust multi-send with cached file list
(function(){
  var form = document.getElementById('sendForm');
  var input = document.getElementById('waAttachment');
  var queue = document.getElementById('waQueue');
  var statusEl = document.getElementById('waStatus');
  var typeEl = document.getElementById('waAttachType');
  if (input && !input.hasAttribute('multiple')) input.setAttribute('multiple','multiple');
  var cachedFiles = [];
  function showQueue(files){
    if (!queue) return;
    queue.innerHTML = '';
    if (!files || !files.length){ if (statusEl) statusEl.textContent=''; return; }
    if (statusEl) statusEl.textContent = files.length + ' öğe seçildi';
    for (var i=0;i<files.length;i++){
      var f = files[i];
      var chip = document.createElement('span');
      chip.className = 'wa-chip';
      chip.innerHTML = '<span>'+(f.type.indexOf('image/')===0?'Resim':(f.type.indexOf('audio/')===0?'Ses':'Dosya'))+': '+(f.name||('Seçim '+(i+1)))+'</span>';
      queue.appendChild(chip);
    }
  }
  if (input){
    input.addEventListener('change', function(){
      try{ cachedFiles = Array.prototype.slice.call(input.files || []); }catch(e){ cachedFiles = []; }
      showQueue(cachedFiles);
    });
  }
  if (form){
    form.addEventListener('submit', function(ev){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
      var files = (cachedFiles && cachedFiles.length) ? cachedFiles : (input ? (input.files||[]) : []);
      var multi = files && files.length > 1;
      if (!multi){ return; } // native submit for tekli
      ev.preventDefault();
      var textEl = form.querySelector('textarea[name="text"]');
      var caption = textEl ? textEl.value : '';
      var to = (form.querySelector('input[name="to"]')||{}).value || '';
      (async function(){
        for (var i=0;i<files.length;i++){
          if (statusEl) statusEl.textContent = 'Gönderiliyor ' + (i+1) + '/' + files.length + '...';
          var fd = new FormData(form);
          if (fd.has('attachment')) fd.delete('attachment');
          fd.append('attachment', files[i], files[i].name);
          if (caption) fd.set('caption', caption);
          if (typeEl) fd.set('attachment_type', typeEl.value||'document');
          try{
            await fetch(form.action, { method:'POST', body:fd, credentials:'same-origin', cache:'no-store', headers:{'X-Requested-With':'XMLHttpRequest'} });
            await new Promise(function(r){ setTimeout(r, 300); });
          }catch(e){ console.error(e); }
        }
        if (statusEl) statusEl.textContent = 'Gönderildi';
        try{ location.reload(); }catch(e){}
      })();
    });
  }
})();
</script>

<script>
(function(){
  var form = document.getElementById('sendForm');
  if(!form) return;
  var sel = document.getElementById('waChannel');
  var URL_SEND = '<?php echo admin_url('whatsapp_plus/send'); ?>';
  var URL_SEND_QR = '<?php echo admin_url('whatsapp_plus/send_qr'); ?>';
  form.addEventListener('submit', function(e){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
    if(!sel) return;
    if(sel.value === 'qr'){
      form.setAttribute('action', URL_SEND_QR);
    } else {
          try{ window.__waStatus__&&__waStatus__&&__waStatus__.hide(400);}catch(e){}
      form.setAttribute('action', URL_SEND);
    }
  });
})();
</script>

<!-- wp ui fix --><style>.wa-toolbar{display:flex;align-items:center;gap:.5rem}.wa-toolbar select{max-width:220px}</style>


<!-- Patch v2.3.3: default to send_qr if Cloud kapalıysa -->

    <script>

    (function(){

      try {

        var form = document.querySelector('form#sendForm, form[action*="whatsapp_plus/send"], form[action*="whatsapp_plus/send_qr"]');

        if(!form) return;

        var qrEnabled = (typeof wp_qr_enabled !== 'undefined') ? !!wp_qr_enabled : true; // varsayılan true

        var cloudEnabled = (typeof wa_cloud_enabled !== 'undefined') ? !!wa_cloud_enabled : false; // varsayılan false

        if (qrEnabled && !cloudEnabled) {

          form.setAttribute('action', (form.getAttribute('action') || '').replace('whatsapp_plus/send', 'whatsapp_plus/send_qr'));

        }

      } catch(e) {}

    })();

    </script>



<script>
(function(){
  function qs(sel, ctx){ return (ctx||document).querySelector(sel); }
  function qsa(sel, ctx){ return Array.prototype.slice.call((ctx||document).querySelectorAll(sel)); }

  var form = qs('#waSendForm');
  var input = qs('#waSendInput');
  var attachBtn = qs('#waPlus .wa-plus-inside');
  var file = qs('#waAttachment');
  var attachType = qs('#waAttachType');

  if (!form || !input) return;

  // ENTER -> Send, SHIFT+ENTER -> newline
  input.addEventListener('keydown', function(e){
    if (e.key === 'Enter' && !e.shiftKey){
      e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      if (btn) btn.click(); else form.submit();
    }
  });

  // Clear input after submit success by listening XHR/fetch hook
  // If the app uses normal submit, we fallback to clearing on 'submit' and short timeout
  form.addEventListener('submit', function(){
      try{ window.__waStatus__ && window.__waStatus__.set('Gönderiliyor...', 'loading'); }catch(e){}
    setTimeout(function(){
      if (input) { input.value = ''; input.style.height = '32px'; }
      if (file) file.value = '';
      if (attachType) attachType.value = 'none';
    }, 150);
  });

  // Plus button opens file chooser
  if (attachBtn && file){
    attachBtn.addEventListener('click', function(e){
      e.preventDefault();
      var fIn=document.getElementById('waAttachment');
      var files=(fIn&&fIn.files)?Array.prototype.slice.call(fIn.files):[];
      file.click();
    });
  }

  // When a file is picked, set attachment_type automatically
  if (file){
    file.addEventListener('change', function(){
      if (!file.files || !file.files.length) { if (attachType) attachType.value='none'; return; }
      var f = file.files[0];
      if (attachType){
        attachType.value = (f.type && f.type.indexOf('image/') === 0) ? 'image' :
                           (f.type && f.type.indexOf('video/') === 0) ? 'video' :
                           (f.type && f.type.indexOf('audio/') === 0) ? 'audio' : 'file';
      }
    });
  }
})();
</script>


<script>
// v2.4.3 stabilizer — enter-to-send, status auto-hide, pending cleanup, live reconcile
(function(){
  function $(s,ctx){ return (ctx||document).querySelector(s); }
  function $all(s,ctx){ return Array.prototype.slice.call((ctx||document).querySelectorAll(s)); }
  var form, input, body, statusEl, sendBtn, attachInput;

  function hideStatus(delay){
    if(!statusEl){ statusEl = $('#waStatus'); }
    if(!statusEl) return;
    var ms = (typeof delay==='number') ? delay : 2000;
    clearTimeout(statusEl._v243Timer);
    statusEl._v243Timer = setTimeout(function(){ statusEl.style.display='none'; }, ms);
  }
  function showStatus(text){
    if(!statusEl){ statusEl = $('#waStatus'); }
    if(!statusEl) return;
    statusEl.textContent = text || '';
    statusEl.style.display = 'block';
  }

  function clearPendings(){
    $all('#waBody .wa-msg.pending').forEach(function(n){
      // remove any pending bubbles left from older attempts
      try{ n.parentNode && n.parentNode.removeChild(n); }catch(e){}
    });
  }

  function wireEnterToSend(){
    input = input || $('#waMessage') || $('textarea[name="message"]') || $('textarea');
    form = form || $('#waSendForm') || $('form[action*="whatsapp_plus/send"]');
    if(!input || !form) return;
    if(input._v243Bound) return;
    input.addEventListener('keydown', function(ev){
      if (ev.isComposing || ev.key !== 'Enter') return;
      if (ev.shiftKey || ev.ctrlKey || ev.altKey || ev.metaKey) return;
      ev.preventDefault();
      // prevent double submit
      if (form._v243Submitting) return;
      form._v243Submitting = true;
      try { form.requestSubmit ? form.requestSubmit() : form.submit(); } catch(e){ form.submit(); }
      setTimeout(function(){ form._v243Submitting = false; }, 1200);
    });
    input._v243Bound = true;
  }

  function wireSubmitStatus(){
    form = form || $('#waSendForm') || $('form[action*="whatsapp_plus/send"]');
    if(!form) return;
    if(form._v243SubmitBound) return;
    form.addEventListener('submit', function(){
      showStatus('Gönderiliyor...');
      hideStatus(2000);
      // cleanup any leftovers shortly after
      setTimeout(clearPendings, 4000);
    }, true);
    form._v243SubmitBound = true;
  }

  function observeChat(){
    body = body || $('#waBody') || $('.wa-body');
    if(!body || body._v243Obs) return;
    var obs = new MutationObserver(function(muts){
      var changed = false;
      muts.forEach(function(m){
        if(m.type === 'childList' && m.addedNodes && m.addedNodes.length){
          changed = true;
        }
        if(m.type === 'attributes'){
          changed = true;
        }
      });
      if(changed){
        // New/updated message -> hide status and drop pending leftovers.
        hideStatus(200);
        clearPendings();
      }
    });
    obs.observe(body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    body._v243Obs = obs;
  }

  function watchdog(){
    // If a status text lingers >7s, hide it.
    var el = $('#waStatus');
    if(el && el.style && el.style.display !== 'none'){
      var now = Date.now();
      if(!el._v243LastShown){ el._v243LastShown = now; }
      if(now - el._v243LastShown > 7000){ el.style.display = 'none'; }
    }
  }

  function init(){
    statusEl = $('#waStatus');
    wireEnterToSend();
    wireSubmitStatus();
    observeChat();
    // first-time cleanup
    clearPendings();
    // watchdog interval
    setInterval(watchdog, 1500);
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  }else{
    init();
  }
})();
</script>

<script>
// v2.4.4 ajax sender — clean status, no "Gönderilemedi", empty-guard
(function(){
  function $(s,ctx){ return (ctx||document).querySelector(s); }
  function byId(id){ return document.getElementById(id); }
  function hideStatus(ms){ try{ window.__waStatus__&&__waStatus__.hide(ms||300);}catch(e){} }
  function showSending(){ try{ window.__waStatus__&&__waStatus__.set('Gönderiliyor...','loading'); __waStatus__.hide(2000);}catch(e){} }

  function bind(){
    var form = byId('waSendForm') || $('form[action*="whatsapp_plus/send"]');
    if(!form || form._v244Bound) return;
    form.addEventListener('submit', function(ev){
      ev.preventDefault();
      var btn = form.querySelector('[type=submit]');
      var msgEl = byId('waMessage') || $('textarea[name=message]', form) || $('textarea', form);
      var attEl = byId('waAttachment') || $('input[type=file]', form);
      var txt = (msgEl && msgEl.value) ? msgEl.value.trim() : '';
      var hasFile = !!(attEl && attEl.files && attEl.files.length>0);
      if(!txt && !hasFile){
        // completely empty -> do nothing and keep status hidden
        hideStatus(100);
        return;
      }
      if(btn) btn.disabled = true;
      showSending();

      var fd = new FormData(form);
      var url = form.getAttribute('action') || '/crm/admin/whatsapp_plus/send_qr';
      fetch(url, {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
      }).then(function(res){
        if(btn) btn.disabled = false;
        hideStatus(200);
        if(res.ok){
          if(msgEl) msgEl.value='';
          if(attEl) attEl.value='';
        }
        return res;
      }).catch(function(){
        if(btn) btn.disabled=false;
        hideStatus(200);
      });
    }, true);
    form._v244Bound = true;
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', bind);
  } else {
    bind();
  }
})();
</script>


<!-- v2.4.5: Auto-scroll to the latest message -->
<script>
(function(){
  function toBottom(force){
    var el = document.getElementById('waBody');
    if(!el) return;
    try {
      var nearBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 200;
      if(force || nearBottom){
        el.scrollTop = el.scrollHeight;
      }
    } catch(e){}
  }

  // On initial load, force-scroll to the bottom
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ setTimeout(function(){ toBottom(true); }, 0); });
  } else {
    setTimeout(function(){ toBottom(true); }, 0);
  }

  // When new messages are appended, keep view stuck to bottom if user hasn't scrolled far up
  var el = document.getElementById('waBody');
  if (el && !el._v245Obs) {
    var obs = new MutationObserver(function(muts){
      var added = false;
      for (var i=0;i<muts.length;i++){
        var m = muts[i];
        if (m.type === 'childList' && m.addedNodes && m.addedNodes.length){ added = true; break; }
      }
      if (added) { toBottom(false); }
    });
    obs.observe(el, { childList: true, subtree: true });
    el._v245Obs = obs;
  }
})();
</script>



<!-- v2.4.7: Normalize checks spacing & style -->
<style>
  /* Enforce consistent gap & prevent wrapping around ticks */
  #waPlus .wa-meta .wa-checks{ margin-left: 6px; white-space: nowrap; display: inline-block; }
</style>
<script>
(function(){
  // Trim stray whitespace inside wa-checks (server-rendered indentation)
  function normalizeChecks(ctx){
    (ctx || document).querySelectorAll('#waBody .wa-checks').forEach(function(el){
      var t = (el.textContent || '').replace(/\s+/g, '');
      el.textContent = t;
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ normalizeChecks(document); });
  } else {
    normalizeChecks(document);
  }
  // Expose for live reconcile if needed elsewhere
  window.__waNormalizeChecks__ = normalizeChecks;
})();
</script>

<script id="wa-realtime-core">
(function(){
  var activePhone = <?php echo json_encode($active_phone ?? ""); ?> || "";
  var accId       = <?php echo (int)($active_acc ?? 0); ?>;
  var body        = document.getElementById('waBody');
  if(!activePhone || !body) return;

  /* ---- Tik yardımcıları ---- */
  function statusRankFromEl(el){
    if(!el) return 0;
    var txt = (el.textContent||"").replace(/\s+/g,'');
    if(el.classList.contains('read')) return 3;       // ✔✔ (mavi)
    if(txt === '✔✔') return 2;                        // ✔✔ (gri)
    if(txt === '✔')  return 1;                        // ✔
    return 0;
  }
  function rankOf(status){ return (status==='read')?3:(status==='delivered'?2:1); }
  function setChecks(el, status){
    if(!el) return;
    var r = rankOf(status);
    el.textContent = (r>=2) ? '✔✔' : '✔';
    if(r===3){ el.classList.add('read'); } else { el.classList.remove('read'); }
  }
  window.__waSetChecks__ = setChecks; // global

  /* ---- Son id ---- */
  function currentMaxId(){
    var max = 0;
    body.querySelectorAll('.wa-msg[data-id]').forEach(function(n){
      var id = parseInt(n.getAttribute('data-id')||'0',10);
      if(id>max) max=id;
    });
    return max;
  }

  /* ---- Yeni mesaj ekle (global) ---- */
  function appendMsg(m){
    try{
      if(!m || !m.id) return;

      var exists = body.querySelector('.wa-msg[data-id="'+m.id+'"]');
      if(exists){
        var ch = exists.querySelector('.wa-checks');
        if(ch && m.direction==='out' && m.status){
          if(rankOf(m.status) >= statusRankFromEl(ch)) setChecks(ch, m.status);
        }
        if(m.attachments_html){
          var bub = exists.querySelector('.bubble');
          if(bub && !bub.querySelector('.wa-attachments')){
            var t = document.createElement('div'); t.innerHTML = m.attachments_html;
            if(t.firstElementChild) bub.insertBefore(t.firstElementChild, bub.firstChild);
          }
        }
        return;
      }

      var wrap   = document.createElement('div');
      wrap.className = 'wa-msg ' + (m.direction==='out' ? 'out' : 'in');
      wrap.setAttribute('data-id', m.id);

      var bubble = document.createElement('div'); bubble.className = 'bubble';

      // Grup içindeki gelen mesajlarda gönderen etiketi
      try{
        var isGroup = (typeof activePhone==='string' && activePhone.indexOf('g:')===0);
        if(m.direction==='in'){
          var metaJson = null; try{ metaJson = m.meta_json ? JSON.parse(m.meta_json) : null; }catch(_){}
          var senderPhone = (metaJson && metaJson.sender_e164) || m.sender || m.phone || '';
          var senderName  = (metaJson && metaJson.sender_name)  || m.sender_name || m.contact_name || '';
          var label = isGroup ? (senderName || senderPhone) + (senderPhone ? ' ('+senderPhone+')' : '') : (senderName || '');
          if(label){ var lab=document.createElement('div'); lab.className='wa-sender'; lab.textContent=label; bubble.appendChild(lab); }
        }
      }catch(_){}

      if(m.attachments_html){
        var tmp = document.createElement('div'); tmp.innerHTML = m.attachments_html;
        if(tmp.firstElementChild) bubble.appendChild(tmp.firstElementChild);
      }

      var bodyText = (m.has_caption ? '' : (m.body || ''));
      if(bodyText){ var t = document.createElement('div'); t.className='wa-text'; t.textContent = bodyText; bubble.appendChild(t); }

      var meta = document.createElement('div'); meta.className='wa-meta';
      var sp   = document.createElement('span'); sp.textContent = m.created_at_fmt || m.created_at || '';
      meta.appendChild(sp);
      if(m.direction==='out'){
        var ck = document.createElement('span'); ck.className='wa-checks';
        setChecks(ck, m.status || 'sent');
        meta.appendChild(ck);
      }
      bubble.appendChild(meta);
      wrap.appendChild(bubble);

      body.appendChild(wrap);
      body.scrollTop = body.scrollHeight;
    }catch(e){}
  }
  window.appendMsg = appendMsg; // global

  /* ---- Mesaj poll ---- */
  var msgBusy = false;
  function pollOnce(){
    if(msgBusy) return; msgBusy = true;
    var url = '<?php echo admin_url("whatsapp_plus/poll_messages"); ?>'
              + '?acc=<?php echo (int)($active_acc ?? 0); ?>'
              + '&phone=' + encodeURIComponent(activePhone)
              + '&after_id=' + currentMaxId();
    fetch(url, {credentials:'same-origin'})
      .then(r=>r.json())
      .then(function(res){
        (res.messages||[]).forEach(appendMsg);
        (res.media_updates||[]).forEach(function(mu){
          var bub = body.querySelector('.wa-msg[data-id="'+mu.id+'"] .bubble');
          if(bub && mu.attachments_html && !bub.querySelector('.wa-attachments')){
            var t = document.createElement('div'); t.innerHTML = mu.attachments_html;
            if(t.firstElementChild) bub.insertBefore(t.firstElementChild, bub.firstChild);
          }
        });
      })
      .finally(function(){ msgBusy=false; });
  }
  window.pollOnce = pollOnce; // global

  /* ---- Durum (tik) poll ---- */
  var stBusy = false;
  function pollStatus(){
    if(stBusy) return; stBusy = true;
    var url = '<?php echo admin_url("whatsapp_plus/status_poll"); ?>'
              + '?acc=' + encodeURIComponent(accId)
              + '&phone=' + encodeURIComponent(activePhone);
    fetch(url, {credentials:'same-origin'})
      .then(r=>r.json())
      .then(function(res){
        if(!res || !res.success) return;
        (res.statuses||[]).forEach(function(row){
          var el = body.querySelector('.wa-msg[data-id="'+row.id+'"] .wa-checks');
          if(!el) return;
          if(rankOf(row.status) >= statusRankFromEl(el)){ setChecks(el, row.status); }
        });
      })
      .finally(function(){ stBusy=false; });
  }

  /* ---- Zamanlayıcılar ---- */
  var pollMs = Math.max((parseInt('<?php echo (int)(get_option("wp_poll_interval_sec") ?: 3); ?>',10)||3)*1000, 2500);
  setInterval(pollOnce,  pollMs);
  setInterval(pollStatus, 3500);
  setTimeout(function(){ pollOnce(); pollStatus(); }, 500);
  window.addEventListener('focus', function(){ pollOnce(); pollStatus(); });
})();
</script>

<style id="wa-checks-style">
  #waPlus .wa-meta .wa-checks{
    display:inline-block; white-space:nowrap; margin-left:6px; opacity:.9; color:#6b7280; /* sent/delivered gri */
  }
  #waPlus .wa-meta .wa-checks.read{ color:#34B7F1; } /* read = mavi */
</style>
<style id="wa-checks-blue-fix">
  #waPlus .wa-meta .wa-checks{ display:inline-block; white-space:nowrap; margin-left:6px; }
  #waPlus .wa-meta .wa-checks.read{ color:#34B7F1 !important; }
</style>



<script id="waPlusToggleOnly322">
(function(){
  var root = document.getElementById('waPlus') || document;
  var plus = root.querySelector('#waPlusAddBtn');
  var menu = root.querySelector('#waPlusMenu') || root.querySelector('.wa-inside-menu');
  if(!plus || !menu) return;
  function block(e){ try{ e.preventDefault(); if(e.stopImmediatePropagation) e.stopImmediatePropagation(); e.stopPropagation(); }catch(_){ } }
  ['pointerdown','mousedown','touchstart'].forEach(function(evt){ plus.addEventListener(evt, block, true); });
  plus.addEventListener('click', function(e){ block(e); menu.classList.toggle('show'); plus.setAttribute('aria-expanded', menu.classList.contains('show')?'true':'false'); }, true);
  document.addEventListener('click', function(e){ if(menu.classList.contains('show') && !menu.contains(e.target) && e.target!==plus){ menu.classList.remove('show'); plus.setAttribute('aria-expanded','false'); } });
})();
</script>



<style id="waRecBarStyles323">
#waPlus .wa-recbar{position:absolute;left:12px;right:12px;bottom:52px;background:#222b35;color:#e5e7eb;border-radius:12px;padding:8px 12px;display:flex;align-items:center;gap:14px;box-shadow:0 10px 24px rgba(0,0,0,.25);z-index:9999}
#waPlus .wa-recbar__dot{width:8px;height:8px;border-radius:50%;background:#ef4444;animation:blink 1s infinite}
#waPlus .wa-recbar__time{font-variant-numeric:tabular-nums;min-width:48px}
#waPlus .wa-recbar__eq{flex:1;height:12px; background:repeating-linear-gradient(90deg, rgba(229,231,235,.35) 0 6px, transparent 6px 12px); mask:linear-gradient(90deg,#fff,rgba(255,255,255,.1)); animation:eqmove 1s linear infinite}
#waPlus .wa-recbar__cancel{margin-left:auto;color:#cbd5e1;text-decoration:none}
@keyframes blink{0%,100%{opacity:.4}50%{opacity:1}}
@keyframes eqmove{0%{background-position:0 0}100%{background-position:100px 0}}
</style>

<script id="waPlusHoldVoice323">
(function(){
  var root = document.getElementById('waPlus') || document;
  var btn = root.querySelector('#waHoldVoiceBtn');
  var form = root.querySelector('#waSendForm') || document.querySelector('#waSendForm');
  var attach = root.querySelector('#waAttachment');
  var typeEl = root.querySelector('#waAttachType');
  var bar = root.querySelector('#waRecBar');
  var tEl = root.querySelector('.wa-recbar__time');
  var cancelBtn = root.querySelector('#waRecCancelBtn');
  if(!btn || !attach || !form) return;
  if(!(navigator.mediaDevices && window.MediaRecorder)) return;

  var down=false, rec=null, stream=null, chunks=[], MAX=120000, t0=0, raf=null;

  function setFilesFromBlob(blob){
    var file = new File([blob],'voice_'+Date.now()+'.webm',{type:'audio/webm'});
    try{ var dt=new DataTransfer(); dt.items.add(file); attach.files=dt.files; }catch(_){}
    if (typeEl) typeEl.value='audio';
  }
  function fmt(ms){ var s=Math.floor(ms/1000), m=('0'+Math.floor(s/60)).slice(-2), ss=('0'+(s%60)).slice(-2); return m+':'+ss; }
  function tick(){
    if(!down || !tEl) return;
    tEl.textContent = fmt(Date.now()-t0);
    raf = requestAnimationFrame(tick);
  }
  function showBar(v){
    if (!bar) return;
    bar.style.display = v ? 'flex' : 'none';
  }
  function start(){
    navigator.mediaDevices.getUserMedia({audio:true}).then(function(s){
      stream=s; chunks=[]; rec=new MediaRecorder(s);
      rec.ondataavailable=function(e){ if(e.data && e.data.size) chunks.push(e.data); };
      rec.onstop=function(){
        try{ stream.getTracks().forEach(t=>t.stop()); }catch(_){}
        showBar(false);
        if (down){ return; } // safety
        if (chunks.length){ var blob=new Blob(chunks,{type:'audio/webm'}); setFilesFromBlob(blob); form.submit(); }
      };
      rec.start(); t0=Date.now(); down=true; showBar(true); tick();
      setTimeout(function(){ if(rec && down){ stop(false); } }, MAX);
    }).catch(function(err){ alert('Mikrofon izni/HTTPS gerekli: '+err); down=false; showBar(false); });
  }
  function stop(cancel){
    try{ if(raf) cancelAnimationFrame(raf); }catch(_){}
    down=false;
    if(rec){ try{ if(cancel){ rec.ondataavailable=null; } rec.stop(); }catch(_){} }
    else { try{ if(stream) stream.getTracks().forEach(t=>t.stop()); }catch(_){ } }
  }
  var startEv = function(e){ e.preventDefault(); e.stopPropagation(); if(!down) start(); };
  var endEv   = function(e){ e.preventDefault(); e.stopPropagation(); if(down) stop(false); };
  var cancelEv= function(e){ e.preventDefault(); e.stopPropagation(); if(down) stop(true); };
  btn.addEventListener('mousedown', startEv);
  btn.addEventListener('touchstart', startEv);
  btn.addEventListener('mouseup', endEv);
  btn.addEventListener('touchend', endEv);
  btn.addEventListener('mouseleave', cancelEv);
  if (cancelBtn) cancelBtn.addEventListener('click', cancelEv);
})();
</script>













<style id="waQueueXPatchCSS">
#waQueue .wa-chip { position: relative; }
#waQueue .wa-chip .wa-remove {
  position: absolute;
  top: -6px;
  right: -6px;
  width: 18px;
  height: 18px;
  border: none;
  border-radius: 50%;
  background: #f44336;
  color: #fff;
  font-size: 12px;
  line-height: 18px;
  text-align: center;
  cursor: pointer;
  padding: 0;
}
#waQueue .wa-chip .wa-remove:focus { outline: 2px solid rgba(0,0,0,0.1); outline-offset: 1px; }
#waQueue .wa-chip .wa-remove:hover { filter: brightness(0.95); }
</style>

<script id="waQueueXPatchJS">
(function () {
  function ready(fn){ if (document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  ready(function() {
    var queue = document.getElementById('waQueue');
    if (!queue) return;

    var form = queue.closest('form') || document;
    var fileInputs = form.querySelectorAll('input[type="file"][multiple], #waAttachment');

    function filenameFromChip(chip){
      var txtEl = chip.querySelector('span');
      if (!txtEl) return null;
      var raw = (txtEl.textContent || '').trim();
      var m = raw.match(/(?:Resim|Dosya)\s*:\s*(.+)$/i);
      return (m && m[1]) ? m[1].trim() : raw;
    }

    function attachRemoveButtons(){
      queue.querySelectorAll('.wa-chip').forEach(function(chip){
        if (chip.querySelector('.wa-remove')) return;
        var name = filenameFromChip(chip);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'wa-remove';
        btn.setAttribute('aria-label', 'Sil');
        btn.textContent = '✕';
        btn.addEventListener('click', function(e){
          e.preventDefault();
          chip.remove();
          fileInputs.forEach(function(inp){
            try {
              if (!inp || !inp.files || !inp.files.length) return;
              var dt = new DataTransfer();
              Array.from(inp.files).forEach(function(f){
                if (!name || f.name !== name) dt.items.add(f);
              });
              inp.files = dt.files;
            } catch (err) {
              if (window.console && console.warn) console.warn('[waqueue-remove] Could not update file input:', err);
            }
          });
        });
        if (!getComputedStyle(chip).position || getComputedStyle(chip).position === 'static') {
          chip.style.position = 'relative';
        }
        chip.appendChild(btn);
      });
    }

    attachRemoveButtons();
    var observer = new MutationObserver(function(mutations){
      var needs = false;
      mutations.forEach(function(m){ if (m.addedNodes && m.addedNodes.length) needs = true; });
      if (needs) attachRemoveButtons();
    });
    observer.observe(queue, { childList: true, subtree: true });
  });
})();
</script>






<script id="waSendUX328">
// v3.2.8: 
// - Clear input after send (text & attachments)
// - Avoid extra text bubble when sending attachments with caption
// - Show optimistic preview for EVERY file (images/docs) instantly
// - Clear #waQueue chips immediately on send
// - More robust dedup & event capture
(function(){
  function ready(fn){ if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', fn); } else { fn(); } }
  ready(function(){
    var form = document.getElementById('waSendForm') || document.querySelector('form[action*="whatsapp_plus/send"]');
    var input = document.getElementById('waAttachment');
    var queue = document.getElementById('waQueue');
    var statusEl = document.getElementById('waStatus');
    var bodyEl = document.getElementById('waBody') || document.querySelector('.wa-body');
    var sendBtn = (form && (document.getElementById('waSendBtn') || form.querySelector('.wa-send-btn[type="submit"]'))) || null;
    var textEl = form && (form.querySelector('#waSendInput, textarea[name="text"], textarea[name="message"]') || null);

    if(!form) return;
    if (form._wa328Bound) return; form._wa328Bound = true;

    function toBottom(force){
      var el = bodyEl;
      if(!el) return;
      try {
        var nearBottom = (el.scrollHeight - el.scrollTop - el.clientHeight) < 200;
        if(force || nearBottom){ el.scrollTop = el.scrollHeight; }
      } catch(e){}
    }

    function readCsrf(){
      var hid = document.querySelector('input[type=hidden][name*="csrf"]');
      if (hid) return {name:hid.name, value:hid.value};
      var meta = document.querySelector('meta[name="csrf_token"]');
      var metaName = document.querySelector('meta[name="csrf_token_name"]');
      if (meta) return {name:(metaName?metaName.getAttribute('content'):'csrf_token'), value:meta.getAttribute('content')||''};
      return {name:'', value:''};
    }
    function refreshHiddenCsrf(v){
      var hid = document.querySelector('input[type=hidden][name*="csrf"]');
      if (hid && v) hid.value = v;
    }
    function computeType(file){
      var t = (file && file.type || '').toLowerCase();
      if (t.indexOf('image/')===0) return 'image';
      if (t.indexOf('video/')===0) return 'video';
      if (t.indexOf('audio/')===0) return 'audio';
      return 'document';
    }
    function sigOf(f){ return (f && [f.name, f.size, f.lastModified||0].join('|')) || ''; }

    // Create optimistic bubble for a file and return node
    function createPendingBubble(file, caption){
      if (!bodyEl) return null;
      var wrap = document.createElement('div');
      wrap.className = 'wa-msg out pending';
      var bubble = document.createElement('div');
      bubble.className = 'bubble';

      var at = document.createElement('div');
      at.className = 'wa-attachments wa-attachments--single';

      if (file && file.type && file.type.indexOf('image/')===0){
        var att = document.createElement('div'); att.className='wa-att wa-att--image';
        var img = document.createElement('img');
        try{ img.src = URL.createObjectURL(file); img.onload = function(){ try{ URL.revokeObjectURL(img.src); }catch(_){}}; }catch(_){}
        img.alt = file.name || 'image';
        att.appendChild(img);
        at.appendChild(att);
      } else {
        var att = document.createElement('div'); att.className='wa-att wa-att--doc';
        var chip = document.createElement('div'); chip.className='wa-chip'; chip.textContent = (file && file.name) ? ('Dosya: ' + file.name) : 'Dosya';
        att.appendChild(chip); at.appendChild(att);
      }

      bubble.appendChild(at);
      if (caption){
        var cap = document.createElement('div'); cap.className='wa-cap'; cap.textContent=caption;
        bubble.appendChild(cap);
      }
      var meta = document.createElement('div'); meta.className='wa-meta'; meta.innerHTML='<span class="wa-checks">…</span>';
      bubble.appendChild(meta);
      wrap.appendChild(bubble);
      bodyEl.appendChild(wrap);
      toBottom(true);
      return wrap;
    }

    // When a real message arrives via JSON+appendMsg, remove one pending bubble
    function consumeOnePending(){
      var p = bodyEl && bodyEl.querySelector('.wa-msg.out.pending');
      if (p){ try{ p.parentNode && p.parentNode.removeChild(p); }catch(_){ } }
    }

    var running = false;
    var sentSig = new Set();

    async function runAttachmentsFlow(){
      if (running) return;
      running = true;
      try{ if (sendBtn) sendBtn.disabled = true; }catch(_){}

      // Snapshot files and caption
      var files = input ? Array.prototype.slice.call(input.files || []) : [];
      var hasFiles = files && files.length > 0;
      var caption = textEl ? (textEl.value||'') : '';

      if (!hasFiles){
        running=false; try{ if (sendBtn) sendBtn.disabled=false; }catch(_){ }
        return;
      }

      // UX: immediately clear queue chips and message box (caption becomes part of attachments)
      if (queue) queue.innerHTML = '';
      if (textEl) textEl.value = '';

      // Clear input so no other handler sees it
      if (input){ try{ input.value=''; }catch(_){ } }

      var to = (form.querySelector('input[name="to"]')||{}).value || '';

      for (var i=0;i<files.length;i++){
        var f = files[i];
        var sig = sigOf(f);
        if (sig && sentSig.has(sig)) { continue; }
        sentSig.add(sig);

        // optimistic bubble
        var pendingNode = createPendingBubble(f, caption);

        var fd = new FormData();
        var csrf = readCsrf();
        if (csrf.name) fd.append(csrf.name, csrf.value);
        fd.append('to', to);
        fd.append('attachment_type', computeType(f));
        fd.append('attachment', f, f.name);
        if (caption) fd.append('caption', caption);
        fd.append('text',''); // avoid separate text message

        try{
          if (statusEl) statusEl.textContent = 'Gönderiliyor ' + (i+1) + '/' + files.length + '...';
          var resp = await fetch(form.action, {
            method:'POST',
            body:fd,
            credentials:'same-origin',
            cache:'no-store',
            headers:{'X-Requested-With':'XMLHttpRequest'}
          });
          var json = null;
          try{ json = await resp.clone().json(); }catch(_){}

          if (json && json.message && typeof window.appendMsg === 'function'){
            try{ window.appendMsg(json.message); }catch(_){}
            consumeOnePending();
          }
          try{ if (json && json.csrf_token) refreshHiddenCsrf(json.csrf_token); }catch(_){}
          await new Promise(function(r){ setTimeout(r, 140); });
        }catch(err){ if (window.console && console.warn) console.warn('Attachment send error:', err); }
      }

      try{ if (statusEl) statusEl.textContent = 'Gönderildi ✓'; }catch(_){}
      try{ if (window.__waStatus__) __waStatus__.hide(1500); }catch(_){}
      try{ if (window.pollOnce) pollOnce(); }catch(_){}
      try{ if (sendBtn) sendBtn.disabled = false; }catch(_){}
      running = false;
    }

    function interceptIfFiles(ev){
      var hasFiles = input && input.files && input.files.length > 0;
      if (!hasFiles || running) return;
      ev.preventDefault();
      ev.stopPropagation();
      if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
      runAttachmentsFlow();
    }

    // Intercept for ANY file count >=1
    form.addEventListener('submit', interceptIfFiles, true);
    if (sendBtn) sendBtn.addEventListener('click', interceptIfFiles, true);
    if (textEl){
      textEl.addEventListener('keydown', function(e){
        if (e.key === 'Enter' && !e.shiftKey){ interceptIfFiles(e); }
      }, true);
    }

    // Universal UX: when a real out message is appended, clear input (text-only sends)
    if (bodyEl && !bodyEl._wa328Obs){
      var obs = new MutationObserver(function(muts){
        var addedOut = false;
        muts.forEach(function(m){
          m.addedNodes && Array.prototype.forEach.call(m.addedNodes, function(n){
            if (n && n.classList && n.classList.contains('wa-msg') && n.classList.contains('out') && !n.classList.contains('pending')){
              addedOut = true;
            }
          });
        });
        if (addedOut){
          if (textEl) textEl.value = '';
          if (queue) queue.innerHTML = '';
          try{ if (statusEl) statusEl.textContent = ''; }catch(_){}
          toBottom(true);
        }
      });
      obs.observe(bodyEl, {childList:true, subtree:true});
      bodyEl._wa328Obs = obs;
    }
  });
})();

  // --- GÖNDER (tek tetikleme + alan eşitleme; capture-phase) ---
  var form   = qs('#waSendForm');
  var input  = qs('#waSendInput');
  var btn    = qs('#waSendBtn');
  var toHid  = qs('#waTo');
  var header = qs('#waHeaderPhone');
  var hRecv  = qs('#waReceiver');
  var hMsg   = qs('#waHiddenMsg');

  if (form && !form._waBound) {
    form._waBound = true;
    form.addEventListener('submit', function(e){
      e.stopImmediatePropagation(); e.stopPropagation(); e.preventDefault();
      if (form._waSending) return; form._waSending = true;

      var fIn   = document.getElementById('waAttachment');
      var files = (fIn && fIn.files) ? fIn.files : [];
      var txt   = (input && input.value) ? input.value.trim() : '';
      if (!txt && (!files || files.length === 0)) { form._waSending = false; return; }

      var fd = new FormData(form);
      var to = (fd.get('to') || fd.get('phone') || (toHid ? toHid.value : '') || (header && header.dataset ? header.dataset.phone : '') || '').toString().trim();
      if (to) { fd.set('to', to); fd.set('receiver', to); if(hRecv) hRecv.value = to; }
      if (txt){ fd.set('text', txt); fd.set('message', txt); if(hMsg) hMsg.value = txt; }

      if (btn) btn.disabled = true;
      fetch(form.action, { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(res){
          if (!res || res.success !== true) {
            var msg = (res && res.message) ? res.message : 'Gönderilemedi';
            try{ window.__waStatus__ && window.__waStatus__.set(msg, 'error'); }catch(_){}
            return;
          }
          try{ window.__waStatus__ && window.__waStatus__.set('Gönderildi', 'ok'); }catch(_){}
          if (input) input.value = '';
        })
        .catch(function(){ try{ window.__waStatus__ && window.__waStatus__.set('Ağ hatası', 'error'); }catch(_){}})
        .finally(function(){ form._waSending = false; if (btn) btn.disabled = false; });
    }, true);
  }

// auto-scroll to bottom on load
try{ var __b=document.getElementById('waBody'); if(__b){ __b.scrollTop = __b.scrollHeight; } }catch(_){}
</script>



<!-- 3.3.6: Safe submit hardening to avoid missing ) errors and ensure required fields -->
<script>
(function(){
  try{
    var form = document.getElementById('waSendForm');
    if(!form) return;
    var sel = document.getElementById('waChannel');
    var URL_SEND = '<?php echo admin_url('whatsapp_plus/send'); ?>';
    var URL_SEND_QR = '<?php echo admin_url('whatsapp_plus/send_qr'); ?>';
    function qsForm(sel){ return form.querySelector(sel); }
    function ensureHidden(name, val){
      var el = qsForm('[name="'+name+'"]');
      if(!el){ el = document.createElement('input'); el.type='hidden'; el.name=name; form.appendChild(el); }
      el.value = (val||'').trim();
    }
    function getVal(){
      var v='';
      var els = ['[name=to]','[name=receiver]','[name=phone]','#phone','#to'];
      for(var i=0;i<els.length;i++){ var e = document.querySelector(els[i]); if(e && e.value){ v = e.value; break; } }
      if(!v){ try{ var q = new URLSearchParams(location.search); v = q.get('phone') || q.get('to') || ''; }catch(_){} }
      return (v||'').trim();
    }
    function getMsg(){
      var v='';
      var els = ['[name=text]','[name=message]','[name=body]','#message','#waSendInput','textarea'];
      for(var i=0;i<els.length;i++){ var e = document.querySelector(els[i]); if(e && e.value){ v = e.value; break; } }
      return (v||'').trim();
    }
    form.addEventListener('submit', function(ev){
      // Don't prevent default; let normal POST happen. We only normalize fields.
      var to = getVal();
      var msg = getMsg();
      ensureHidden('to', to);
      ensureHidden('text', msg);
      ensureHidden('account_id', '<?php echo (int)($active_acc ?? 0); ?>');
      if(sel && sel.value === 'qr'){
        form.setAttribute('action', URL_SEND_QR);
      } else {
        form.setAttribute('action', URL_SEND);
      }
    }, true);
    console.log('[WA 3.3.6] composer hardening active');
  }catch(e){ console.warn('[WA 3.3.6] composer hardening failed', e); }
})();
</script>


<script id="wa-read-normalizer-336">
(function(){
  var body = document.getElementById('waBody');
  var phone = <?php echo json_encode($active_phone ?? ""); ?> || "";
  var acc   = <?php echo (int)($active_acc ?? 0); ?>;
  if (!body || !phone) return;

  function rank(s){ s=(s||'').toString().toLowerCase();
    if (/read|seen|viewed|okundu|blue/.test(s)) return 3;
    if (/deliver/.test(s)) return 2;
    if (/sent|server|queued|submit/.test(s)) return 1;
    return 1;
  }
  function curr(el){
    var t=(el.textContent||'').replace(/\s+/g,'');
    if (el.classList.contains('read')) return 3;
    if (t==='✔✔') return 2;
    if (t==='✔')  return 1;
    return 0;
  }
  function set(el, r){
    el.textContent = (r>=2) ? '✔✔' : '✔';
    if (r===3) el.classList.add('read'); else el.classList.remove('read');
  }

  var busy=false;
  function poll(){
    if (busy) return; busy=true;
    var url = '<?php echo admin_url("whatsapp_plus/status_poll"); ?>'
            + '?acc=' + encodeURIComponent(acc)
            + '&phone=' + encodeURIComponent(phone);
    fetch(url, {credentials:'same-origin'})
      .then(function(r){ return r.json(); })
      .then(function(res){
        var list = (res && (res.statuses || res.items || res.data)) || [];
        list.forEach(function(row){
          var id = row.id || row.message_id || row.msg_id;
          var el = id ? body.querySelector('.wa-msg[data-id="'+id+'"] .wa-checks') : null;
          if (!el) el = body.querySelector('.wa-msg.out:last-of-type .wa-checks');
          if (!el) return;
          var st = row.status || row.state || row.message_status || row.delivery_status || '';
          var rnk = rank(st);
          if (rnk >= curr(el)) set(el, rnk);
        });
      })
      .finally(function(){ busy=false; });
  }
  setInterval(poll, 3200);
  setTimeout(poll, 800);
})();
</script>


<script>
  // v2.4.1 status helpers
  (function(){
    var st = document.getElementById('waStatus');
    function setStatus(text, mode){
      if(!st){ st = document.getElementById('waStatus'); }
      if(!st) return;
      st.textContent = text || '';
      st.classList.remove('ok','error','muted','loading','hidden');
      if(mode){ st.classList.add(mode); }
      st.style.display = 'block';
      st.setAttribute('aria-live','polite');
    }
    function hideStatus(delay){
      if(!st){ st = document.getElementById('waStatus'); }
      if(!st) return;
      var ms = (typeof delay==='number') ? delay : 1600;
      window.clearTimeout(st._hideTimer);
      st._hideTimer = window.setTimeout(function(){
        st.style.display = 'none';
      }, ms);
    }
    window.__waStatus__ = { set: setStatus, hide: hideStatus };
  })();
</script>