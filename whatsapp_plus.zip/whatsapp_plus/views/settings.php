<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="panel_s">
      <div class="panel-body">
        <h4><?php echo _l('settings'); ?></h4><a class="btn btn-sm btn-secondary" href="<?= admin_url('whatsapp_plus/accounts') ?>">Hesaplar</a>
        <?php echo form_open(admin_url('whatsapp_plus/settings')); ?>
          <div class="form-group">
            <label>Access Token</label>
            <input class="form-control" name="wp_access_token" value="<?php echo html_escape($wp_access_token); ?>" required>
          </div>
          <div class="form-group">
            <label>WABA ID</label>
            <input class="form-control" name="wp_waba_id" value="<?php echo html_escape($wp_waba_id); ?>" required>
          </div>
          <div class="form-group">
            <label>Phone Number ID</label>
            <input class="form-control" name="wp_phone_number_id" value="<?php echo html_escape($wp_phone_number_id); ?>" required>
          </div>
          <div class="form-group">
            <label>Verify Token (Webhook doğrulama için)</label>
            <input class="form-control" name="wp_verify_token" value="<?php echo html_escape($wp_verify_token); ?>">
          </div>
          <button class="btn btn-success"><?php echo _l('submit'); ?></button>
        <div class="row tw-mb-2">
            <div class="col-md-3">
              <div class="checkbox"><label><input type="checkbox" name="wp_cloud_enabled" value="1" <?php echo get_option('wp_cloud_enabled')!=='0'?'checked':''; ?>> Cloud API Aktif</label></div>
            </div>
            <div class="col-md-3">
              <div class="checkbox"><label><input type="checkbox" name="wp_qr_enabled" value="1" <?php echo get_option('wp_qr_enabled')==='1'?'checked':''; ?>> QR (wa-lazy) Aktif</label></div>
            </div>
          </div>
          <hr/>
          <h4 class="tw-mb-2">QR (wa-lazy) Ayarları</h4>
<?php if($has_accounts){ ?>
<p class="text-warning">Çoklu hesap modu aktif. Aşağıdaki genel QR alanları <strong>kullanılmıyor</strong>. Lütfen <a href="<?= admin_url('whatsapp_plus/accounts') ?>">Hesaplar</a> sayfasından cihaz bazlı ayar yapın.</p>
<?php } ?>
          <div class="row">
            <div class="col-md-6">
              <?php echo render_input('wp_qr_api_url','API Base URL', get_option('wp_qr_api_url'), 'text', ['placeholder'=>'https://your-wa-gateway.tld'] + ($has_accounts ? ['disabled'=>'disabled'] : [])); ?>
            </div>
            <div class="col-md-6">
              <?php echo render_input('wp_qr_api_key','API Key', get_option('wp_qr_api_key'), 'text', $has_accounts ? ['disabled'=>'disabled'] : []); ?>
            </div>
            <div class="col-md-4">
              <?php echo render_input('wp_qr_device','Device (adı/ID)', get_option('wp_qr_device'), 'text', $has_accounts ? ['disabled'=>'disabled'] : []); ?>
            </div>
            <div class="col-md-4">
              <?php echo render_input('wp_qr_send_text_path','Send Text Path', get_option('wp_qr_send_text_path') ?: '/api/send-text', 'text', $has_accounts ? ['disabled'=>'disabled'] : []); ?>
            </div>
            <div class="col-md-4">
              <?php echo render_input('wp_qr_send_media_path','Send Media Path', get_option('wp_qr_send_media_path') ?: '/api/send-media', 'text', $has_accounts ? ['disabled'=>'disabled'] : []); ?>
            </div>
          </div>
          <p>QR Webhook URL: <code><?php echo site_url('whatsapp_plus/qr_webhook'); ?></code></p>
          <button type="submit" class="btn btn-primary"><?php echo _l('settings_save'); ?></button>
        <?php echo form_close(); ?>
        <hr/>
        <p><strong>Webhook URL:</strong> <code><?php echo site_url('whatsapp_plus/webhook'); ?></code></p>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
