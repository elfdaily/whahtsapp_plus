<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="tw-mb-4">QR Logları</h4>
            <p>Bu sayfa yalnızca <strong>QR/wa-lazy</strong> kaynaklı logları gösterir. Cloud API logları <a href="<?php echo admin_url('whatsapp_plus/logs'); ?>">burada</a>.</p>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead><tr><th>ID</th><th>Zaman</th><th>Seviye</th><th>Başlık</th><th>İçerik</th></tr></thead>
                <tbody>
                  <?php foreach(($db_rows??[]) as $r): ?>
                    <tr>
                      <td><?php echo (int)$r['id']; ?></td>
                      <td><?php echo html_escape($r['created_at']); ?></td>
                      <td><?php echo html_escape($r['tag']); ?></td>
                      <td><?php echo html_escape($r['source']); ?></td>
                      <td><pre style="white-space:pre-wrap;"><?php echo html_escape($r['text']); ?></pre></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
            <h5>Webhook Ham Log</h5>
            <pre style="max-height:420px;overflow:auto;background:#0b1021;color:#a6e22e;padding:12px;border-radius:4px;"><?php echo html_escape($log_text ?? ''); ?></pre>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
