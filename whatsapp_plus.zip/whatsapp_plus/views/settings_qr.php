<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="tw-mb-4">QR (wa-lazy) Entegrasyonu</h4>
            <p class="tw-text-slate-600">Bu alan, QR tabanlı gateway ile gönderim/alım yapmak içindir. Mevcut Cloud API ayarlarını <em>bozmadan</em> ek olarak kullanılır.</p>
            <a class="btn btn-sm btn-secondary" href="<?= admin_url('whatsapp_plus/accounts') ?>">Hesaplar</a><hr/>
            <?php echo form_open(admin_url('whatsapp_plus/qr_settings')); ?>
              <div class="row">
                <div class="col-md-6">
                  <?php echo render_input('wp_qr_api_url','API Base URL', get_option('wp_qr_api_url'), 'text', ['placeholder'=>'https://your-wa-gateway.tld/api']); ?>
                </div>
                <div class="col-md-6">
                  <?php echo render_input('wp_qr_api_key','API Key', get_option('wp_qr_api_key'), 'text'); ?>
                </div>
                <div class="col-md-4">
                  <?php echo render_input('wp_qr_device','Device (adı/ID)', get_option('wp_qr_device'), 'text'); ?>
                </div>
                <div class="col-md-4">
                  <?php echo render_input('wp_qr_send_text_path','Send Text Path', get_option('wp_qr_send_text_path') ?: '/api/send-text', 'text'); ?>
                </div>
                <div class="col-md-4">
                  <?php echo render_input('wp_qr_send_media_path','Send Media Path', get_option('wp_qr_send_media_path') ?: '/api/send-media', 'text'); ?>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group">
                  <div class="checkbox checkbox-primary">
                    <input type="checkbox" name="wp_qr_assume_delivered_on_200" id="wp_qr_assume_delivered_on_200" value="1" <?php echo get_option('wp_qr_assume_delivered_on_200')==='1'?'checked':''; ?>>
                    <label for="wp_qr_assume_delivered_on_200">HTTP 200 geldiğinde <strong>teslim (✔✔)</strong> varsay</label>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <div class="checkbox checkbox-primary">
                    <input type="checkbox" name="wp_qr_assume_read_on_incoming" id="wp_qr_assume_read_on_incoming" value="1" <?php echo get_option('wp_qr_assume_read_on_incoming')==='1'?'checked':''; ?>>
                    <label for="wp_qr_assume_read_on_incoming">Karşıdan mesaj gelince <strong>okundu (mavi ✔✔)</strong> varsay</label>
                  </div>
                </div>
              </div>

              <p class="tw-text-slate-600 tw-mt-2">
                Webhook URL: <code><?php echo site_url('whatsapp_plus/qr_webhook'); ?></code>
              </p>
              <button type="submit" class="btn btn-primary"><?php echo _l('settings_save'); ?></button>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
