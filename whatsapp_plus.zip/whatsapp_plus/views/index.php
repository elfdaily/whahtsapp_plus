<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <h4 class="no-margin"><?php echo _l('whatsapp_plus_title'); ?></h4>
            <hr/>
            <div class="wp-inbox">
              <div class="wp-threads" id="wpThreads"></div>
              <div class="wp-chat">
                <div class="wp-chat-body" id="wpChatBody">
                  <em><?php echo _l('whatsapp_plus_pick_thread'); ?></em>
                </div>
                <div class="wp-chat-input">
                  <input type="text" id="wpInput" class="form-control" placeholder="<?php echo _l('message'); ?>" disabled>
                  <button class="btn btn-success" id="wpSend" disabled><?php echo _l('send'); ?></button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php init_tail(); ?>
<script>
(function(){
  const $threads = $('#wpThreads');
  const $chat = $('#wpChatBody');
  let currentPhone = null;

  function esc(s){ return $('<div/>').text(s||'').html(); }
  function threadRow(t){
     const name = t.contact_name ? esc(t.contact_name) : esc(t.phone);
     const time = t.last_at ? esc(t.last_at) : '';
     return `<div class="wp-thread" data-phone="${esc(t.phone)}">
              <div><strong>${name}</strong></div>
              <small style="color:#777">${time}</small>
             </div>`;
  }
  function renderThreads(list){
     $threads.html(list.map(threadRow).join(''));
  }
  function renderMessages(list){
     if (!list.length){ $chat.html('<em>Empty</em>'); return; }
     $chat.html(list.map(function(m){
        const dir = m.direction || 'in';
        const body = esc(m.body || '');
        const at = esc(m.created_at || '');
        return `<div class="wp-msg ${dir}"><div>${body}</div><small style="color:#888">${at}</small></div>`;
     }).join(''));
     $chat.scrollTop($chat[0].scrollHeight);
  }

  function loadThreads(){
     $.getJSON(admin_url + 'whatsapp_plus/threads_json', function(r){
        if (r && r.ok){ renderThreads(r.threads||[]); }
     });
  }
  function loadConv(phone){
     $.getJSON(admin_url + 'whatsapp_plus/conversation_json/' + encodeURIComponent(phone), function(r){
        if (r && r.ok){
          renderMessages(r.messages||[]);
          $('#wpInput,#wpSend').prop('disabled', false);
        }
     });
  }

  $threads.on('click', '.wp-thread', function(){
     $('.wp-thread').removeClass('active');
     $(this).addClass('active');
     currentPhone = $(this).data('phone');
     loadConv(currentPhone);
  });

  loadThreads();
  setInterval(loadThreads, 15000);
})();
</script>
</body>
</html>
