<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper"><div class="content">
<div class="row"><div class="col-md-12">
  <div class="panel_s"><div class="panel-body">
    <h4 class="tw-mb-2">WhatsApp Hesapları (QR / wa-lazy)</h4>
    <p class="text-muted">Her numara için ayrı API anahtarı, cihaz adı ve webhook token kullanın. Dayxen cihaz webhook adresi: 
      <code><?= site_url('whatsapp_plus/qr_webhook'); ?>?token=&lt;TOKEN&gt;</code>
    </p>
    <hr/>
    <?php echo form_open(admin_url('whatsapp_plus/account_save')); ?>
      <div class="row">
        <div class="col-md-3"><?php echo render_input('label','Etiket (görünen ad)'); ?></div>
        <div class="col-md-3"><?php echo render_input('qr_device','Cihaz/Device'); ?></div>
        <div class="col-md-3"><?php echo render_input('qr_api_url','API URL','', 'text', ['placeholder'=>'https://dayxen.tld/api']); ?></div>
        <div class="col-md-3"><?php echo render_input('qr_api_key','API KEY'); ?></div>
      </div>
      <div class="row">
        <div class="col-md-2"><?php echo render_select('qr_payload_mode',[['id'=>'form','name'=>'form'],['id'=>'json','name'=>'json']],['id','name'],'Payload','form'); ?></div>
        <div class="col-md-3"><?php echo render_input('qr_send_text_path','Text Path','/api/send-text'); ?></div>
        <div class="col-md-3"><?php echo render_input('qr_send_media_path','Media Path','/api/send-media'); ?></div>
        <div class="col-md-4"><?php echo render_input('webhook_token','Webhook TOKEN'); ?></div>
      </div>
      <button class="btn btn-primary">Kaydet</button>
    <?php echo form_close(); ?>
    <hr/>
    <h4 class="tw-mt-3">Kayıtlı Hesaplar</h4>
    <table class="table table-striped">
      <thead><tr><th>ID</th><th>Etiket</th><th>Cihaz</th><th>Webhook</th><th></th></tr></thead>
      <tbody>
        <?php foreach($accounts as $a): ?>
          <tr>
            <?php $id = isset($a['id']) ? (int)$a['id'] : 0; ?>
<td><?= $id ?></td>
            <?php $label = isset($a['label']) ? $a['label'] : (isset($a['name'])?$a['name']:''); ?>
<td><?= html_escape($label !== '' ? $label : '-') ?></td>
            <?php $dev = isset($a['qr_device']) ? $a['qr_device'] : (isset($a['device'])?$a['device']:''); ?>
<td><?= html_escape($dev !== '' ? $dev : '-') ?></td>
            <?php $tok = isset($a['webhook_token']) ? $a['webhook_token'] : ''; ?>
<td><?php if ($tok): ?><code><?= site_url('whatsapp_plus/qr_webhook'); ?>?token=<?= html_escape($tok) ?></code><?php else: ?><span class="text-muted">—</span><?php endif; ?></td>
            <td><a href="<?= admin_url('whatsapp_plus/account_delete/'.(int)$a['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Silinsin mi?')">Sil</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div></div>
</div></div>
</div></div>
<?php init_tail(); ?>
