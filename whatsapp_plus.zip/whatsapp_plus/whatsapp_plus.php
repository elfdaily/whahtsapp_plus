<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: WhatsApp Plus
Description: WhatsApp Business Cloud API entegrasyonu. Mesajlar, Ayarlar ve Loglar. (Şablonlar/Kampanyalar/Kontrol Paneli kaldırıldı)

Author: Iteally (revamped by ChatGPT)
*/

define('WHATSAPP_PLUS_MODULE_NAME', 'whatsapp_plus');
define('WHATSAPP_PLUS_MODULE_PATH', module_dir_path(WHATSAPP_PLUS_MODULE_NAME));
define('WHATSAPP_PLUS_BASE_URL', module_dir_url(WHATSAPP_PLUS_MODULE_NAME));

register_language_files(WHATSAPP_PLUS_MODULE_NAME, ['whatsapp_plus']);

/** Admin CSS/JS **/
hooks()->add_action('admin_head', 'whatsapp_plus_admin_head');
hooks()->add_action('admin_init', 'whatsapp_plus_register_menu');
hooks()->add_action('admin_init', 'whatsapp_plus_maybe_install');

/** Menü **/
function whatsapp_plus_register_menu()
{
    $CI = &get_instance();
    if (!is_staff_logged_in()) {
        return;
    }
    // Ana menü
    if (function_exists('has_permission') && has_permission('whatsapp_plus','', 'view')) {
$CI->app_menu->add_sidebar_menu_item('whatsapp_plus', [
        'name'     => 'WhatsApp',
        'position' => 61,
        'icon'     => 'fa fa-whatsapp',
        'href'     => admin_url('whatsapp_plus'),
    ]);
    }
// Çocuklar
    $CI->app_menu->add_sidebar_children_item('whatsapp_plus', [
        'slug'  => 'whatsapp_plus_messages',
        'name'  => _l('whatsapp_plus_messages'),
        'icon'  => 'fa fa-comments',
        'href'  => admin_url('whatsapp_plus'),
    ]);
    $CI->app_menu->add_sidebar_children_item('whatsapp_plus', [
        'slug'  => 'whatsapp_plus_settings',
        'name'  => _l('settings'),
        'icon'  => 'fa fa-cog',
        'href'  => admin_url('whatsapp_plus/settings'),
    ]);
    $CI->app_menu->add_sidebar_children_item('whatsapp_plus', [
        'slug'  => 'whatsapp_plus_logs',
        'name'  => _l('logs'),
        'icon'  => 'fa fa-list',
        'href'  => admin_url('whatsapp_plus/logs'),
    ]);
}

/** Kurulum / Şema kontrolü (DB silinse bile tekrar oluşturur) **/
function whatsapp_plus_maybe_install()
{
    require_once __DIR__ . '/install.php';
    try {
        whatsapp_plus_install(); // idempotent
    } catch (Throwable $e) {
        // sessizce geç
    }
}

// Load hooks & assets
require_once __DIR__ . '/init.php';
