<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Whatsapp_plus_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('whatsapp_plus/whatsapp_plus');
        if (function_exists('whatsapp_plus_install')) {
            whatsapp_plus_install();
        }
    }

    /** Tek kayıt ekle (gelen/giden) */
    public function log_message($data)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            whatsapp_plus_install();
        }
        if (!isset($data['account_id']) || $data['account_id'] === null) {
            $data['account_id'] = 0;
        }
        if (isset($data['phone'])) {
            $data['phone_e164'] = function_exists('wp_normalize_phone') ? wp_normalize_phone($data['phone']) : $data['phone'];
        }
        $fields = $this->db->list_fields(db_prefix().'whatsapp_plus_messages');
$data = array_intersect_key($data, array_flip($fields));
$this->db->insert(db_prefix() . 'whatsapp_plus_messages', $data);
        $ins_id = $this->db->insert_id();

        // Fallback: inbound text that is actually a filename -> create media row
        if ((empty($data['__attachments']) || !is_array($data['__attachments']))
            && isset($data['direction']) && $data['direction'] === 'in'
            && isset($data['body']) && is_string($data['body'])) {

            $bodyName = trim($data['body']);
            if (preg_match('~\.(png|jpe?g|gif|webp|pdf|mp4|mov|webm|mp3|m4a|ogg|wav)$~i', $bodyName)) {
                $med_tbl = db_prefix().'whatsapp_plus_media';
                if ($this->db->table_exists($med_tbl)) {
                    $fields = $this->db->list_fields($med_tbl);
                    $ext = strtolower(pathinfo($bodyName, PATHINFO_EXTENSION));
                    $t = 'document';
                    if (in_array($ext, ['png','jpg','jpeg','gif','webp'])) { $t='image'; }
                    elseif (in_array($ext, ['mp4','mov','webm'])) { $t='video'; }
                    elseif (in_array($ext, ['mp3','m4a','ogg','wav'])) { $t='audio'; }

                    $rowm = ['message_id'=>$ins_id];
                    if (in_array('account_id', $fields, true) && isset($data['account_id'])) { $rowm['account_id'] = $data['account_id']; }
                    if (in_array('type', $fields, true))       { $rowm['type'] = $t; }
                    if (in_array('media_type', $fields, true))  { $rowm['media_type'] = $t; }
                    if (in_array('filename', $fields, true))    { $rowm['filename'] = $bodyName; }
                    if (in_array('file_path', $fields, true))   { $rowm['file_path'] = null; }
                    if (in_array('url', $fields, true))         { $rowm['url'] = null; }
                    if (in_array('caption', $fields, true))     { $rowm['caption'] = ''; }
                    if (in_array('created_at', $fields, true))  { $rowm['created_at'] = date('Y-m-d H:i:s'); }

                    $rowm = array_intersect_key($rowm, array_flip($fields));
                    if (!empty($rowm)) { $this->db->insert($med_tbl, $rowm); }
                }
            }
        }


        // Attachments (optional): if provided via '__attachments', insert into whatsapp_plus_media
        if (!empty($data['__attachments']) && is_array($data['__attachments'])) {
            $med_tbl = db_prefix().'whatsapp_plus_media';
            if ($this->db->table_exists($med_tbl)) {
                $med_fields = $this->db->list_fields($med_tbl);
                foreach ($data['__attachments'] as $att) {
                    if (!is_array($att)) continue;
                    $att['message_id'] = $ins_id;
                    // If schema has account_id, pass through from message data
                    if (in_array('account_id', $med_fields, true) && isset($data['account_id'])) {
                        $att['account_id'] = $data['account_id'];
                    }
                    $att = array_intersect_key($att, array_flip($med_fields));
                    if (!empty($att)) {
                        $this->db->insert($med_tbl, $att);
                    }
                }
            }
        }
    
        // wa_message_id fallback for QR setups: ensure non-NULL on outgoing rows
        if ((!isset($data['wa_message_id']) || !$data['wa_message_id']) && isset($data['direction']) && $data['direction']==='out') {
            $fake = 'qr:' . time() . ':' . substr(md5(mt_rand()),0,6);
            $this->db->where('id', $ins_id)->update(db_prefix() . 'whatsapp_plus_messages', ['wa_message_id' => $fake]);
            $data['wa_message_id'] = $fake;
        }
    
        if (!empty($data['phone_e164'])) {
            $this->upsert_contact($data['phone_e164'], isset($data['contact_name']) ? $data['contact_name'] : null);
        }
        return $ins_id;
    }

    /** Kişi adını güncelle/ekle */
    public function upsert_contact($phone_e164, $name = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_contacts')) {
            return;
        }
        $now = date('Y-m-d H:i:s');
        $row = $this->db->where('phone_e164', $phone_e164)->get(db_prefix() . 'whatsapp_plus_contacts')->row_array();
        if ($row) {
            $upd = ['updated_at' => $now];
            if ($name && (empty($row['name']) || $row['name'] !== $name)) {
                $upd['name'] = $name;
            }
            if (!empty($upd)) {
                $this->db->where('id', $row['id'])->update(db_prefix() . 'whatsapp_plus_contacts', $upd);
            }
        } else {
            $this->db->insert(db_prefix() . 'whatsapp_plus_contacts', [
                'phone_e164' => $phone_e164,
                'name'       => $name,
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        }
    }

    /** Son konuşma listesi (normalize edilerek tekilleştirilmiş) */
    public function list_threads($limit = 200, $account_id = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            return [];
        }
        $tbl = db_prefix() . 'whatsapp_plus_messages';
        $ct  = db_prefix() . 'whatsapp_plus_contacts';

        // Son N kaydı çek
        $N = max($limit * 5, 500);
        $this->db->order_by('id','DESC');
        $this->db->limit($N);
        $acc = $account_id; if ($acc!==null) { $this->db->where('account_id', (int)$acc); }
        $rows = $this->db->get($tbl)->result_array();

        // Telefon başına tekilleştir + son mesaj gövdesi ve zamanı
        $map = []; $nameByPhone = []; $hasIn = [];
        foreach ($rows as $r) {
            $key = !empty($r['phone_e164']) ? $r['phone_e164'] : (function_exists('wp_normalize_phone') ? wp_normalize_phone($r['phone']) : $r['phone']);
            $hasIn[$key] = ($hasIn[$key] ?? false) || (($r['direction'] ?? 'in') === 'in');
            if (!isset($map[$key]) || $r['id'] > $map[$key]['id']) { $nameByPhone[$key] = !empty($r['contact_name']) ? $r['contact_name'] : (isset($nameByPhone[$key])?$nameByPhone[$key]:null);
                $map[$key] = [
                    'id'         => $r['id'],
                    'phone'      => $r['phone'],
                    'phone_e164' => $key,
                    'created_at' => $r['created_at'],
                    'last_body'  => isset($r['body']) ? $r['body'] : null,
                ];
            }
        }

        // id desc'e göre sırala
        usort($map, function($a,$b){ return ($a['id'] < $b['id']) ? 1 : -1; });
        $threads = array_values(array_filter($map, function($t) use ($hasIn){ $k = $t['phone_e164']; return !isset($hasIn[$k]) || $hasIn[$k]; }));
        /*__ONLY_INCOMING_FILTER__*/
        $threads = array_slice($threads, 0, $limit);
        // Attach important flag
        $impPhones = $this->list_important_threads();
        $impSet = array_flip($impPhones);
        foreach ($threads as &$__t) { $__t['important'] = isset($impSet[$__t['phone_e164']]) ? 1 : 0; }
// İsim ve unread sayacı
        if ($this->db->table_exists($ct) && !empty($threads)) {
            $phones = array_map(function($x){ return $x['phone_e164']; }, $threads);
            // isimler
            $this->db->where_in('phone_e164', $phones);
            $crows = $this->db->get($ct)->result_array();
            $cmap = []; $lmap = [];
            foreach ($crows as $c) { $cmap[$c['phone_e164']] = $c['name']; $lmap[$c['phone_e164']] = isset($c['last_open_at']) ? $c['last_open_at'] : null; }
            // unread
            foreach ($threads as &$t) {
                $p = $t['phone_e164'];
                if (isset($cmap[$p])) $t['contact_name'] = $cmap[$p];
                $last_open = isset($lmap[$p]) ? $lmap[$p] : null;
                if ($last_open) {
                    $this->db->where('phone_e164', $p);
                    $this->db->where('direction', 'in');
                    $this->db->where('created_at >', $last_open);
                    $t['unread'] = $this->db->count_all_results($tbl);
                } else {
                    // Hiç açılmadıysa tüm gelenleri unread say
                    $this->db->where('phone_e164', $p);
                    $this->db->where('direction', 'in');
                    $t['unread'] = $this->db->count_all_results($tbl);
                }
            }
        } else {
            foreach ($threads as &$t) { $t['unread'] = 0; }
        }

        return $threads;
    }

    /** Bir numaranın tüm konuşması (kronolojik) */
    public function get_conversation($phone, $limit = 200, $account_id = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_messages')) {
            return [];
        }
        $pkey = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone;
        $this->db->group_start();
        $this->db->where('phone_e164', $pkey);
        //_where('phone', $pkey);
        $this->db->group_end();
        $this->db->order_by('id','DESC');
        $this->db->limit($limit);
        $acc = $account_id; if ($acc!==null) { $this->db->where('account_id', (int)$acc); }
        $rows = $this->db->get(db_prefix() . 'whatsapp_plus_messages')->result_array();
        return array_reverse($rows);
    }

    /** Basit log satırı ekle (DB) */
    public function log_line($source, $tag, $text, $meta = null)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            whatsapp_plus_install();
        }
        $data = [
            'source'    => $source,
            'tag'       => $tag,
            'text'      => $text,
            'meta_json' => is_string($meta) ? $meta : json_encode($meta),
            'created_at'=> date('Y-m-d H:i:s'),
        ];
        $this->db->insert(db_prefix() . 'whatsapp_plus_logs', $data);
        return $this->db->insert_id();
    }

    /** Son X log satırı (en yeni önce) */
    public function list_logs($limit = 1000)
    {
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            return [];
        }
        $this->db->order_by('id','DESC');
        $this->db->limit((int)$limit);
        return $this->db->get(db_prefix() . 'whatsapp_plus_logs')->result_array();
    }

    /** Logları temizle */
    public function clear_logs()
    {
        if ($this->db->table_exists(db_prefix() . 'whatsapp_plus_logs')) {
            $this->db->truncate(db_prefix() . 'whatsapp_plus_logs');
        }
    }

    /** Konuşma açıldığında son açılma zamanını güncelle */
    public function mark_opened($phone){
        if (!$this->db->table_exists(db_prefix() . 'whatsapp_plus_contacts')) { return; }
        $pkey = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone;
        $row = $this->db->where('phone_e164',$pkey)->get(db_prefix().'whatsapp_plus_contacts')->row_array();
        $now = date('Y-m-d H:i:s');
        if ($row){
            $this->db->where('id',$row['id'])->update(db_prefix().'whatsapp_plus_contacts', ['last_open_at'=>$now, 'updated_at'=>$now]);
        } else {
            $this->db->insert(db_prefix().'whatsapp_plus_contacts',[
                'phone_e164'=>$pkey, 'name'=>null, 'created_at'=>$now, 'updated_at'=>$now, 'last_open_at'=>$now
            ]);
        }
    }

    public function get_messages_after($phone, $after_id = 0, $limit = 200, $account_id = null){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_messages')) { return []; }
        $tbl = db_prefix().'whatsapp_plus_messages';
        $this->db->where('phone_e164', $phone);
        if ($after_id > 0) { $this->db->where('id >', $after_id); }
        //order_by('id','ASC');
        $this->db->limit($limit);
        $acc = $account_id; if ($acc!==null) { $this->db->where('account_id', (int)$acc); }
        return $this->db->get($tbl)->result_array();
    }

    private function is_thread_important_internal($phone){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_important_threads')) { return false; }
        $pkey = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone;
        $row = $this->db->where('phone_e164',$pkey)->get(db_prefix().'whatsapp_plus_important_threads')->row_array();
        if ($row) return true;
        // Also mark important if the last 500 messages of the thread include any important message
        if ($this->db->table_exists(db_prefix().'whatsapp_plus_messages')){
            $this->db->where('phone_e164', $pkey);
            $this->db->where('is_important', 1);
            $this->db->limit(1);
            $q = $this->db->get(db_prefix().'whatsapp_plus_messages');
            return $q->num_rows() > 0;
        }
        return false;
    }
    


public function set_message_important($id, $flag = 1){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_messages')) { return false; }
        $this->db->where('id', (int)$id)->update(db_prefix().'whatsapp_plus_messages', ['is_important' => $flag ? 1 : 0]);
        return $this->db->affected_rows() > 0;
    }


public function set_thread_important($phone, $flag = 1){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_important_threads')) { return false; }
        $pkey = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone;
        if ($flag) {
            // upsert (unique key on phone)
            $exists = $this->db->where('phone_e164', $pkey)->get(db_prefix().'whatsapp_plus_important_threads')->row_array();
            if (!$exists){
                $this->db->insert(db_prefix().'whatsapp_plus_important_threads', ['phone_e164'=>$pkey, 'created_at'=>date('Y-m-d H:i:s')]);
            }
        } else {
            $this->db->where('phone_e164', $pkey)->delete(db_prefix().'whatsapp_plus_important_threads');
        }
        return true;
    }

    /** Return media rows for a given message id */
    public function get_media_by_message($message_id)
    {
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_media')) return [];
        return $this->db->where('message_id', $message_id)
                        ->order_by('id', 'asc')
                        ->get(db_prefix().'whatsapp_plus_media')
                        ->result_array();
    }



public function list_important_threads(){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_important_threads')) { return []; }
        $rows = $this->db->get(db_prefix().'whatsapp_plus_important_threads')->result_array();
        return array_map(function($r){ return $r['phone_e164']; }, $rows);
    }



    public function get_media($id){
        if (!$this->db->table_exists(db_prefix().'whatsapp_plus_media')) return null;
        return $this->db->where('id', (int)$id)->get(db_prefix().'whatsapp_plus_media')->row_array();
    }

    /** Accounts helpers (QR/Cloud) **/
    public function get_accounts($provider = null){
        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return [];
        $cols = $this->db->list_fields($tbl);
        if ($provider && in_array('provider', $cols, true)){ $this->db->where('provider', $provider); }
        if (in_array('is_default', $cols, true)) { $this->db->order_by('is_default','DESC'); }
        $this->db->order_by('id','ASC');
        return $this->db->get($tbl)->result_array();
    }
    public function get_account($id){
        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return null;
        return $this->db->where('id',(int)$id)->get($tbl)->row_array();
    }
    public function find_account_by_token($token){
        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return null;
        if (!$token) return null;
        return $this->db->where('webhook_token',$token)->get($tbl)->row_array();
    }
    public function find_account_by_device($device){
        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return null;
        if (!$device) return null;
        return $this->db->where('qr_device',$device)->get($tbl)->row_array();
    }
    
    public function save_account($data){
        // Ensure schema is up-to-date
        if (function_exists('whatsapp_plus_install')) { whatsapp_plus_install(); }

        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return false;

        $now = date('Y-m-d H:i:s');
        $data['updated_at'] = $now;

        // ensure token value present
        if (empty($data['webhook_token'])){
            $data['webhook_token'] = bin2hex(random_bytes(16));
        }

        // only keep columns that actually exist (robust against older schemas)
        $fields = $this->db->list_fields($tbl);
        $data = array_intersect_key($data, array_flip($fields));

        if (!empty($data['id'])){
            $id = (int)$data['id']; unset($data['id']);
            $this->db->where('id',$id)->update($tbl, $data);
            return $id;
        } else {
            if (in_array('created_at', $fields, true)) { $data['created_at'] = $now; }
            $this->db->insert($tbl, $data);
            return $this->db->insert_id();
        }
    }
    public function delete_account($id){
        $tbl = db_prefix().'whatsapp_plus_accounts';
        if (!$this->db->table_exists($tbl)) return false;
        $this->db->where('id',(int)$id)->delete($tbl);
        return true;
    }



    /**
 * Check if a QR account exists and active
 */
public function account_exists($id)
{
    $id = (int) $id;
    if (!$id) { return false; }

    $sql = "SELECT id FROM " . db_prefix() . "whatsapp_plus_accounts
            WHERE id = ? AND provider = 'qr' AND status = 1
            LIMIT 1";
    $row = $this->db->query($sql, [$id])->row_array();

    return !empty($row['id']);
}

public function find_account_by_phone_number_id($pnid){
    $tbl = db_prefix().'whatsapp_plus_accounts';
    if (!$this->db->table_exists($tbl)) return null;
    if (!$pnid) return null;
    return $this->db->where('phone_number_id',$pnid)->get($tbl)->row_array();
}


    public function get_media_by_filename($filename){
        $this->db->from(db_prefix().'whatsapp_plus_media');
        $this->db->where('filename', $filename);
        $this->db->order_by('id','DESC');
        return $this->db->get()->result_array();
    }
    
}
