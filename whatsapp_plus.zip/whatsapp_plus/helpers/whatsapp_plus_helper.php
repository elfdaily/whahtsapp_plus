<?php
defined('BASEPATH') or exit('No direct script access allowed');

function wp_option($k, $d = '')
{
    $v = function_exists('get_option') ? get_option($k) : '';
    return $v === '' ? $d : $v;
}
function wp_admin_view($view, $data = [])
{
    $CI = &get_instance();
    $CI->load->view('whatsapp_plus/' . $view, $data);
}
function wp_json_response($arr, $code = 200)
{
    header('Content-Type: application/json; charset=utf-8', true, $code);
    echo json_encode($arr);
    exit;
}

function wp_normalize_phone($s){
    $s = trim((string)$s);
    if ($s==='') return '';
    $has_plus = substr($s,0,1) === '+';
    $digits = preg_replace('/\D+/', '', $s);
    if ($digits==='') return '';
    if (!$has_plus && strpos($digits,'00')===0){ $digits = substr($digits,2); $has_plus = true; }
    return ($has_plus?'+' : '+') . $digits;
}


if (!function_exists('wa_bool_opt')) {
    function wa_bool_opt($key) {
        $v = function_exists('get_option') ? get_option($key) : null;
        return $v === '1' || $v === 1 || $v === true || $v === 'yes' || $v === 'on';
    }
}
if (!function_exists('wa_cloud_enabled')) {
    function wa_cloud_enabled() {
        return wa_bool_opt('wp_cloud_enabled')
            || wa_bool_opt('wp_cloud_active')
            || wa_bool_opt('cloud_api_enabled')
            || wa_bool_opt('cloud_api_active');
    }
}
