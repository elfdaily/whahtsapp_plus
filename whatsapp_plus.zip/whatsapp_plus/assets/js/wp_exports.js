(function(){
  // Guard: run once
  if (window.__wpExportsToolbarLoaded) return;
  window.__wpExportsToolbarLoaded = true;

  function onReady(fn){
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  onReady(function(){
    // Only on whatsapp_plus pages
    var href = (location.pathname + location.search).toLowerCase();
    if (href.indexOf('whatsapp_plus') === -1) return;

    
    // Show ONLY on Messages page (and module root which renders messages)
    var isMessages = /\/whatsapp_plus(?:\/messages(?:\/|$)|(?:\?|$)|$)/.test(href);
    if (!isMessages) return;
// URL builder (handles /admin/, /index.php/admin/, subfolders)
    function buildAdminUrl(path){
      // prefer global admin_url string if available
      if (typeof admin_url === 'string' && admin_url) {
        return admin_url.replace(/\/+$/, '/') + path.replace(/^\/+/, '');
      }
      // derive from current page up to /whatsapp_plus/
      try {
        var href = String(location.href);
        var idx = href.toLowerCase().indexOf('/whatsapp_plus/');
        if (idx > -1){
          var base = href.substring(0, idx+1); // keep trailing slash
          return base + path.replace(/^\/+/, '');
        }
      } catch (e) {}
      // derive from pathname including index.php/admin/
      try {
        var p = String(location.pathname), i = p.indexOf('/admin/');
        if (i>-1){
          var base = p.substring(0, i+7);
          if (base.charAt(0) !== '/') base = '/' + base;
          return base + path.replace(/^\/+/, '');
        }
      } catch (e) {}
      // final fallback: relative admin/
      return 'admin/' + path.replace(/^\/+/, '');
    }

    // Find admin base
    var adminBase = (typeof admin_url !== 'undefined' && admin_url) ? admin_url : (function(){
      var p = window.location.pathname, i = p.indexOf('/admin/');
      return i>-1 ? p.substring(0, i+7) : '/admin/';
    })();

    // Avoid duplicate toolbar
    if (document.querySelector('.wp-export-toolbar')) return;

    // Elements
    var wrap = document.createElement('div');
    wrap.className = 'wp-export-toolbar';
    wrap.innerHTML = ''
      + '<div class="wp-export-row">'
      + '  <div class="wp-export-left">'
      + '    <label class="wp-exp-label">Hesap:</label>'
      + '    <select id="wp-export-account" class="wp-exp-input"></select>'
      + '    <label class="wp-exp-label">Tarih:</label>'
      + '    <input type="date" id="wp-export-from" class="wp-exp-input" />'
      + '    <span class="wp-exp-dash">—</span>'
      + '    <input type="date" id="wp-export-to" class="wp-exp-input" />'
      + '  </div>'
      + '  <div class="wp-export-right">'
      + '    <button id="wp-btn-media-zip" class="wp-exp-btn">Medyayı İndir (ZIP)</button>'
      + '    <div class="wp-exp-menu">'
      + '      <button class="wp-exp-btn" id="wp-btn-export-menu">Mesajları Dışa Aktar ▾</button>'
      + '      <div class="wp-exp-dropdown" id="wp-export-dropdown" hidden>'
      + '        <a href="#" data-format="csv" class="wp-exp-dd-item">CSV</a>'
      + '        <a href="#" data-format="xlsx" class="wp-exp-dd-item">Excel (XLSX)</a>'
      + '        <a href="#" data-format="pdf" class="wp-exp-dd-item">PDF</a>'
      + '      </div>'
      + '    </div>'
      + '  </div>'
      + '</div>';

    var style = document.createElement('style');
    style.textContent = ''
      + '.wp-export-toolbar{position:sticky;bottom:0;z-index:999;background:#fff;border-top:1px solid #e5e7eb;padding:10px 12px;}'
      + '.wp-export-row{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;}'
      + '.wp-export-left,.wp-export-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}'
      + '.wp-exp-label{font-size:12px;color:#374151;}'
      + '.wp-exp-input{height:34px;padding:0 8px;border:1px solid #d1d5db;border-radius:8px;background:#fff;font-size:13px;}'
      + '.wp-exp-dash{color:#6b7280;}'
      + '.wp-exp-btn{height:36px;padding:0 12px;border-radius:10px;border:1px solid #16a34a;background:#22c55e;color:#fff;font-weight:600;cursor:pointer;}'
      + '.wp-exp-btn:hover{filter:brightness(0.95);}'
      + '.wp-exp-menu{position:relative;}'
      + '.wp-exp-dropdown{position:absolute;right:0;top:110%;min-width:180px;background:#fff;border:1px solid #e5e7eb;border-radius:10px;box-shadow:0 10px 20px rgba(0,0,0,.06);}'
      + '.wp-exp-dd-item{display:block;padding:10px 12px;text-decoration:none;color:#111827;font-size:14px;}'
      + '.wp-exp-dd-item:hover{background:#f3f4f6;}'
      + '@media (max-width:640px){.wp-export-left{width:100%;}.wp-export-right{width:100%;justify-content:space-between;}}';

    // Detect account id
    function detectAccountId(){
      // Prefer unified top account selector if present
      var wa = document.querySelector('#waAccount');
      if (wa && wa.value) return wa.value;

      // Legacy selectors in various pages
      var s = document.querySelector('select[name="account"]') || document.querySelector('#account') || document.querySelector('#wp-export-account');
      if (s && s.value) return s.value;

      // URL param fallback (?acc=ID)
      try {
        var sp = new URLSearchParams(location.search);
        var urlAcc = sp.get('acc');
        if (urlAcc) return urlAcc;
      } catch (e) {}

      // Server-rendered attributes fallback
      var el = document.querySelector('[data-active-account-id]');
      if (el) return el.getAttribute('data-active-account-id');
      return 0;
    }

    // Mount after the "Destek: ... storage/media" line if possible
    var anchor = document.querySelector('a[href*="modules/whatsapp_plus/storage/media"]');
    var target = null;
    if (anchor){
      target = anchor.closest('.row, .col-md-12, .panel, .panel-body') || anchor.parentElement;
    }
    if (!target) target = document.querySelector('.content .panel-body') || document.querySelector('.content') || document.body;

    // Append
    if (target){
      target.appendChild(style);
      target.appendChild(wrap);
    } else {
      document.head.appendChild(style);
      document.body.appendChild(wrap);
    }

    // Populate current account
    var accSelect = document.getElementById('wp-export-account');
    var val = detectAccountId();
    accSelect.innerHTML = '';
    var opt = document.createElement('option');
    opt.value = val; opt.textContent = val ? ('#'+val) : 'Seçilmedi';
    accSelect.appendChild(opt);
    // If top account dropdown (#waAccount) exists, mirror it and keep in sync
    var topSel = document.getElementById('waAccount');
    if (topSel) {
      var setFromTop = function(){
        // Copy value
        accSelect.value = topSel.value;
        // Replace single option to display the same text label as top dropdown
        accSelect.innerHTML = '';
        var o = document.createElement('option');
        o.value = topSel.value;
        o.textContent = (topSel.options[topSel.selectedIndex] || {}).text || ('#' + topSel.value);
        accSelect.appendChild(o);
      };
      setFromTop();
      // Keep in sync on change
      topSel.addEventListener('change', setFromTop);
      // Make the secondary selector read-only to avoid confusion
      accSelect.setAttribute('disabled', 'disabled');
      accSelect.title = 'Hesap seçimini yukarıdaki menüden yapın';
    } else {
      // If no top dropdown, keep the secondary selector enabled
      accSelect.removeAttribute('disabled');
    }

    // Dropdown logic
    var ddBtn = document.getElementById('wp-btn-export-menu');
    var dd = document.getElementById('wp-export-dropdown');
    ddBtn.addEventListener('click', function(e){ e.preventDefault(); dd.hidden = !dd.hidden; });
    document.addEventListener('click', function(e){ if(!dd.contains(e.target) && e.target!==ddBtn){ dd.hidden = true; } });

    // Date params
    function dateParams(){
      var from = document.getElementById('wp-export-from').value || '';
      var to   = document.getElementById('wp-export-to').value || '';
      var p = new URLSearchParams();
      if (from) p.set('from', from);
      if (to)   p.set('to', to);
      return p.toString();
    }

    // Media ZIP
    document.getElementById('wp-btn-media-zip').addEventListener('click', function(){
      var accId = String(parseInt(detectAccountId(), 10) || '').trim();
      var q = dateParams();
      window.location.href = buildAdminUrl('whatsapp_plus/exports/media_zip/' + accId + (q ? ('?'+q) : ''));
    });

    // Messages export
    dd.querySelectorAll('.wp-exp-dd-item').forEach(function(a){
      a.addEventListener('click', function(e){
        e.preventDefault();
        var format = this.getAttribute('data-format');
        var accId = String(parseInt(detectAccountId(), 10) || '').trim();
        var q = dateParams();
        window.location.href = buildAdminUrl('whatsapp_plus/exports/messages/' + accId + '/' + format + (q ? ('?'+q) : ''));
      });
    });
  });
})();