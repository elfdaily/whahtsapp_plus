<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Whatsapp_plus extends AdminController
{
    /* ---------- helpers ---------- */

    private function ensure_wp_migrations()
    {
        if (!property_exists($this, 'db') || !$this->db) { return; }

        $sqls = [
            // minimal tables; mevcut tablolarınız daha zenginse bunlar sadece "varsayılan kurulum" içindir
            "CREATE TABLE IF NOT EXISTS `tblwhatsapp_plus_messages` (
              `id` int unsigned NOT NULL AUTO_INCREMENT,
              `account_id` int unsigned DEFAULT NULL,
              `phone` varchar(32) DEFAULT NULL,
              `phone_e164` varchar(32) DEFAULT NULL,
              `direction` enum('in','out') NOT NULL DEFAULT 'out',
              `type` varchar(16) DEFAULT 'text',
              `body` longtext,
              `status` varchar(32) DEFAULT NULL,
              `wa_message_id` varchar(128) DEFAULT NULL,
              `meta_json` longtext,
              `error` longtext,
              `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
              `sent_at` datetime DEFAULT NULL,
              `delivered_at` datetime DEFAULT NULL,
              `read_at` datetime DEFAULT NULL,
              `is_important` tinyint(1) DEFAULT 0,
              `contact_name` varchar(191) DEFAULT NULL,
              PRIMARY KEY (`id`),
              KEY `idx_phone` (`phone_e164`),
              KEY `idx_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS `tblwhatsapp_plus_media` (
              `id` int unsigned NOT NULL AUTO_INCREMENT,
              `message_id` int unsigned NOT NULL,
              `type` varchar(16) DEFAULT 'document',
              `media_id` varchar(191) DEFAULT NULL,
              `file_path` text,
              `filename` varchar(255) DEFAULT NULL,
              `mime` varchar(128) DEFAULT NULL,
              `size` int unsigned DEFAULT NULL,
              `sha1` char(40) DEFAULT NULL,
              `caption` text,
              `meta_json` longtext,
              `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              KEY `idx_msg` (`message_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
            "CREATE TABLE IF NOT EXISTS `tblwhatsapp_plus_logs` (
              `id` int unsigned NOT NULL AUTO_INCREMENT,
              `direction` enum('in','out') NOT NULL DEFAULT 'out',
              `channel` varchar(16) NOT NULL DEFAULT 'qr',
              `to_number` varchar(64) DEFAULT NULL,
              `payload` longtext,
              `response_http` int DEFAULT NULL,
              `response_body` longtext,
              `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (`id`),
              KEY `idx_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        ];
        foreach ($sqls as $sql) { try { $this->db->query($sql); } catch (Exception $e) {} }

        $this->ensure_option('wp_qr_enabled', '1');
        $this->ensure_option('wp_active_provider', 'qr');
        $this->ensure_option('wp_channel', 'qr');
        $this->ensure_option('wp_qr_payload_mode', 'json');
        $this->ensure_option('wp_qr_api_url', 'https://wa-api.dayxen.com');
        $this->ensure_option('wp_qr_send_text_path', '/api/send-message');
        $this->ensure_option('wp_qr_send_media_path', '/api/send-media');
        $this->ensure_option('wp_qr_api_key', '');
        $this->ensure_option('wp_qr_device', '');
    }

    private function ensure_option($name, $default)
    {
        if (!property_exists($this, 'db') || !$this->db) { return; }
        $row = $this->db->query("SELECT name FROM tbloptions WHERE name = ?", [$name])->row();
        if (!$row) {
            $this->db->query("INSERT INTO tbloptions (name, value, autoload) VALUES (?, ?, 1)", [$name, $default]);
        }
    }

    private function get_active_account_id()
    {
        $accId = (int)($this->input->get('acc') ?: 0);
        if (!$accId) {
            $accId = (int)($this->session->userdata('wp_active_acc') ?: 0);
        }
        if (!$accId) {
            $row = $this->db->query("SELECT id FROM ".db_prefix()."whatsapp_plus_accounts WHERE provider='qr' AND status=1 AND is_default=1 ORDER BY id ASC LIMIT 1")->row_array();
            if (!empty($row['id'])) { $accId = (int)$row['id']; }
        }
        if (!$accId) {
            $row = $this->db->query("SELECT id FROM ".db_prefix()."whatsapp_plus_accounts WHERE provider='qr' AND status=1 ORDER BY id ASC LIMIT 1")->row_array();
            if (!empty($row['id'])) { $accId = (int)$row['id']; }
        }
        if ($accId) { $this->session->set_userdata('wp_active_acc', $accId); }
        return $accId;
    }

    private function normalize_phone($p)
    {
        if (!$p) return $p;
        return function_exists('wp_normalize_phone') ? wp_normalize_phone($p) : $p;
    }

    /* ---------- ctor ---------- */

    public function __construct()
    {
        parent::__construct();
        $this->ensure_wp_migrations();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->helper('whatsapp_plus/whatsapp_plus');
        $this->load->library('whatsapp_plus/WhatsAppCloudClient');
    }

    /* ---------- pages ---------- */

    public function index(){ return $this->messages(); }

    public function accounts()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { access_denied('whatsapp_plus'); }
        $data['title']    = 'WhatsApp Hesapları';
        $data['accounts'] = $this->whatsapp_plus_model->get_accounts('qr');
        $this->load->view('whatsapp_plus/accounts', $data);
    }

public function account_save()
{
    if (!has_permission('whatsapp_plus', '', 'create')) { access_denied('whatsapp_plus'); }

    $post = $this->input->post();

    // Zorunlu QR alanları
    $qr_api_url = rtrim($post['qr_api_url'] ?? '', '/');
    $qr_api_key = trim($post['qr_api_key'] ?? '');
    $qr_device  = trim($post['qr_device'] ?? '');

    if (!$qr_api_url || !$qr_api_key || !$qr_device) {
        set_alert('danger', 'QR API ayarları eksik');
        redirect(admin_url('whatsapp_plus/accounts'));
        return;
    }

    // Webhook token sanitize
    $raw = trim($post['webhook_token'] ?? '');
    $raw = urldecode($raw);
    if (stripos($raw, 'qr_webhook') !== false) {
        $pos = stripos($raw, '?token=');
        $raw = $pos !== false ? substr($raw, $pos + 7) : $raw;
    }
    $webhook_token = preg_replace('/\s+/', '', $raw);

    // path normalizasyonu
    $textPath  = '/' . ltrim($post['qr_send_text_path']  ?? '/api/send-text',  '/');
    $mediaPath = '/' . ltrim($post['qr_send_media_path'] ?? '/api/send-media', '/');

    $data = [
        'channel'            => 'qr',
        'provider'           => 'qr',
        'status'             => 1,

        'label'              => trim($post['label'] ?? ''),
        'qr_device'          => $qr_device,
        'qr_api_url'         => $qr_api_url,
        'qr_api_key'         => $qr_api_key,
        'qr_payload_mode'    => $post['qr_payload_mode'] ?? 'form',
        'qr_send_text_path'  => $textPath,
        'qr_send_media_path' => $mediaPath,
        'webhook_token'      => $webhook_token,
    ];

    if (!empty($post['id'])) { $data['id'] = (int)$post['id']; }

    $savedId = $this->whatsapp_plus_model->save_account($data);
    $accId   = $savedId ?: (!empty($post['id']) ? (int)$post['id'] : 0);

    if ($accId) {
        // yeni kaydı varsayılan yap
        $this->db->query("UPDATE ".db_prefix()."whatsapp_plus_accounts SET is_default=0 WHERE provider='qr'");
        $this->db->query("UPDATE ".db_prefix()."whatsapp_plus_accounts SET is_default=1 WHERE id=?", [$accId]);

        // oturumda aktif hesap
        $this->session->set_userdata('wp_active_acc', (int)$accId);

        set_alert('success', 'Hesap kaydedildi ve aktif hesap olarak ayarlandı.');
        // >>> Mesajlar yerine Hesaplar sayfasında kal
        redirect(admin_url('whatsapp_plus/accounts'));
        return;
    }

    set_alert('danger', 'Hesap kaydedilemedi.');
    redirect(admin_url('whatsapp_plus/accounts'));
}



public function account_delete($id)
{
    if (!has_permission('whatsapp_plus', '', 'delete')) { access_denied('whatsapp_plus'); }

    $ok = $this->whatsapp_plus_model->delete_account((int)$id);

    if ($ok) { set_alert('success', 'Hesap silindi.'); }
    else     { set_alert('danger', 'Hesap silinemedi.'); }

    redirect(admin_url('whatsapp_plus/accounts'));
}


    public function messages()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { access_denied('whatsapp_plus'); }

        $data['title'] = _l('whatsapp_plus_messages');

        // aktif hesap (URL → phone geçmişi → varsayılan)
        $accId = (int)($this->input->get('acc') ?: 0);
        if (!$accId) {
            $activePhone = $this->normalize_phone($this->input->get('phone'));
            if ($activePhone) {
                $row = $this->db->query("SELECT account_id FROM ".db_prefix()."whatsapp_plus_messages WHERE phone=? OR phone_e164=? ORDER BY id DESC LIMIT 1", [$activePhone, $activePhone])->row_array();
                if (!empty($row['account_id'])) { $accId = (int)$row['account_id']; }
            }
        }
        if (!$accId) { $accId = $this->get_active_account_id(); }
        $this->session->set_userdata('wp_active_acc', $accId);

        $data['accounts']   = $this->whatsapp_plus_model->get_accounts('qr');
        $data['active_acc'] = $accId;
        $data['threads']    = $this->whatsapp_plus_model->list_threads(400, $accId);

        $activeRaw   = $this->input->get('phone');
        $activePhone = $this->normalize_phone($activeRaw);
        if ($activePhone) { $this->whatsapp_plus_model->mark_opened($activePhone); }

        $data['active_phone'] = $activePhone; // normalized kullan
        $data['conversation'] = $activePhone ? $this->whatsapp_plus_model->get_conversation($activePhone, 400, $accId) : [];

        // aktif kişi adı
        $data['active_contact_name'] = $activePhone;
        if ($activePhone && !empty($data['threads'])) {
            foreach ($data['threads'] as $t) {
                $pkey = !empty($t['phone_e164']) ? $t['phone_e164'] : $t['phone'];
                if ($pkey === $activePhone) {
                    $data['active_contact_name'] = !empty($t['contact_name']) ? $t['contact_name'] : $pkey;
                    break;
                }
            }
        }

        $this->load->view('whatsapp_plus/messages', $data);
    }

    /* ---------- realtime APIs ---------- */

    public function poll_messages()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { wp_json_response(['success'=>false,'message'=>'forbidden'], 403); }

        $accId = $this->get_active_account_id();
        $phone = $this->normalize_phone($this->input->get('phone'));
        $after = (int)$this->input->get('after_id');

        $rows = $phone ? $this->whatsapp_plus_model->get_messages_after($phone, $after, 200, $accId) : [];
        $out  = [];

        foreach ($rows as $r) {
            list($att_html, $att_has_cap) = $this->_render_attachments_html($r['id']);
            $out[] = [
                'id'             => (int)$r['id'],
                'direction'      => $r['direction'],
                'body'           => isset($r['body']) ? $r['body'] : (isset($r['message']) ? $r['message'] : ''),
                'status'         => $r['status'],
                'important'      => isset($r['is_important']) ? (int)$r['is_important'] : 0,
                'created_at'     => $r['created_at'],
                'created_at_fmt' => _dt($r['created_at']),
                'meta_json'      => isset($r['meta_json']) ? $r['meta_json'] : null,
                'contact_name'   => isset($r['contact_name']) ? $r['contact_name'] : null,
                'attachments_html'=> $att_html,
                'has_caption'    => $att_has_cap,
            ];
        }

        // Late media updates (last 15m)
        $mediaUpdates = [];
        if ($this->db->table_exists(db_prefix().'whatsapp_plus_media')) {
            $tblM  = db_prefix().'whatsapp_plus_media';
            $tblMs = db_prefix().'whatsapp_plus_messages';
            $this->db->select("m.message_id as id, ms.body as body");
            $this->db->from("$tblM m");
            $this->db->join("$tblMs ms", "ms.id = m.message_id", "inner");
            $this->db->where('ms.phone_e164', $phone);
            $this->db->where('m.created_at >=', date('Y-m-d H:i:s', time()-15*60));
            $this->db->group_by('m.message_id');
            $recent = $this->db->get()->result_array();
            foreach ($recent as $rowM) {
                $mid = (int)$rowM['id'];
                list($att_html, $att_has_cap) = $this->_render_attachments_html($mid);
                $mediaUpdates[] = ['id'=>$mid, 'attachments_html'=>$att_html, 'has_caption'=>$att_has_cap];
            }
        }

        wp_json_response(['messages'=>$out, 'media_updates'=>$mediaUpdates]);
    }

    public function poll_threads()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { wp_json_response(['success'=>false,'message'=>'forbidden'], 403); }
        $accId   = $this->get_active_account_id();
        $threads = $this->whatsapp_plus_model->list_threads(200, $accId);
        wp_json_response(['threads'=>$threads]);
    }

    /** sadece durum (tik) */
public function status_poll()
{
    if (!has_permission('whatsapp_plus', '', 'view')) {
        wp_json_response(['success' => false, 'message' => 'forbidden'], 403);
    }

    $phone = $this->input->get('phone');
    if ($phone) { $phone = function_exists('wp_normalize_phone') ? wp_normalize_phone($phone) : $phone; }
    if (!$phone) { wp_json_response(['success'=>true,'statuses'=>[]]); }

    // 👇 EKSİK OLAN KISIM
    $accId = (int)($this->input->get('acc') ?: $this->session->userdata('wp_active_acc'));

    $limit = (int)($this->input->get('limit') ?: 120);
    if ($limit < 1 || $limit > 300) { $limit = 120; }

    $rows = $this->db->select('id, wa_message_id, status, delivered_at, read_at')
        ->where('direction', 'out')
        ->group_start()
            ->where('phone_e164', $phone)
            ->or_where('phone', $phone)
        ->group_end()
        ->where('account_id', (int)$accId)
        ->order_by('id', 'DESC')
        ->limit($limit)
        ->get(db_prefix().'whatsapp_plus_messages')
        ->result_array();

    $rows = array_reverse($rows); // eski→yeni
    wp_json_response(['success'=>true,'statuses'=>$rows]);
}



    public function typing()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { wp_json_response(['success'=>false], 403); }
        wp_json_response(['success'=>true]);
    }

    /* ---------- send (Cloud API) ---------- */

    public function send()
    {
        if (!wa_cloud_enabled()) { wp_json_response(['success'=>false,'message'=>'Cloud API şu an devre dışı.'], 422); }

        if (!has_permission('whatsapp_plus', '', 'create')) { access_denied('whatsapp_plus'); }

        $accId   = $this->get_active_account_id();
        $to      = $this->normalize_phone($this->input->post('to'));
        $type    = $this->input->post('attachment_type'); // image|document|audio|voice|event|none
        $caption = $this->input->post('caption');
        $text    = $this->input->post('text');
        $now     = date('Y-m-d H:i:s');

        if (!$to) { wp_json_response(['success'=>false,'message'=>'Missing recipient'], 422); }

        $storageDir = FCPATH . 'modules/whatsapp_plus/storage/media/' . date('Y/m');
        if (!is_dir($storageDir)) { @mkdir($storageDir, 0775, true); }

        $response = null; $code = null; $err = null; $wa_id = null; $message_type = 'text'; $fileRow = null;

        $handleUploadAndSend = function($expectedTypes, $sendCb) use ($storageDir, &$fileRow, &$code, &$response, &$err, &$wa_id, $caption, $to) {
            if (empty($_FILES['attachment']) || !is_uploaded_file($_FILES['attachment']['tmp_name'])) {
                wp_json_response(['success'=>false,'message'=>'Dosya yüklenmedi'], 422);
            }
            $tmp  = $_FILES['attachment']['tmp_name'];
            $name = $_FILES['attachment']['name'];
            $mime = $_FILES['attachment']['type'] ?: mime_content_type($tmp);
            $size = (int)$_FILES['attachment']['size'];

            $ok=false; foreach ($expectedTypes as $t){ if (stripos($mime,$t)===0){ $ok=true; break; } }
            if(!$ok && !in_array('any',$expectedTypes,true)){ wp_json_response(['success'=>false,'message'=>'Desteklenmeyen MIME türü: '.$mime], 422); }

            $sha1 = sha1_file($tmp);
            $safeName = preg_replace('~[^a-zA-Z0-9_.-]+~', '_', $name);
            $dest = rtrim($storageDir,'/').'/'.$sha1.'_'.$safeName;
            if (!@move_uploaded_file($tmp, $dest)) { if (!@copy($tmp,$dest)) { wp_json_response(['success'=>false,'message'=>'Dosya kaydedilemedi'], 500); } }

            list($ucode, $ures, $uerr) = $this->whatsappcloudclient->uploadMedia($dest, $mime);
            $response = $ures; $err=$uerr; $code=$ucode;

            $decoded = json_decode($ures, true);
            $media_id = (is_array($decoded) && isset($decoded['id'])) ? $decoded['id'] : null;

            if ($media_id) {
                list($scode, $sres, $serr) = $sendCb($media_id, $safeName);
                $code=$scode; $response=$sres; $err=$serr;
                $dec2 = json_decode($sres, true);
                if (is_array($dec2) && isset($dec2['messages'][0]['id'])) { $wa_id = $dec2['messages'][0]['id']; }
            }

            $fileRow = [
                'type'      => $expectedTypes[0] === 'any' ? 'document' : $expectedTypes[0],
                'media_id'  => isset($media_id) ? $media_id : null,
                'file_path' => str_replace(FCPATH, '', $dest),
                'filename'  => $safeName,
                'mime'      => $mime,
                'size'      => $size,
                'sha1'      => $sha1,
                'caption'   => $caption,
                'created_at'=> date('Y-m-d H:i:s'),
            ];
        };

        try {
            if ($type === 'image') {
                $message_type = 'image';
                $handleUploadAndSend(['image'], function($media_id) use ($to, $caption){ return $this->whatsappcloudclient->sendImageById($to,$media_id,(string)$caption); });
            } elseif ($type === 'audio' || $type === 'voice') {
                $message_type = 'audio';
                $handleUploadAndSend(['audio'], function($media_id) use ($to){ return $this->whatsappcloudclient->sendAudioById($to,$media_id); });
            } elseif ($type === 'document') {
                $message_type = 'document';
                $handleUploadAndSend(['any'], function($media_id, $filename) use ($to, $caption){ return $this->whatsappcloudclient->sendDocumentById($to,$media_id,$filename,(string)$caption); });
            } else {
                $text = trim((string)$text);
                if ($text===''){ wp_json_response(['success'=>false,'message'=>'Boş mesaj gönderilemez.'], 422); }
                list($code,$response,$err) = $this->whatsappcloudclient->sendText($to,$text);
                $message_type = 'text';
            }
        } catch (Exception $ex){ $code=500; $err=$ex->getMessage(); $response=null; }

        $status = ($code===200 ? 'sent' : 'error');
        $decoded = json_decode($response, true);
        if (is_array($decoded)) {
            if (isset($decoded['messages'][0]['id'])) { $wa_id = $decoded['messages'][0]['id']; }
            elseif (isset($decoded['messageId'])) { $wa_id = $decoded['messageId']; }
            elseif (isset($decoded['id'])) { $wa_id = $decoded['id']; }
            elseif (isset($decoded['data']['key']['id'])) { $wa_id = $decoded['data']['key']['id']; }
            elseif (isset($decoded['data']['id'])) { $wa_id = $decoded['data']['id']; }
        }
        if (empty($wa_id)) { $wa_id = 'qr:'.time().':'.substr(md5(mt_rand()),0,6); }

        $__meta_out = ['cloud_send'=>$decoded, 'wa_id'=>$wa_id];
        $msgId = $this->whatsapp_plus_model->log_message([
            'account_id'    => (int)$accId,
            'direction'     => 'out',
            'meta_json'     => json_encode($__meta_out, JSON_UNESCAPED_UNICODE),
            'phone'         => $to,
            'type'          => $message_type,
            'body'          => ($message_type==='text' ? $text : ($caption ?: '')),
            'status'        => $status,
            'wa_message_id' => $wa_id,
            'error'         => $err ?: ($code!==200 ? $response : null),
            'created_at'    => $now,
            'sent_at'       => ($code===200 ? $now : null),
        ]);

        if ($fileRow && $this->db->table_exists(db_prefix().'whatsapp_plus_media')) {
            $fileRow['message_id'] = $msgId;
            $this->db->insert(db_prefix().'whatsapp_plus_media', $fileRow);
        }

        $msgPayload = null;
        if ($this->db->table_exists(db_prefix().'whatsapp_plus_messages')) {
            $msgRow = $this->db->where('id',(int)$msgId)->get(db_prefix().'whatsapp_plus_messages')->row_array();
            if ($msgRow){
                $msgPayload = [
                    'id'           => (int)$msgRow['id'],
                    'direction'    => $msgRow['direction'],
                    'body'         => isset($msgRow['body']) ? $msgRow['body'] : (isset($msgRow['message'])?$msgRow['message']:''),
                    'status'       => $msgRow['status'],
                    'created_at'   => $msgRow['created_at'],
                    'phone_e164'   => $msgRow['phone_e164'],
                    'is_important' => isset($msgRow['is_important']) ? (int)$msgRow['is_important'] : 0,
                ];
            }
        }

        wp_json_response(['success'=>($code===200),'code'=>$code,'wa_id'=>$wa_id,'message'=>$msgPayload,'response'=>$decoded,'error'=>$err]);
    }

    /* ---------- send (QR / Dayxen) ---------- */

    public function send_qr()
    {
        // izin
        if (!has_permission('whatsapp_plus', '', 'create')) { access_denied('whatsapp_plus'); }
        if (!function_exists('wa_bool_opt') ? (get_option('wp_qr_enabled')!=='1') : !wa_bool_opt('wp_qr_enabled')) {
            return wp_json_response(['success'=>false,'message'=>'QR (wa-lazy) şu an devre dışı.'], 422);
        }

        $accId = (int)($this->input->post('account_id') ?: $this->session->userdata('wp_active_acc'));
        if (!$accId) { $accId = $this->get_active_account_id(); }
        $accRow = $accId ? $this->whatsapp_plus_model->get_account($accId) : null;

        $is_multipart = stripos((string)$this->input->server('CONTENT_TYPE'), 'multipart/form-data') !== false;

        // alias alanları + JSON fallback
        $to      = $this->input->post('to') ?: $this->input->post('receiver') ?: $this->input->post('phone') ?: $this->input->post('whatsapp');
        $message = $this->input->post('message') ?: $this->input->post('text') ?: $this->input->post('body');
        $caption = $this->input->post('caption');

        if ((!$to || (!$message && !$is_multipart)) && ($raw = $this->input->raw_input_stream)) {
            $j = json_decode($raw, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($j)) {
                if (!$to)      { $to = isset($j['receiver']) ? $j['receiver'] : (isset($j['to']) ? $j['to'] : null); }
                if (!$message) { $message = $j['data']['message'] ?? ($j['message'] ?? ($j['text'] ?? null)); }
            }
        }

        $to = $this->normalize_phone($to);
        $now = date('Y-m-d H:i:s');

        $this->load->library('WhatsAppLazyClient');
        $client = new WhatsAppLazyClient($accRow ? [
            'api_url'        => $accRow['qr_api_url'] ?? null,
            'api_key'        => $accRow['qr_api_key'] ?? null,
            'device'         => $accRow['qr_device'] ?? null,
            'payload_mode'   => $accRow['qr_payload_mode'] ?? null,
            'send_text_path' => $accRow['qr_send_text_path'] ?? null,
            'send_media_path'=> $accRow['qr_send_media_path'] ?? null,
        ] : null);
        if (!$client->isConfigured()) { return wp_json_response(['success'=>false,'message'=>'QR API ayarları eksik.'], 500); }

        // storage
        $storageDir = FCPATH . 'modules/whatsapp_plus/storage/media/' . date('Y/m');
        if (!is_dir($storageDir)) { @mkdir($storageDir, 0775, true); }

        $response=null; $status='sent'; $wa_id=null; $err=null; $message_type='text'; $fileRow=null; $code=0; $res=null;

        if ($is_multipart && !empty($_FILES['attachment']) && is_uploaded_file($_FILES['attachment']['tmp_name'])) {
            $f    = $_FILES['attachment'];
            $tmp  = $f['tmp_name'];
            $orig = $f['name'];
            $mime = $f['type'] ?: 'application/octet-stream';
            $size = (int)$f['size'];

            $attachType = $this->input->post('attachment_type') ?: 'document';
            if     (stripos($mime,'image/')===0) $attachType = 'image';
            elseif (stripos($mime,'video/')===0) $attachType = 'video';
            elseif (stripos($mime,'audio/')===0) $attachType = 'audio';

            $safeName = preg_replace('~[^a-zA-Z0-9_.-]+~','_', $orig);
            $dest = rtrim($storageDir,'/').'/'.time().'_'.$safeName;
            @move_uploaded_file($tmp, $dest);

            $rel = str_replace(FCPATH,'',$dest);
            if (function_exists('site_url'))      { $base = rtrim(site_url(''),'/').'/'; }
            elseif (function_exists('base_url'))  { $base = rtrim(base_url(''),'/').'/'; }
            else { $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') ? 'https' : 'http'; $host = $_SERVER['HTTP_HOST'] ?? 'localhost'; $base = $scheme.'://'.$host.'/'; }
            $fileUrl = $base . ltrim($rel,'/');

            $mediaType = $attachType === 'document' ? 'file' : $attachType;
            $res = $client->sendMedia($to, $fileUrl, $mime, ($caption ?: $message ?: ''), $mediaType);
            $code = (int)($res['status'] ?? 0); $response=$res['raw'] ?? null; $err=$res['error'] ?? null;

            $message_type = $attachType;
            $fileRow = [
                'type'      => $attachType,
                'media_id'  => null,
                'file_path' => $rel,
                'filename'  => $safeName,
                'mime'      => $mime,
                'size'      => $size,
                'sha1'      => @sha1_file($dest),
                'caption'   => ($caption ?: $message ?: ''),
            ];
        } else {
            if (!$to || !$message) { return wp_json_response(['success'=>false,'message'=>'Alıcı (receiver) ve mesaj zorunludur.'], 422); }
            $res = $client->sendText($to, $message);
            $code = (int)($res['status'] ?? 0); $response = $res['raw'] ?? null; $err = $res['error'] ?? null;
            $message_type = 'text';
        }

        // wa_id çıkar
        if (empty($wa_id) && isset($res['json']) && is_array($res['json'])) {
            $j = $res['json'];
            if     (isset($j['messages'][0]['id']))   { $wa_id = $j['messages'][0]['id']; }
            elseif (isset($j['messageId']))           { $wa_id = $j['messageId']; }
            elseif (isset($j['id']))                  { $wa_id = $j['id']; }
            elseif (isset($j['data']['key']['id']))   { $wa_id = $j['data']['key']['id']; }
            elseif (isset($j['data']['id']))          { $wa_id = $j['data']['id']; }
        }
        if (empty($wa_id) && is_string($response)) {
            if (preg_match('/"(?:id|messageId)"\s*:\s*"([^"]+)"/', $response, $m))      { $wa_id = $m[1]; }
            elseif (preg_match('/[A-Za-z0-9+\/=._:-]{16,}/', $response, $m))            { $wa_id = $m[0]; }
        }

        $__meta_out = ['qr_send'=>$res, 'wa_id'=>$wa_id];
        $msgId = $this->whatsapp_plus_model->log_message([
            'account_id'    => (int)$accId,
            'direction'     => 'out',
            'meta_json'     => json_encode($__meta_out, JSON_UNESCAPED_UNICODE),
            'phone'         => $to,
            'type'          => $message_type,
            'body'          => ($message_type==='text' ? $message : ($caption ?: '')),
            'status'        => ($code===200 ? 'sent' : 'error'),
            'wa_message_id' => $wa_id,
            'error'         => $err ?: ($code!==200 ? $response : null),
            'created_at'    => $now,
            'sent_at'       => ($code===200 ? $now : null),
            'contact_name'  => null,
        ]);

        if ($fileRow && $this->db->table_exists(db_prefix().'whatsapp_plus_media')) {
            $fileRow['message_id'] = $msgId;
            $this->db->insert(db_prefix().'whatsapp_plus_media', $fileRow);
        }

        $msgPayload = null;
        if ($this->db->table_exists(db_prefix().'whatsapp_plus_messages')) {
            $row = $this->db->where('id', (int)$msgId)->get(db_prefix().'whatsapp_plus_messages')->row_array();
            if ($row) {
                $msgPayload = [
                    'id'            => (int)$row['id'],
                    'direction'     => $row['direction'],
                    'body'          => isset($row['body']) ? $row['body'] : (isset($row['message']) ? $row['message'] : ''),
                    'status'        => $row['status'],
                    'created_at'    => $row['created_at'],
                    'phone_e164'    => $row['phone_e164'],
                    'is_important'  => isset($row['is_important']) ? (int)$row['is_important'] : 0,
                ];
            }
        }
        return wp_json_response(['success'=>($code===200), 'message'=>$msgPayload], ($code===200 ? 200 : ($code ?: 500)));
    }

    /* ---------- flags / lists ---------- */

    public function toggle_message_important()
    {
        $id   = (int)$this->input->post('id');
        $flag = (int)$this->input->post('important') ? 1 : 0;
        $ok = $this->whatsapp_plus_model->set_message_important($id, $flag);
        wp_json_response(['ok'=>$ok]);
    }

    public function toggle_thread_important()
    {
        $phone = $this->normalize_phone($this->input->post('phone'));
        $flag  = (int)$this->input->post('important') ? 1 : 0;
        $ok = $this->whatsapp_plus_model->set_thread_important($phone, $flag);
        wp_json_response(['ok'=>$ok]);
    }

    public function important_threads()
    {
        $phones = $this->whatsapp_plus_model->list_important_threads();
        wp_json_response(['phones'=>$phones]);
    }

    /* ---------- misc pages ---------- */

    public function download_media($id)
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { access_denied('whatsapp_plus'); }
        $id = (int)$id; if ($id<=0) show_404();
        $row = $this->db->where('id',$id)->get(db_prefix().'whatsapp_plus_media')->row_array();
        if (!$row) show_404();
        $path = FCPATH . $row['file_path'];
        if (!is_file($path) || !is_readable($path)) show_404();
        $filename = $row['filename'] ?: basename($path);
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.rawurlencode($filename).'"');
        header('Content-Length: ' . (string)filesize($path));
        header('Cache-Control: private');
        readfile($path); exit;
    }

    public function settings()
    {
        if (!has_permission('whatsapp_plus', '', 'view_settings')) { access_denied('whatsapp_plus'); }
        if ($this->input->method(true) === 'POST') {
            if (!has_permission('whatsapp_plus', '', 'edit')) { access_denied('whatsapp_plus'); }
            update_option('wp_access_token', $this->input->post('wp_access_token', false));
            update_option('wp_waba_id', $this->input->post('wp_waba_id', false));
            update_option('wp_phone_number_id', $this->input->post('wp_phone_number_id', false));
            update_option('wp_verify_token', $this->input->post('wp_verify_token', false));
            update_option('wp_cloud_enabled', $this->input->post('wp_cloud_enabled') ? '1' : '0');
            update_option('wp_qr_enabled', $this->input->post('wp_qr_enabled') ? '1' : '0');
            update_option('wp_qr_api_url', $this->input->post('wp_qr_api_url', false));
            update_option('wp_qr_api_key', $this->input->post('wp_qr_api_key', false));
            update_option('wp_qr_device',  $this->input->post('wp_qr_device', false));
            update_option('wp_qr_send_text_path',  $this->input->post('wp_qr_send_text_path', false));
            update_option('wp_qr_send_media_path', $this->input->post('wp_qr_send_media_path', false));
            update_option('wp_qr_assume_delivered_on_200', $this->input->post('wp_qr_assume_delivered_on_200') ? '1' : '0');
            update_option('wp_qr_assume_read_on_incoming', $this->input->post('wp_qr_assume_read_on_incoming') ? '1' : '0');
            set_alert('success', _l('updated_successfully'));
            redirect(admin_url('whatsapp_plus/settings'));
        }
        $data = [
            'title'              => _l('settings'),
            'wp_access_token'    => get_option('wp_access_token'),
            'wp_waba_id'         => get_option('wp_waba_id'),
            'wp_phone_number_id' => get_option('wp_phone_number_id'),
            'wp_verify_token'    => get_option('wp_verify_token'),
            'has_accounts'       => count($this->whatsapp_plus_model->get_accounts('qr')) > 0,
        ];
        $this->load->view('whatsapp_plus/settings', $data);
    }

    public function logs()
    {
        if (!has_permission('whatsapp_plus', '', 'view_logs')) { access_denied('whatsapp_plus'); }
        $data['title'] = _l('logs');
        $file = __DIR__ . '/../storage/webhook.log';
        $data['log_text'] = @is_file($file) ? @file_get_contents($file) : 'Log bulunamadı.';
        $this->load->view('whatsapp_plus/log', $data);
    }

    public function qr_settings(){ redirect(admin_url('whatsapp_plus/settings')); }

    public function qr_logs()
    {
        if (!has_permission('whatsapp_plus', '', 'view')) { access_denied('whatsapp_plus'); }
        $data['title'] = _l('logs') . ' (QR)';
        $this->db->limit(200);
        $this->db->order_by('id','DESC');
        $rows = $this->db->where('source','qr')->get(db_prefix().'whatsapp_plus_logs')->result_array();
        $data['db_rows'] = $rows;
        $file = __DIR__ . '/../storage/webhook.log';
        $data['log_text'] = @is_file($file) ? @file_get_contents($file) : '';
        $this->load->view('whatsapp_plus/log_qr', $data);
    }

    /* ---------- private helpers ---------- */

    private function _render_attachments_html($message_id, $fallback_caption=null)
    {
        $CI =& get_instance();
        $CI->load->model('whatsapp_plus/Whatsapp_plus_model');
        $files = $CI->Whatsapp_plus_model->get_media_by_message((int)$message_id);
        if (!$files || !is_array($files) || count($files)===0){
            $fn = is_string($fallback_caption) ? trim($fallback_caption) : '';
            if ($fn !== '' && preg_match('~\.(png|jpe?g|gif|webp|mp4|mov|webm|mp3|m4a|ogg|wav|pdf|zip|docx?)$~i', $fn)){
                $files = $CI->Whatsapp_plus_model->get_media_by_filename(basename($fn));
            }
        }
        if (!$files || !is_array($files) || count($files)===0) return [null,false,null];

        $img_count = 0; foreach ($files as $f){ $type = $f['type'] ?? ''; $mime = $f['mime'] ?? ''; if (strpos((string)$type,'image')!==false || strpos((string)$mime,'image/')===0) $img_count++; }
        $att_class = ($img_count <= 1) ? 'wa-attachments wa-attachments--single' : 'wa-attachments wa-attachments--grid';

        $buf = '<div class="'.$att_class.'" data-count="'.(int)$img_count.'">';
        $first_caption = '';
        foreach ($files as $f){
            $path = base_url((string)($f['file_path'] ?? ''));
            $type = (string)($f['type'] ?? 'document'); $mime = (string)($f['mime'] ?? '');
            $name = (string)($f['filename'] ?? 'file');
            $cap  = isset($f['caption']) ? (string)$f['caption'] : '';
            if ($first_caption === '' && $cap !== '') { $first_caption = $cap; }
            if (strpos($type,'image')!==false || strpos($mime,'image/')===0){
                $buf .= '<div class="wa-att wa-att--image"><a href="'.$path.'" download title="'.html_escape($name).'"><img src="'.$path.'" alt="'.html_escape($name).'"/></a></div>';
            } elseif (strpos($type,'audio')!==false || strpos($mime,'audio/')===0){
                $buf .= '<div class="wa-att wa-att--audio"><audio controls preload="none" src="'.$path.'"></audio></div>';
            } else {
                $buf .= '<div class="wa-att wa-att--doc"><a href="'.$path.'" download title="'.html_escape($name).'"><span class="wa-att__icon"><i class="fa fa-file-text-o"></i></span><span class="wa-att__name">'.html_escape($name).'</span></a></div>';
            }
        }
        $cap_final = ($first_caption !== '') ? $first_caption : (string)$fallback_caption;
        if ($cap_final !== ''){ $buf .= '<div class="wa-cap">'.html_escape($cap_final).'</div>'; }
        $buf .= '</div>';
        $has_cap = ($cap_final !== '');
        return [$buf, $has_cap, $cap_final];
    }

    /** Compatibility stub */
    public function status_updates(){ wp_json_response(['updates'=>[]]); }
}
