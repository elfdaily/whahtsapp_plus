<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * QR/Webhook (Dayxen/WALazy) – 3.8.5 + PATCH (caption ≠ filename) + DEDUPE + GET/POST backfill
 *
 * - filename/caption iyileştirmeleri
 * - medya dedup (mesaj içi ve isteğe bağlı global pencere)
 * - STATUS GET ve STATUS POST’ta backfill: gateway gerçek waId gönderdiğinde, DB’deki qr:% placeholder OUT mesajı gerçek waId ile eşlenir
 *
 * Ayarlar:
 *  DB options:
 *    whatsapp_plus_media_dedupe_enabled  => "1" | "0" (varsayılan: 1)
 *    whatsapp_plus_media_dedupe_minutes  => dakika (varsayılan: 10)
 *  ENV (DB>ENV>default sırası):
 *    WA_MEDIA_DEDUPE_ENABLED=true|false
 *    WA_MEDIA_DEDUPE_MIN=10
 *    WA_MEDIA_GLOBAL_DEDUPE_MIN=0  (sadece ENV; 0 = kapalı)
 */

class Qr_webhook extends CI_Controller
{
    private $DBG = false;

    /** Dedupe ayarları (constructor’da yüklenir) */
    private $DEDUP_ON  = true;
    private $DEDUP_MIN = 10;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->helper('whatsapp_plus/whatsapp_plus');
        $this->load->database();

        // --- ayarları yükle
        $this->DEDUP_ON  = $this->_opt_bool('whatsapp_plus_media_dedupe_enabled', 'WA_MEDIA_DEDUPE_ENABLED', true);
        $this->DEDUP_MIN = max(0, (int)$this->_opt_int('whatsapp_plus_media_dedupe_minutes', 'WA_MEDIA_DEDUPE_MIN', 10));
    }

    /* -------------------- options helpers -------------------- */
    private function _db_option($name) {
        $tbl = db_prefix().'options';
        if (!$this->db->table_exists($tbl)) return null;
        $q = $this->db->select('value')->from($tbl)->where('name',$name)->get();
        if ($q && $q->num_rows()) return $q->row()->value;
        return null;
    }
    private function _env($key, $default=null) {
        $v = getenv($key);
        return ($v===false || $v===null) ? $default : $v;
    }
    private function _opt_raw($dbKey, $envKey, $default=null) {
        $v = $this->_db_option($dbKey);
        if ($v !== null && $v !== '') return $v;
        $v = $this->_env($envKey, null);
        if ($v !== null && $v !== '') return $v;
        return $default;
    }
    private function _opt_bool($dbKey, $envKey, $default=true) {
        $v = $this->_opt_raw($dbKey, $envKey, $default ? '1' : '0');
        if (is_bool($v)) return $v;
        $s = strtolower((string)$v);
        return in_array($s, ['1','true','on','yes','y'], true);
    }
    private function _opt_int($dbKey, $envKey, $default=0) {
        $v = $this->_opt_raw($dbKey, $envKey, (string)$default);
        return (int)$v;
    }

    /* -------------------- logging -------------------- */
    private function dlog($tag, $data = null)
    {
        if (!$this->DBG) return;
        $dir = FCPATH.'modules/whatsapp_plus/storage/';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $line = date('c').' ['.$tag.'] '.(is_string($data) ? $data : json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        @file_put_contents($dir.'qr_debug.log', $line."\n", FILE_APPEND);
    }

    /* -------------------- filename helpers -------------------- */
    private function _looks_generic_filename($s){
        $s = trim((string)$s);
        return $s !== '' && preg_match('~^file(\s*\(\d+\))?\.[a-z0-9]{1,8}$~i', $s);
    }
    private function _looks_filename_like($s){
        $s = trim((string)$s);
        return $s !== '' && preg_match('~^[^\\\\/:\*\?"<>\|]+?\.[A-Za-z0-9]{1,8}$~', $s);
    }
    private function _sanitize_filename($name)
    {
        $name = trim((string)$name);
        if ($name === '') return 'file';
        $name = pathinfo($name, PATHINFO_FILENAME);
        $name = preg_replace('/[\x00-\x1F\\/:*?"<>|]+/', '', $name);
        $name = preg_replace('/\s+/', ' ', $name);
        return $name !== '' ? $name : 'file';
    }
    private function _unique_target($dir, $base, $ext)
    {
        $base = $this->_sanitize_filename($base);
        $ext  = ltrim((string)$ext, '.');
        $n = 0;
        do {
            $suffix    = $n === 0 ? '' : ' ('.$n.')';
            $candidate = rtrim($dir, '/').'/'.$base.$suffix.($ext ? '.'.$ext : '');
            $n++;
        } while (file_exists($candidate));
        return $candidate;
    }
    private function _ext_from_mime($hintMime){
        $mmap = [
            'image/jpeg'=>'jpg','image/jpg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp','image/heic'=>'heic','image/tiff'=>'tif','image/svg+xml'=>'svg',
            'video/mp4'=>'mp4','video/quicktime'=>'mov','video/webm'=>'webm',
            'audio/mpeg'=>'mp3','audio/mp4'=>'m4a','audio/ogg'=>'ogg','audio/wav'=>'wav',
            'application/pdf'=>'pdf','application/zip'=>'zip'
        ];
        $hintMime = $hintMime ? strtolower($hintMime) : '';
        return $mmap[$hintMime] ?? '';
    }
    private function _cd_filename_from_header($cd){
        $cd = (string)$cd; if ($cd === '') return null;
        if (preg_match('~filename\*\s*=\s*([^\'"]*)\'\'([^;]+)~i', $cd, $m)) {
            $enc = strtoupper(trim($m[1])); $val = rawurldecode(trim($m[2]));
            if ($enc==='UTF-8' || $enc==='') return $val;
            return @iconv($enc, 'UTF-8//IGNORE', $val) ?: $val;
        }
        if (preg_match('~filename\s*=\s*"([^"]+)"~i', $cd, $m)) return $m[1];
        if (preg_match('~filename\s*=\s*([^;]+)~i', $cd, $m))  return trim($m[1]);
        return null;
    }
    private function _filename_from_caption($caption, $mimeHint = null){
        $c = trim((string)$caption);
        if ($c === '') return null;

        $exts = ['jpg','jpeg','png','webp','gif','tif','tiff','bmp','heic','svg','pdf','zip','mp4','mov','webm','mp3','m4a','ogg','wav'];
        if ($mimeHint) {
            $m = strtolower($mimeHint);
            if (strpos($m,'image/')===0)      $exts = ['jpg','jpeg','png','webp','gif','tif','tiff','bmp','heic','svg'];
            elseif (strpos($m,'video/')===0)  $exts = ['mp4','mov','webm','mkv','avi'];
            elseif (strpos($m,'audio/')===0)  $exts = ['mp3','m4a','ogg','wav','flac','opus'];
            elseif ($m==='application/pdf')   $exts = ['pdf'];
        }
        $extRe = implode('|', array_map(fn($e)=>preg_quote($e,'~'), $exts));

        if (preg_match_all('~([^\r\n\\\\/:*?"<>|]+\.(?:'.$extRe.'))~i', $c, $m) && !empty($m[1])) {
            return trim($m[1][count($m[1])-1]);
        }
        if ($this->_looks_filename_like($c)) return $c;
        return null;
    }
    private function _filename_from_url($url){
        if (!is_string($url) || !filter_var($url, FILTER_VALIDATE_URL)) return null;
        $u = parse_url($url);
        if (!empty($u['query'])) {
            parse_str($u['query'], $q);
            foreach (['filename','name','file','attname','attachment','download'] as $k) {
                if (!empty($q[$k]) && $this->_looks_filename_like($q[$k])) return $q[$k];
            }
        }
        if (!empty($u['path'])) {
            $base = basename($u['path']);
            if ($this->_looks_filename_like($base)) return $base;
        }
        return null;
    }
    private function _prefer_filename($suggest, $caption, $mimeHint, $srcUrl = null){
        if (empty($suggest) || $this->_looks_generic_filename($suggest)) {
            $fromCap = $this->_filename_from_caption($caption, $mimeHint);
            if ($fromCap) return $fromCap;
            $fromUrl = $this->_filename_from_url($srcUrl);
            if ($fromUrl) return $fromUrl;
        }
        if (!empty($caption) && $this->_looks_filename_like($caption)) return $caption;
        return $suggest ?: $this->_filename_from_url($srcUrl);
    }

    /** Caption ile filename eşit mi? (ext & boşluk hassasiyetini azalt) */
    private function _same_fileish($a, $b) {
        $norm = function($s){
            $s = strtolower(trim((string)$s));
            $s = preg_replace('~\.[^.]+$~', '', $s);
            $s = preg_replace('~\s+~', ' ', $s);
            return $s;
        };
        return ($a!=='' && $b!=='') && ($norm($a) === $norm($b));
    }

    /* -------------------- JSON helpers -------------------- */
    private function json_ok($arr = [], $code = 200)
    {
        if (!isset($arr['status'])) $arr['status'] = 'ok';
        $this->output->set_status_header($code)
            ->set_content_type('application/json', 'utf-8')
            ->set_output(json_encode($arr, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))->_display();
        exit;
    }

    /* -------------------- phone/name/id/status/body extractors -------------------- */
    private function _normalize_phone($s)
    {
        $s = (string)$s;
        if ($s === '') return '';
        if (strpos($s, '@') !== false) $s = explode('@', $s)[0];
        $digits = preg_replace('/\D+/', '', $s);
        if ($digits === '') return '';
        if (preg_match('~^120\d{5,}~', $digits)) return 'g:'.$digits; // group id
        if ($digits[0] !== '+') $digits = '+'.$digits;
        return function_exists('wp_normalize_phone') ? wp_normalize_phone($digits) : $digits;
    }
    private function _extract_remote_phone(array $e)
    {
        foreach (['key',''] as $__scope) {
            if ($__scope==='key' && !isset($e['key'])) continue;
            $src = ($__scope==='key') ? $e['key'] : $e;
            foreach (['remoteJid','chatId','jid'] as $k) {
                if (isset($src[$k])) { $p = $this->_normalize_phone($src[$k]); if ($p) return $p; }
            }
        }
        if (isset($e['participant'])) {
            $p = $this->_normalize_phone($e['participant']);
            if ($p && strpos($p,'g:')===0) return $p;
        }
        foreach (['remoteJid','jid','chatId','from','sender','participant','number','phone','to','receiver'] as $k) {
            if (isset($e[$k])) { $p = $this->_normalize_phone($e[$k]); if ($p) return $p; }
        }
        return null;
    }
    private function _extract_name(array $e)
    {
        foreach (['contact_name','contactName','pushName','senderName','name','displayName'] as $k) {
            if (!empty($e[$k])) return trim((string)$e[$k]);
        }
        if (!empty($e['sender']) && is_array($e['sender'])) {
            foreach (['contact_name','contactName','name','pushName','notify','displayName'] as $k) {
                if (!empty($e['sender'][$k])) return trim((string)$e['sender'][$k]);
            }
        }
        if (!empty($e['message']) && is_array($e['message'])) {
            foreach (['pushName','displayName','name'] as $k) {
                if (!empty($e['message'][$k])) return trim((string)$e[$k]);
            }
        }
        return null;
    }
    private function _extract_id(array $e)
    {
        $paths = [['id'],['message_id'],['messageId'],['wamid'],['key','id'],['data','key','id'],['message','key','id']];
        foreach ($paths as $p) {
            $x=$e;
            foreach($p as $k){
                if(!is_array($x)||!array_key_exists($k,$x)){ $x=null; break; }
                $x=$x[$k];
            }
            if($x && is_string($x)) return $x;
        }
        if (!empty($e['messages'][0]['key']['id'])) return (string)$e['messages'][0]['key']['id'];
        return null;
    }
    private function _map_status(array $e)
    {
        $ack = null; $stat = null;
        if (isset($e['ack'])) $ack = (int)$e['ack'];
        elseif (isset($e['data']['ack'])) $ack = (int)$e['data']['ack'];

        $s = null;
        if (isset($e['status']))            $s = strtolower((string)$e['status']);
        elseif (isset($e['data']['status']))$s = strtolower((string)$e['data']['status']);
        elseif (isset($e['event']))         $s = strtolower((string)$e['event'] );

        if ($s) {
            $stat = (strpos($s,'read')!==false) ? 'read'
                : ((strpos($s,'deliver')!==false) ? 'delivered'
                : ((strpos($s,'server')!==false || strpos($s,'sent')!==false) ? 'sent' : null));
        }
        if (!$stat && $ack!==null) $stat = ($ack>=3?'read':($ack>=2?'delivered':($ack>=1?'sent':null)));
        return [$ack,$stat];
    }

    /* -------------------- MONOTON DURUM GUARD -------------------- */
    // Sınıf içine eklendi: status downgrade'i engeller (sent < delivered < read)
    private function _guard_where_for_status($new)
    {
        switch ($new) {
            case 'read':
                // read en yüksek seviye; opsiyonel olarak zaten read ise dokunma
                // $this->db->where("status <> 'read'", null, false);
                return;
            case 'delivered':
                // delivered yalnızca NULL/boş veya sent üzerine yazılabilir
                $this->db->group_start();
                    $this->db->where('status IS NULL', null, false);
                    $this->db->or_where('status', '');
                    $this->db->or_where('status', 'sent');
                $this->db->group_end();
                return;
            case 'sent':
                // sent yalnızca boş üstüne yazılsın (downgrade’i önle)
                $this->db->group_start();
                    $this->db->where('status IS NULL', null, false);
                    $this->db->or_where('status', '');
                $this->db->group_end();
                return;
            default:
                return;
        }
    }

    private function _body_from_event(array $e)
    {
        if (isset($e['text']['body']))          return (string)$e['text']['body'];
        if (isset($e['body']) && is_string($e['body'])) return $e['body'];
        if (isset($e['message']) && is_string($e['message'])) return $e['message'];
        if (isset($e['message']['conversation'])) return (string)$e['message']['conversation'];
        if (isset($e['caption']))               return (string)$e['caption'];
        if (isset($e['buttonText']))            return (string)$e['buttonText'];
        if (isset($e['listResponse']['title'])) return (string)$e['listResponse']['title'];
        if (isset($e['messageText']))           return (string)$e['messageText'];
        return null;
    }

    /* -------------------- hydrate gateway -------------------- */
    private function _hydrate_gateway(array $e)
    {
        if (!isset($e['pushName']) && !empty($e['contact_name'])) $e['pushName'] = $e['contact_name'];

        if (isset($e['message']) && is_array($e['message'])) {
            $m = $e['message'];

            foreach (['imageMessage','videoMessage','audioMessage','documentMessage','stickerMessage'] as $t) {
                if (!empty($m[$t]) && is_array($m[$t])) {
                    $mm = $m[$t];
                    if (!isset($e['type'])) {
                        if (strpos($t,'image')!==false)      $e['type']='image';
                        elseif (strpos($t,'video')!==false)  $e['type']='video';
                        elseif (strpos($t,'audio')!==false)  $e['type']='audio';
                        else                                  $e['type']='document';
                    }
                    if (!isset($e['mime'])     && !empty($mm['mimetype'])) $e['mime'] = $mm['mimetype'];
                    if (!isset($e['caption'])  && !empty($mm['caption']))  $e['caption'] = $mm['caption'];
                    if (!isset($e['fileName']) && !empty($mm['fileName'])) $e['fileName'] = $mm['fileName'];
                    if (!isset($e['filename']) && !empty($mm['fileName'])) $e['filename'] = $mm['fileName'];
                    foreach (['url','mediaUrl','downloadUrl','fileUrl','dlUrl','clientUrl','dataUri','data_uri'] as $k) {
                        if (!isset($e[$k]) && !empty($mm[$k])) $e[$k] = $mm[$k];
                    }
                    if (!isset($e['directPath']) && !empty($mm['directPath'])) $e['directPath'] = $mm['directPath'];
                    return $e;
                }
            }

            if (!empty($m['type']) && in_array($m['type'], ['image','video','audio','document'])) {
                if (!isset($e['type'])) $e['type'] = $m['type'];
                if (!isset($e['mime'])     && !empty($m['mimetype'])) $e['mime'] = $m['mimetype'];
                if (!isset($e['caption'])  && !empty($m['caption']))  $e['caption'] = $m['caption'];
                if (!isset($e['fileName']) && !empty($m['fileName'])) $e['fileName'] = $m['fileName'];
                if (!isset($e['filename']) && !empty($m['fileName'])) $e['filename'] = $m['fileName'];
                foreach (['url','mediaUrl','downloadUrl','fileUrl','dlUrl','clientUrl','dataUri','data_uri'] as $k) {
                    if (!isset($e[$k]) && !empty($m[$k])) $e[$k] = $m[$k];
                }
                if (!isset($e['directPath']) && !empty($m['directPath'])) $e['directPath'] = $m['directPath'];
                return $e;
            }

            if (!empty($m['image']) && is_array($m['image'])) {
                $im = $m['image'];
                if (!isset($e['type'])) $e['type'] = 'image';
                if (!isset($e['mime'])     && !empty($im['mimetype'])) $e['mime'] = $im['mimetype'];
                if (!isset($e['caption'])  && !empty($im['caption']))  $e['caption'] = $im['caption'];
                if (!isset($e['fileName']) && !empty($im['fileName'])) $e['fileName'] = $im['fileName'];
                if (!isset($e['filename']) && !empty($im['fileName'])) $e['filename'] = $im['fileName'];
                foreach (['url','mediaUrl','downloadUrl','fileUrl','dlUrl','clientUrl','dataUri','data_uri'] as $k) {
                    if (!isset($e[$k]) && !empty($im[$k])) $e[$k] = $im[$k];
                }
                if (!isset($e['directPath']) && !empty($im['directPath'])) $e['directPath'] = $im['directPath'];
                return $e;
            }
        }

        if (!isset($e['type']) && !empty($e['media_type'])) $e['type'] = $e['media_type'];
        if (!isset($e['mime']) && !empty($e['mimetype']))   $e['mime'] = $e['mimetype'];
        if (!isset($e['fileName']) && !empty($e['filename'])) $e['fileName'] = $e['filename'];

        // messageText → caption sadece GERÇEK açıklamaysa
        if (isset($e['type']) && in_array($e['type'], ['image','video','audio','document'], true)) {
            $mt = $e['messageText'] ?? ($e['messagetext'] ?? null);
            if (empty($e['caption']) && !empty($mt)) {
                $fn = $e['fileName'] ?? ($e['filename'] ?? '');
                $fnNoExt = $fn ? preg_replace('~\.[^.]+$~','',$fn) : '';
                if (!$this->_same_fileish($mt, $fn) && !$this->_same_fileish($mt, $fnNoExt)) {
                    $e['caption'] = (string)$mt;
                }
            }
        }
        return $e;
    }

    /* -------------------- remote/local save -------------------- */
    private function _save_remote_file($src, $suggest=null, $hintMime=null)
    {
        $dir = FCPATH.'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/';
        if (!is_dir($dir)) @mkdir($dir,0775,true);

        $baseSuggest = $suggest ? pathinfo($suggest, PATHINFO_FILENAME) : null;
        $extSuggest  = $suggest ? strtolower((string)pathinfo($suggest, PATHINFO_EXTENSION)) : '';

        $urlName = $this->_filename_from_url($src);
        if ((empty($baseSuggest) || $this->_looks_generic_filename($baseSuggest.'.'.$extSuggest)) && $urlName) {
            $baseSuggest = pathinfo($urlName, PATHINFO_FILENAME);
            $extSuggest  = strtolower((string)pathinfo($urlName, PATHINFO_EXTENSION));
        }

        if (!$baseSuggest && is_string($src) && strlen($src)>2 && $src[0]==='/' && @is_file($src)) {
            $baseSuggest = pathinfo($src, PATHINFO_FILENAME);
            if (!$extSuggest) $extSuggest = strtolower((string)pathinfo($src, PATHINFO_EXTENSION));
        }

        $ext = $extSuggest ?: $this->_ext_from_mime($hintMime);

        $curl_ct = null; $ok=false; $target=null; $data=null; $content_hash=null; $resp_headers=[];

        if (is_string($src) && strlen($src)>2 && $src[0]==='/' && @is_file($src)) {
            $content_hash = @sha1_file($src) ?: null;
            $base = $this->_sanitize_filename($baseSuggest ?: 'file');
            $target = $this->_unique_target($dir, $base, $ext ?: '');
            $ok=@copy($src,$target);
        } elseif (is_string($src) && strpos($src,'data:')===0 && strpos($src,';base64,')!==false) {
            $parts=explode(',',$src,2);
            $payload = preg_replace('~\s+~','', $parts[1]);
            $data=base64_decode($payload);
            if ($data!==false) {
                $content_hash = sha1($data);
                $base = $this->_sanitize_filename($baseSuggest ?: 'file');
                $target = $this->_unique_target($dir, $base, $ext ?: '');
                $ok=file_put_contents($target,$data)!==false;
            }
        } elseif (filter_var($src,FILTER_VALIDATE_URL)) {
            $ch=curl_init($src);
            curl_setopt_array($ch,[
                CURLOPT_RETURNTRANSFER=>true,
                CURLOPT_FOLLOWLOCATION=>true,
                CURLOPT_CONNECTTIMEOUT=>8,
                CURLOPT_TIMEOUT=>30,
                CURLOPT_SSL_VERIFYPEER=>false,
                CURLOPT_USERAGENT=>'Mozilla/5.0 (Linux; Android 12) WhatsApp/2.24 Webhook',
                CURLOPT_HEADERFUNCTION=>function($ch,$header) use (&$resp_headers){
                    $len = strlen($header);
                    $p = explode(':', $header, 2);
                    if (count($p)==2){ $resp_headers[strtolower(trim($p[0]))] = trim($p[1]); }
                    return $len;
                }
            ]);
            $data=curl_exec($ch);
            $code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
            $curl_ct=curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
            curl_close($ch);

            $cd_name = !empty($resp_headers['content-disposition']) ? $this->_cd_filename_from_header($resp_headers['content-disposition']) : null;
            if ($cd_name && (empty($baseSuggest) || $this->_looks_generic_filename(($baseSuggest.'.'.$ext)))) {
                $baseSuggest = pathinfo($cd_name, PATHINFO_FILENAME) ?: $baseSuggest;
                $cdExt = strtolower((string)pathinfo($cd_name, PATHINFO_EXTENSION));
                if (!$ext) $ext = $cdExt ?: $ext;
            }
            if (!$ext) $ext = $this->_ext_from_mime($curl_ct ?: $hintMime);

            if ($data!==false && $code>=200 && $code<300) {
                $content_hash = sha1($data);
                $base = $this->_sanitize_filename($baseSuggest ?: 'file');
                $target = $this->_unique_target($dir, $base, $ext ?: '');
                $ok=file_put_contents($target,$data)!==false;
            } else {
                $this->dlog('CURL_FAIL', ['code'=>$code,'ct'=>$curl_ct,'src'=>$src]);
            }
        }
        if (!$ok) return null;

        $fn_basename = basename($target);
        if ($this->_looks_generic_filename($fn_basename)) {
            $ext2 = strtolower((string)pathinfo($target, PATHINFO_EXTENSION));
            $ext2 = $ext2 ?: $this->_ext_from_mime($hintMime);
            $nice  = 'image-'.date('Ymd-His').'-'.substr((string)($content_hash ?: sha1_file($target)),0,8);
            $new   = $this->_unique_target($dir, $nice, $ext2 ?: '');
            if (@rename($target, $new)) {
                $this->dlog('NAME_FALLBACK', ['old'=>$fn_basename,'new'=>basename($new)]);
                $target = $new;
            }
        }

        $mime=null;
        if (function_exists('finfo_open')) {
            $f=finfo_open(FILEINFO_MIME_TYPE);
            if ($f) { $mime=@finfo_file($f,$target); finfo_close($f); }
        }
        if (!$mime && function_exists('mime_content_type')) $mime=@mime_content_type($target);
        if (!$mime && $curl_ct) $mime=$curl_ct;
        if ($mime && strpos($mime,';')!==false) $mime = trim(explode(';',$mime)[0]);

        @chmod($target, 0644);
        $rel = 'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/'.basename($target);
        return [$rel, $target, basename($target), $mime ?: 'application/octet-stream'];
    }

    private function _save_uploaded_from_fields(array $fields = ['file','media','document','image','video','audio'])
    {
        foreach ($fields as $f) {
            if (empty($_FILES[$f]) || !is_array($_FILES[$f])) continue;
            $fl = $_FILES[$f]; if (!isset($fl['tmp_name']) || $fl['error']!==UPLOAD_ERR_OK) continue;

            $dir = FCPATH.'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/';
            if (!is_dir($dir)) @mkdir($dir,0775,true);

            $orig = (string)($fl['name']??'');
            $mime = (string)($fl['type']??'');

            $name = $this->_sanitize_filename(pathinfo($orig, PATHINFO_FILENAME));
            $ext  = strtolower((string)pathinfo($orig, PATHINFO_EXTENSION));
            $target = $this->_unique_target($dir, $name, $ext);

            if (!@move_uploaded_file($fl['tmp_name'],$target)) @copy($fl['tmp_name'],$target);
            if (!is_file($target)) return null;

            if (!$mime && function_exists('finfo_open')) {
                $f=finfo_open(FILEINFO_MIME_TYPE);
                if ($f) { $mime=@finfo_file($f,$target); finfo_close($f); }
            }

            $rel='modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/'.basename($target);

            $type='document';
            if     ($mime && stripos($mime,'image/')===0) $type='image';
            elseif ($mime && stripos($mime,'video/')===0) $type='video';
            elseif ($mime && stripos($mime,'audio/')===0) $type='audio';

            return [
                'type'      => $type,
                'file_path' => $rel,
                'filename'  => basename($target),
                'mime'      => $mime ?: null,
                'size'      => @filesize($target) ?: null,
                'sha1'      => @sha1_file($target) ?: null,
                'caption'   => null,
                'created_at'=> date('Y-m-d H:i:s'),
            ];
        }
        return null;
    }

    /* -------------------- attachment collector -------------------- */
    private function _collect_attachments(array $e)
    {
        $e = $this->_hydrate_gateway($e);
        $caption = $this->_body_from_event($e);

        // flatten
        $flat = [];
        $walk = function($k,$v) use (&$walk,&$flat){
            if (is_array($v)) { foreach($v as $kk=>$vv) $walk($kk,$vv); return; }
            $flat[strtolower((string)$k)] = $v;
        };
        foreach ($e as $k=>$v) $walk($k,$v);

        $order = ['data_uri','datauri','url','mediaurl','downloadurl','fileurl','dlurl','clienturl'];
        $src = null;
        foreach ($order as $k) {
            if (!empty($flat[$k]) && is_string($flat[$k])) { $src=$flat[$k]; break; }
        }

        $rawSuggest = null;
        foreach (['filename','fileName','name'] as $nk) {
            $lk = strtolower($nk);
            if (!empty($flat[$lk])) { $rawSuggest = $flat[$lk]; break; }
        }
        $hintMime = $flat['mimetype'] ?? ($flat['mime'] ?? null);
        $suggest  = $this->_prefer_filename($rawSuggest, $caption, $hintMime, $src);

        // directPath geldiyse ek ekleme (indirmiyoruz)
        if (!$src && !empty($flat['directpath'])) {
            $this->dlog('DIRECTPATH_SKIP', ['type'=>($flat['type']??null),'filename'=>$suggest]);
            return [];
        }
        if (!$src) {
            $this->dlog('ATTS_NONE', ['reason'=>'no-usable-pointer','keys'=>array_keys($flat)]);
            return [];
        }

        $saved = $this->_save_remote_file($src, $suggest, $hintMime);
        if (!$saved) { $this->dlog('DL_FAIL', ['src'=>$src]); return []; }

        list($rel,$abs,$fn,$mime) = $saved;
        $this->dlog('SAVE_OK', ['file'=>$rel,'mime'=>$mime,'size'=>@filesize($abs)]);

        $type = 'document';
        $mm = strtolower((string)$mime);
        if     (strpos($mm,'image/')===0) $type='image';
        elseif (strpos($mm,'video/')===0) $type='video';
        elseif (strpos($mm,'audio/')===0) $type='audio';

        // caption dosya adıyla aynı/benzer ise caption'ı boşalt
        if ($caption) {
            $fnNoExt = preg_replace('~\.[^.]+$~','',$fn);
            if ($this->_same_fileish($caption, $fn) || $this->_same_fileish($caption, $fnNoExt)) {
                $caption = '';
            }
        }

        $size = @filesize($abs) ?: null;
        $sha1 = @sha1_file($abs) ?: null;

        return [[
            'type'       => $type,
            'file_path'  => $rel,
            'filename'   => $fn,
            'mime'       => $mime,
            'size'       => $size,
            'sha1'       => $sha1,
            'caption'    => $caption ?: null,
            'created_at' => date('Y-m-d H:i:s'),
        ]];
    }

    /* -------------------- DB helpers: dedupe -------------------- */
    private function _media_exists($msg_id, $file_path = null, $sha1 = null)
    {
        $tbl = db_prefix().'whatsapp_plus_media';
        if (!$this->db->table_exists($tbl)) return false;

        // 1) Aynı message_id içinde AYNI path veya AYNI sha1 varsa tekille
        $this->db->from($tbl)->where('message_id', (int)$msg_id);
        if ($file_path || $sha1) {
            $this->db->group_start();
            if ($file_path) $this->db->or_where('file_path', $file_path);
            if ($sha1)      $this->db->or_where('sha1', $sha1);
            $this->db->group_end();
        }
        $countSameMsg = (int)$this->db->count_all_results();
        if ($countSameMsg > 0) return true;

        // 2) GLOBAL tekilleştirme: son X dk içinde AYNI sha1 geldiyse
        $win = $this->_dedupe_window_min();   // ENV ile yönetiliyor
        if ($sha1 && $win > 0) {
            $since = date('Y-m-d H:i:s', time() - 60 * $win);
            $countGlobal = (int)$this->db->from($tbl)
                ->where('sha1', $sha1)
                ->where('created_at >=', $since)
                ->count_all_results();
            if ($countGlobal > 0) {
                $this->dlog('MEDIA_GLOBAL_DEDUPED', [
                    'sha1' => $sha1,
                    'since' => $since,
                    'window_min' => $win
                ]);
                return true;
            }
        }

        return false;
    }

    /** Global dedupe pencere süresi (dakika). ENV yoksa 0 = KAPALI (test için güvenli). */
    private function _dedupe_window_min()
    {
        $v = getenv('WA_MEDIA_GLOBAL_DEDUPE_MIN');
        if ($v === false || $v === '') return 0;
        $n = (int) $v;
        return ($n < 0) ? 0 : $n;
    }

    /* -------------------- controller -------------------- */
    public function index()
    {
        try {
            $account_id = 0;
            $token = $this->input->get('token');
            if ($token) {
                $acc = $this->whatsapp_plus_model->find_account_by_token($token);
                if ($acc) $account_id = (int)$acc['id'];
            }

            $method = $this->input->server('REQUEST_METHOD');
            $ctype  = (string)$this->input->server('CONTENT_TYPE');
            $raw    = file_get_contents('php://input');

            $this->dlog('REQ', array(
                'method'=>$method, 'ctype'=>$ctype, 'raw_len'=>strlen($raw),
                'get'=>$_GET, 'post_keys'=>array_keys(!empty($_POST)?$_POST:array()), 'file_keys'=>array_keys(!empty($_FILES)?$_FILES:array())
            ));

/* ------------ GET: status ping/quick test ------------ */
if ($method === 'GET') {
    if (isset($_GET['messageId']) || isset($_GET['id']) || isset($_GET['ack']) || isset($_GET['status']) || isset($_GET['event'])) {
        list($ack,$stat) = $this->_map_status($_GET);
        $waId = isset($_GET['messageId']) ? $_GET['messageId'] : (isset($_GET['id']) ? $_GET['id'] : null);

        if ($stat && $this->db->table_exists(db_prefix().'whatsapp_plus_messages')) {
            $tbl = db_prefix().'whatsapp_plus_messages';
            $upd = array('status'=>$stat);
            $now = date('Y-m-d H:i:s');
            if ($stat==='delivered') $upd['delivered_at']=$now;
            if ($stat==='read')      $upd['read_at']=$now;

            $affected = 0;

            // 1) Doğrudan wa_message_id eşleşmesi (qr:... veya wamid...)
            if ($waId) {
                $this->db->where('wa_message_id',$waId);
                $this->_guard_where_for_status($stat);   // <-- MONOTON GUARD
                $this->db->update($tbl,$upd);
                $affected = $this->db->affected_rows();
            }

            // 2) Backfill: gateway gerçek wamid gönderdi ama bizde qr:%/NULL ise
            if ($affected === 0 && $waId && strpos((string)$waId, 'wamid') === 0) {
                $windowSec = 180; // son 3 dk
                // Opsiyonel telefon – GET ile 'phone' veya 'from' gelmişse önce telefonla dene
                $phoneTry = null;
                if (!empty($_GET['phone'])) $phoneTry = $this->_normalize_phone($_GET['phone']);
                elseif (!empty($_GET['from'])) $phoneTry = $this->_normalize_phone($_GET['from']);

                // 2a) Telefonla dene (varsa)
                if ($phoneTry) {
                    $this->db->select('id')->from($tbl)
                        ->group_start()
                            ->where('phone', $phoneTry)
                            ->or_where('phone_e164', $phoneTry)
                        ->group_end()
                        ->where('direction','out')
                        ->where('account_id', (int)$account_id)
                        ->group_start()
                            ->where("wa_message_id LIKE 'qr:%'", null, false)
                            ->or_where('wa_message_id IS NULL', null, false)
                        ->group_end()
                        ->where('created_at >=', date('Y-m-d H:i:s', time()-$windowSec))
                        ->order_by('id','DESC')
                        ->limit(1);
                    $guess = $this->db->get()->row_array();
                } else {
                    $guess = array();
                }

                // 2b) Bulunamazsa: telefonsuz genel backfill
                if (empty($guess['id'])) {
                    $this->db->select('id')->from($tbl)
                        ->where('direction','out')
                        ->where('account_id', (int)$account_id)
                        ->group_start()
                            ->where("wa_message_id LIKE 'qr:%'", null, false)
                            ->or_where('wa_message_id IS NULL', null, false)
                        ->group_end()
                        ->where('created_at >=', date('Y-m-d H:i:s', time()-$windowSec))
                        ->order_by('id','DESC')
                        ->limit(1);
                    $guess = $this->db->get()->row_array();
                }

                if (!empty($guess['id'])) {
                    $upd2 = $upd;
                    $upd2['wa_message_id'] = $waId;
                    $this->db->where('id', (int)$guess['id']);
                    $this->_guard_where_for_status($stat);   // <-- MONOTON GUARD
                    $this->db->update($tbl, $upd2);
                    $affected = $this->db->affected_rows();
                    $this->dlog('GET-BACKFILL', ['row'=>$guess['id'],'waId'=>$waId,'stat'=>$stat]);
                } else {
                    $this->dlog('GET-BACKFILL-MISS', ['waId'=>$waId,'stat'=>$stat,'acc'=>$account_id]);
                }
            }

            $this->dlog('GET-STATUS', array('waId'=>$waId,'stat'=>$stat,'aff'=>$affected));
        }
        return $this->json_ok(array('ack'=>true));
    }

    if (!empty($_GET['from']) && (!empty($_GET['message']) || !empty($_GET['text']))) {
        $phone = $this->_normalize_phone($_GET['from']);
        $body  = isset($_GET['message']) ? $_GET['message'] : $_GET['text'];
        $row = array('direction'=>'in','phone'=>$phone,'type'=>'text','body'=>$body,'status'=>'received','account_id'=>(int)$account_id,'created_at'=>date('Y-m-d H:i:s'));
        $this->whatsapp_plus_model->log_message($row);
        $this->dlog('GET-INSERT', array('phone'=>$phone,'body'=>$body));
        return $this->json_ok(array('inserted'=>true));
    }

    return $this->json_ok(array('ping'=>true));
}


            /* ------------ POST/JSON parse ------------ */
            $json = json_decode($raw, true);
            if (!$json) {
                $rawJson = $this->input->post('payload') ?: $this->input->post('json');
                if ($rawJson) $json = json_decode($rawJson, true);
            }

            $events = array();

            if (is_array($json)) {
                if (isset($json['messages']) && is_array($json['messages'])) {
                    foreach ($json['messages'] as $m) $events[]=$m;
                } elseif (isset($json['data']['message'])) {
                    $events[]=$json['data']['message'];
                } else {
                    $events[]=$json; // düz nesne
                }
            } elseif (!empty($_POST) || !empty($_FILES)) {
                $p=$_POST; $evt=array();
                $evt['from'] = isset($p['from']) ? $p['from']
                            : (isset($p['sender']) ? $p['sender']
                            : (isset($p['number']) ? $p['number']
                            : (isset($p['phone']) ? $p['phone']
                            : (isset($p['participant']) ? $p['participant']
                            : (isset($p['remoteJid']) ? $p['remoteJid']
                            : (isset($p['jid']) ? $p['jid']
                            : (isset($p['chatId']) ? $p['chatId'] : '')))))));

                $evt['to']   = isset($p['to']) ? $p['to'] : (isset($p['receiver']) ? $p['receiver'] : null);
                $evt['type'] = isset($p['media_type']) ? $p['media_type'] : (isset($p['message_type']) ? $p['message_type'] : (isset($p['type']) ? $p['type'] : 'text'));
                $evt['pushName']     = isset($p['pushName']) ? $p['pushName']
                                     : (isset($p['name']) ? $p['name']
                                     : (isset($p['displayName']) ? $p['displayName']
                                     : (isset($p['contact_name']) ? $p['contact_name']
                                     : (isset($p['contactName']) ? $p['contactName'] : null))));
                if (!empty($evt['pushName'])) $evt['sender'] = array('name'=>$evt['pushName']);
                $evt['contact_name'] = isset($p['contact_name']) ? $p['contact_name'] : null;

                $msg = isset($p['message']) ? $p['message'] : (isset($p['text']) ? $p['text'] : (isset($p['body']) ? $p['body'] : null));
                if ($msg!==null) { $evt['text']=array('body'=>$msg); $evt['body']=$msg; }
                foreach (array('url','mediaUrl','downloadUrl','fileUrl','dlUrl','clientUrl','data_uri','datauri','directPath') as $k) {
                    if (!empty($p[$k])) $evt[$k] = $p[$k];
                }
                if (!empty($p['filename']))  $evt['filename']  = $p['filename'];
                if (!empty($p['fileName']))  $evt['fileName']  = $p['fileName'];
                if (!empty($p['mime']))      $evt['mime']      = $p['mime'];
                if (!empty($p['mimetype']))  $evt['mimetype']  = $p['mimetype'];
                if (!empty($_FILES)) {
                    $saved = $this->_save_uploaded_from_fields();
                    if ($saved) $evt['__uploaded_files'] = array($saved);
                }
                if (!empty($evt['from']) || !empty($evt['to']) || !empty($evt['body']) || !empty($evt['__uploaded_files']) || !empty($evt['url']) || !empty($evt['data_uri']) || !empty($evt['directPath'])) {
                    $events[]=$evt;
                }
                $this->dlog('FORM_EVT', array_keys($evt));
            }

            if (empty($events)) {
                if (is_array($json) && (isset($json['from']) || isset($json['text']) || isset($json['body']))) {
                    $events[] = $json;
                    $this->dlog('FALLBACK_SINGLE', array('keys'=>array_keys($json)));
                } else {
                    $this->dlog('NOEVENT', $raw);
                    return $this->json_ok(array('parsed'=>0));
                }
            }

            $inserted=0; $tbl = db_prefix().'whatsapp_plus_messages';

            foreach ($events as $e) {
                if (!is_array($e)) continue;

                list($ack,$stat) = $this->_map_status($e);
                $waId = $this->_extract_id($e);

                // SADECE durum (delivered/read vs) — POST BACKFILL DAHİL
                if ($stat) {
                    $upd=array('status'=>$stat); $now=date('Y-m-d H:i:s');
                    if ($stat==='delivered') $upd['delivered_at']=$now;
                    if ($stat==='read')      $upd['read_at']=$now;

                    $aff = 0;
                    if ($this->db->table_exists($tbl) && $waId) {
                        // 1) Doğrudan dene
                        $this->db->where('wa_message_id',$waId);
                        $this->_guard_where_for_status($stat);   // <-- MONOTON GUARD
                        $this->db->update($tbl,$upd);
                        $aff = $this->db->affected_rows();

                        // 2) Backfill yoksa son OUT qr:%/NULL mesajı eşle
                        if ($aff===0) {
                            $phoneTry = $this->_extract_remote_phone($e); // çoğu status objesinde yok, opsiyonel
                            $windowSec = 180;

                            $this->db->select('id')->from($tbl)
                                ->where('direction','out')
                                ->where('account_id', (int)$account_id)
                                ->group_start()
                                    ->where("wa_message_id LIKE 'qr:%'", null, false)
                                    ->or_where('wa_message_id IS NULL', null, false)
                                ->group_end()
                                ->where('created_at >=', date('Y-m-d H:i:s', time()-$windowSec))
                                ->order_by('id','DESC')
                                ->limit(1);

                            if ($phoneTry) {
                                $this->db->group_start()
                                    ->where('phone', $phoneTry)
                                    ->or_where('phone_e164', $phoneTry)
                                ->group_end();
                            }

                            $guess = $this->db->get()->row_array();

                            if (!empty($guess['id'])) {
                                $upd2 = $upd;
                                $upd2['wa_message_id'] = $waId;
                                $this->db->where('id', (int)$guess['id']);
                                $this->_guard_where_for_status($stat);   // <-- MONOTON GUARD
                                $this->db->update($tbl, $upd2);
                                $aff = $this->db->affected_rows();
                                $this->dlog('POST-BACKFILL', ['row'=>$guess['id'],'waId'=>$waId,'stat'=>$stat,'phone'=>$phoneTry]);
                            } else {
                                $this->dlog('POST-BACKFILL-MISS', ['waId'=>$waId,'stat'=>$stat,'acc'=>$account_id,'phone'=>$phoneTry]);
                            }
                        }
                    }

                    $this->dlog('STATUS-ONLY', array('waId'=>$waId,'stat'=>$stat,'aff'=>$aff));
                    continue;
                }

                // ---- normal mesaj akışı
                $eHyd = $this->_hydrate_gateway($e);

                $phone  = $this->_extract_remote_phone($eHyd);
                if (!$phone) { $this->dlog('MISS-PHONE',$eHyd); continue; }

                $name   = $this->_extract_name($eHyd);
                $type   = isset($eHyd['type']) ? $eHyd['type'] : (isset($eHyd['message_type']) ? $eHyd['message_type'] : 'text');
                $body   = $this->_body_from_event($eHyd);

                $fromMe = null;
                if (isset($eHyd['isMe'])) $fromMe=(bool)$eHyd['isMe'];
                elseif (isset($eHyd['fromMe'])) $fromMe=(bool)$eHyd['fromMe'];
                elseif (isset($eHyd['key']['fromMe'])) $fromMe=(bool)$eHyd['key']['fromMe'];
                $direction = ($fromMe===true)?'out':(($fromMe===false)?'in':'in');

                // medya balonlarında body yazmayalım
                $isMediaType = in_array($type, array('image','video','audio','document','sticker'), true);
                $bodyForRow  = $isMediaType ? null : $body;

/* ---------- BACKFILL: fromMe echo gerçek WA id taşıyorsa, son X sn’deki qr:% out kaydını düzelt ---------- */
$msg_id = null; $backfilled = false;
if ($direction==='out' && $waId && $this->db->table_exists($tbl)) {

    // ayarlar
    $windowSec = 300;             // 5 dk (istersen 180 yap)
    $phoneTry  = !empty($phone);  // ilk denemede telefon filtresi kullan

    // 1) TELEFONLA dene
    $this->db->select('id')->from($tbl);
    if ($phoneTry) {
        $this->db->group_start()
            ->where('phone', $phone)
            ->or_where('phone_e164', $phone)
        ->group_end();
    }
    $this->db->where('direction','out');
    $this->db->where('account_id', (int)$account_id);
    $this->db->group_start()
        ->where("wa_message_id LIKE 'qr:%'", null, false)
        ->or_where('wa_message_id IS NULL', null, false)
    ->group_end();
    $this->db->where('created_at >=', date('Y-m-d H:i:s', time()-$windowSec));
    $this->db->order_by('id','DESC')->limit(1);

    $guess = $this->db->get()->row_array();

    // 2) BULAMADIYSA: telefonsuz ikinci deneme
    if (empty($guess['id']) && $phoneTry) {
        $this->db->select('id')->from($tbl)
            ->where('direction','out')
            ->where('account_id', (int)$account_id)
            ->group_start()
                ->where("wa_message_id LIKE 'qr:%'", null, false)
                ->or_where('wa_message_id IS NULL', null, false)
            ->group_end()
            ->where('created_at >=', date('Y-m-d H:i:s', time()-$windowSec))
            ->order_by('id','DESC')->limit(1);
        $guess = $this->db->get()->row_array();
    }

    if (!empty($guess['id'])) {
        $upd = array(
            'wa_message_id' => $waId,
            'status'        => 'sent',
            'type'          => $type ? $type : 'text',
        );
        if ($bodyForRow !== null) $upd['body'] = $bodyForRow;

        $this->db->where('id', (int)$guess['id'])->update($tbl, $upd);
        $this->dlog('BACKFILL_WAID', array('row'=>$guess['id'], 'waId'=>$waId));
        $msg_id = (int)$guess['id'];
        $backfilled = true;
    }
}


                // Normal ekleme (backfill olmadıysa)
                if (!$backfilled) {
                    $row = array(
                        'direction'    => $direction,
                        'phone'        => $phone,
                        'contact_name' => $name,
                        'type'         => $type ? $type : 'text',
                        'body'         => $bodyForRow,
                        'status'       => ($direction==='out' ? 'sent' : 'received'),
                        'account_id'   => (int)$account_id,
                        'created_at'   => date('Y-m-d H:i:s'),
                        'wa_message_id'=> $waId ? $waId : null,
                        'meta_json'    => json_encode(array('channel'=>'qr','raw_keys'=>array_keys($eHyd)), JSON_UNESCAPED_UNICODE),
                    );
                    $msg_id = $this->whatsapp_plus_model->log_message($row);
                    if ($direction==='out' && $waId) {
                        $this->dlog('OUT_ECHO_INSERTED', array('row'=>$msg_id,'waId'=>$waId));
                    }
                }

                // Ekleri indir (sadece incoming)
                $atts = array();
                if ($direction==='in') {
                    $a1 = $this->_collect_attachments($eHyd);
                    if (!empty($a1)) $atts = $a1;
                    if (empty($atts) && !empty($eHyd['__uploaded_files'])) $atts = $eHyd['__uploaded_files'];
                }
                if (!empty($atts)) {
                    $atts = array_values(array_filter($atts, function($a){
                        return !empty($a['file_path']) && !empty($a['filename']);
                    }));
                }

                if ($msg_id && !empty($atts) && $this->db->table_exists(db_prefix().'whatsapp_plus_media')) {
                    foreach ($atts as $a) {
                        if ($this->_media_exists($msg_id, isset($a['file_path'])?$a['file_path']:null, isset($a['sha1'])?$a['sha1']:null)) {
                            $this->dlog('MEDIA_DEDUPED', array('message_id'=>$msg_id,'file'=>$a['file_path'],'sha1'=>isset($a['sha1'])?$a['sha1']:null));
                            continue;
                        }
                        $ins = array(
                            'message_id' => (int)$msg_id,
                            'type'       => isset($a['type']) ? $a['type'] : null,
                            'file_path'  => isset($a['file_path']) ? $a['file_path'] : null,
                            'filename'   => isset($a['filename']) ? $a['filename'] : null,
                            'mime'       => isset($a['mime']) ? $a['mime'] : null,
                            'size'       => isset($a['size']) ? $a['size'] : null,
                            'sha1'       => isset($a['sha1']) ? $a['sha1'] : null,
                            'caption'    => isset($a['caption']) ? $a['caption'] : null,
                            'created_at' => isset($a['created_at']) ? $a['created_at'] : date('Y-m-d H:i:s'),
                        );
                        if (empty($ins['file_path'])) {
                            $this->dlog('MEDIA_SKIP_NULL_PATH', array('message_id'=>$msg_id,'filename'=>$ins['filename']));
                            continue;
                        }
                        $this->db->insert(db_prefix().'whatsapp_plus_media', $ins);
                    }
                }

                $inserted++;
            }

            return $this->json_ok(array('inserted_count'=>$inserted,'inserted'=>($inserted>0)));

        } catch (\Throwable $ex) {
            $this->dlog('WEBHOOK_EX', array('msg'=>$ex->getMessage(),'line'=>$ex->getLine(),'file'=>$ex->getFile()));
            // her koşulda 200 dön ki provider yeniden denemesin
            return $this->json_ok(array('ok'=>false,'error'=>'caught'));
        }
    }
}
