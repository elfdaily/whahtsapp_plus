<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Cloud API webhook (Meta/WhatsApp)
 * Version: 3.5.2
 * - Medya indiriliyor ve modules/whatsapp_plus/storage/media/Y/m/ klasörüne kaydediliyor
 * - DB: tblwhatsapp_plus_media.file_path artık NULL kalmıyor
 */
class Webhook extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('whatsapp_plus/whatsapp_plus_model');
        $this->load->database();
        $this->load->helper('whatsapp_plus/whatsapp_plus');
    }

    public function index()
    {
        // GET verify
        if ($this->input->server('REQUEST_METHOD') === 'GET') {
            $mode      = $this->input->get('hub_mode');
            $token     = $this->input->get('hub_verify_token');
            $challenge = $this->input->get('hub_challenge');
            if ($mode === 'subscribe' && $token === (function_exists('get_option') ? get_option('wp_verify_token') : '')) {
                header('Content-Type: text/plain; charset=utf-8');
                echo $challenge;
                return;
            }
            echo 'ok';
            return;
        }

        // Only JSON
        $payload = file_get_contents('php://input');
        $json = json_decode($payload, true);

        if (!$json) {
            $this->_debug(['error'=>'invalid_json','raw'=>$payload]);
            echo json_encode(['status'=>'error']); return;
        }

        $inserted = 0;
        // Typical Cloud structure: entry[0].changes[0].value.messages[]
        if (isset($json['entry']) && is_array($json['entry'])) {
            foreach ($json['entry'] as $entry) {
                if (!isset($entry['changes'])) continue;
                foreach ($entry['changes'] as $change) {
                    $val = isset($change['value']) ? $change['value'] : [];
                    $contacts = isset($val['contacts']) ? $val['contacts'] : [];
                    $msgs = isset($val['messages']) ? $val['messages'] : [];
                    $account_id = 0;
                    if (isset($val['metadata']['phone_number_id'])) {
                        // link to account if exists
                        $acc = $this->whatsapp_plus_model->find_account_by_phone_number_id($val['metadata']['phone_number_id']);
                        if ($acc) $account_id = (int)$acc['id'];
                    }
                    foreach ($msgs as $m) {
                        $from = isset($m['from']) ? $m['from'] : null;
                        $type = isset($m['type']) ? $m['type'] : null;
                        $body = null;
                        $attachments = [];
                        $wa_message_id = isset($m['id']) ? $m['id'] : null;

                        // text
                        if ($type === 'text' && isset($m['text']['body'])) {
                            $body = $m['text']['body'];
                        }

                        // image/document/video/audio/sticker
                        foreach (['image','document','video','audio','sticker'] as $mt) {
                            if ($type === $mt && isset($m[$mt])) {
                                $media = $m[$mt];
                                $media_id = isset($media['id']) ? $media['id'] : null;
                                $caption  = isset($media['caption']) ? $media['caption'] : '';
                                $fnSuggest = isset($media['filename']) ? $media['filename'] : (isset($media['mime_type']) ? $mt : $mt);
                                $saved = $this->_download_media_from_cloud($media_id, $fnSuggest, $account_id);
                                if ($saved) {
                                    list($rel, $abs, $realname, $mime, $size, $sha1) = $saved;
                                    $attachments[] = [
                                        'type'       => $mt,
                                        'media_type' => $mt,
                                        'media_id'   => $media_id,
                                        'file_path'  => $rel,
                                        'filename'   => $realname,
                                        'mime'       => $mime,
                                        'size'       => $size,
                                        'sha1'       => $sha1,
                                        'caption'    => $caption,
                                        'created_at' => date('Y-m-d H:i:s'),
                                    ];
                                    // Also put the filename into body if empty (for easier fallback)
                                    if ($body === null) $body = $realname;
                                } else if (!empty($media_id)) {
                                    // could not download now – still log media_id to debug
                                    $attachments[] = [
                                        'type'       => $mt,
                                        'media_type' => $mt,
                                        'media_id'   => $media_id,
                                        'file_path'  => null,
                                        'filename'   => $fnSuggest,
                                        'mime'       => isset($media['mime_type']) ? $media['mime_type'] : null,
                                        'created_at' => date('Y-m-d H:i:s'),
                                    ];
                                }
                            }
                        }

                        // assemble message row
                        $row = [
                            'account_id'  => $account_id,
                            'direction'   => 'in',
                            'phone'       => $from,
                            'phone_e164'  => $from,
                            'wa_message_id'=> $wa_message_id,
                            'status'      => 'delivered',
                            'body'        => $body,
                            'created_at'  => date('Y-m-d H:i:s'),
                        ];
                        if (!empty($attachments)) $row['__attachments'] = $attachments;
                        $this->whatsapp_plus_model->log_message($row);
                        $inserted++;
                    }
                }
            }
        }

        $this->_debug(['inserted'=>$inserted, 'raw'=>$json]);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['status'=>'ok','inserted'=>$inserted]);
    }

    /*** Helpers ***/

    private function _download_media_from_cloud($media_id, $suggestedName=null, $account_id=0)
    {
        if (!$media_id) return null;
        // Resolve URL via Graph API
        $accessToken = function_exists('get_option') ? get_option('wp_access_token') : '';
        $graphVersion = function_exists('get_option') && get_option('wp_graph_api_version') ? get_option('wp_graph_api_version') : 'v20.0';

        $metaUrl = "https://graph.facebook.com/{$graphVersion}/{$media_id}";
        $ch = curl_init($metaUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);
        $resp = curl_exec($ch);
        $http = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $info = @json_decode($resp, true);
        $url  = isset($info['url']) ? $info['url'] : null;
        $mime = isset($info['mime_type']) ? $info['mime_type'] : null;
        if (!$url) { return null; }

        // Fetch binary with auth
        $tmp = tempnam(sys_get_temp_dir(), 'wp_');
        $ch2 = curl_init($url);
        curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch2, CURLOPT_HTTPHEADER, ['Authorization: Bearer ' . $accessToken]);
        $bin = curl_exec($ch2);
        $http2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
        curl_close($ch2);
        if ($http2 < 200 || $http2 >= 300 || $bin === false) { return null; }
        file_put_contents($tmp, $bin);

        // Prepare storage dir
        $dir = FCPATH.'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/' . (int)$account_id . '/';
        if (!is_dir($dir)) @mkdir($dir, 0775, true);

        $san = $this->_sanitize_filename($suggestedName ?: ('file_'.time()));
        // add extension if missing from suggestedName using mime
        $ext = '';
        if ($mime && strpos($mime,'/')!==false) {
            $ext = explode('/', $mime, 2)[1];
            $ext = str_replace(['jpeg'], ['jpg'], $ext);
            if ($ext) $ext = '.'.$ext;
        }
        if (!preg_match('~\.[a-z0-9]{2,5}$~i', $san) && $ext) $san .= $ext;

        $prefix = time();
        $final = $prefix.'_'.$san;
        $abs = $dir.$final;
        if (!@rename($tmp, $abs)) { @copy($tmp,$abs); @unlink($tmp); }

        $rel = 'modules/whatsapp_plus/storage/media/'.date('Y').'/'.date('m').'/'.(int)$account_id.'/'.$final;
        $size = @filesize($abs);
        $sha1 = @sha1_file($abs);
        $mime2 = function_exists('mime_content_type') ? @mime_content_type($abs) : $mime;
        return [$rel, $abs, $final, $mime2, $size, $sha1];
    }

    private function _sanitize_filename($fn)
    {
        $fn = preg_replace('~[^A-Za-z0-9_\-.]+~', '_', (string)$fn);
        $fn = trim($fn, '_.');
        if ($fn==='') $fn = 'file';
        return $fn;
    }

    private function _debug($data)
    {
        $dir = __DIR__ . '/../storage';
        if(!is_dir($dir)) @mkdir($dir, 0775, true);
        $file = $dir . '/webhook.log';
        @file_put_contents($file, '['.date('c').'] '.(is_string($data)?$data:json_encode($data)).PHP_EOL, FILE_APPEND);
        $this->whatsapp_plus_model->log_line('webhook', 'DEBUG', 'cloud_webhook', is_string($data)?$data:json_encode($data));
    }
}
