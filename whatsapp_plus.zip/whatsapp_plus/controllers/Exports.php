<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Exports extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        if (!is_staff_member()) { access_denied('whatsapp_plus'); }
        if (function_exists('has_permission') && !has_permission('whatsapp_plus','', 'export_toolbar')) { access_denied('whatsapp_plus'); }
        $this->load->database();
        $this->load->helper(array('file','download','path','url','security'));
    }

    /** GET /whatsapp_plus/export/media/{account_id}?from=YYYY-MM-DD&to=YYYY-MM-DD */
    public function media_zip($account_id)
    {
        if ((int)$this->input->get('debug') === 1){
            $from = $this->input->get('from', true);
            $to   = $this->input->get('to', true);
            $this->db->from('tblwhatsapp_plus_media m');
            $this->db->join('tblwhatsapp_plus_messages msg', 'msg.id = m.message_id', 'left');
            $this->db->where('msg.account_id',(int)$account_id);
            if (!empty($from)) $this->db->where('DATE(COALESCE(m.created_at, msg.created_at)) >=',$from);
            if (!empty($to))   $this->db->where('DATE(COALESCE(m.created_at, msg.created_at)) <=',$to);
            $cnt = $this->db->count_all_results();
            header('Content-Type: application/json');
            echo json_encode(['account_id'=>(int)$account_id,'media_count'=>$cnt], JSON_UNESCAPED_UNICODE);
            return;
        }

        $account_id = (int)$account_id;
        if ($account_id <= 0) show_error('Hesap bulunamadı', 404);

        $from = $this->input->get('from', true);
        $to   = $this->input->get('to', true);

        $this->db->select('m.*, msg.created_at AS msg_created_at, COALESCE(m.created_at, msg.created_at) AS ord_ts', false);
        // Use JOIN with messages to ensure account filter even if media table lacks account_id
        $this->db->from('tblwhatsapp_plus_media m');
        $this->db->join('tblwhatsapp_plus_messages msg', 'msg.id = m.message_id', 'left');
        $this->db->where('msg.account_id', $account_id);
        if (!empty($from)) $this->db->where('DATE(COALESCE(m.created_at, msg.created_at)) >=', $from);
        if (!empty($to))   $this->db->where('DATE(COALESCE(m.created_at, msg.created_at)) <=', $to);
        $this->db->order_by('ord_ts', 'ASC');
        $media = $this->db->get()->result_array();

        $files = array();
        foreach($media as $row){
            $p = isset($row['file_path']) ? $row['file_path'] : '';
            // Fallbacks if file_path empty: try to compose from sha1 + filename under storage/media/YYYY/MM
            if (!$p){
                $sha1 = isset($row['sha1']) ? $row['sha1'] : '';
                $fname = isset($row['filename']) ? $row['filename'] : '';
                if ($sha1 && $fname){
                    // search a few recent year/month folders
                    $base = rtrim(FCPATH, '/').'/modules/whatsapp_plus/storage/media/';
                    $candidates = array();
                    // search last 24 months
                    for ($i=0; $i<24; $i++){
                        $ts = strtotime("-$i months");
                        $ym = date('Y/m', $ts);
                        $candidates[] = $base.$ym.'/'.$sha1.'_'.$fname;
                    }
                    foreach ($candidates as $cand){
                        if (is_file($cand)) { $p = str_replace(FCPATH, '', $cand); break; }
                    }
                }
            }
            if (!$p) continue;
            // Normalize path: absolute or relative under FCPATH
            if (strpos($p, FCPATH) === 0) {
                $abs = $p;
            } else {
                $abs = FCPATH . ltrim($p, '/');
            }
            $real = @realpath($abs);
            if ($real && is_file($real) && strpos($real, realpath(FCPATH)) === 0) {
                $files[] = array('abs'=>$real, 'rel'=>ltrim($p,'/'));
            }
        }

        $filename = 'wp_media_acc' . $account_id;
        if ($from || $to) {
            $filename .= '_' . ($from ?: '0000-00-00') . '_to_' . ($to ?: '9999-12-31');
        }
        $filename .= '.zip';

        $tmpzip = tempnam(sys_get_temp_dir(), 'wpzip_');
        $zip = new ZipArchive();
        $zip->open($tmpzip, ZipArchive::OVERWRITE);
        if (empty($files)){
            $zip->addFromString('README.txt', "Seçilen aralıkta medya bulunamadı.");
        } else {
            foreach($files as $f){
                $rel = preg_replace('~^modules/whatsapp_plus/storage/media/~','', $f['rel']);
                $zip->addFile($f['abs'], 'media/' . $rel);
            }
        }
        $zip->close();

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header('Content-Length: ' . filesize($tmpzip));
        readfile($tmpzip);
        @unlink($tmpzip);
        exit;
    }

    /** GET /whatsapp_plus/export/messages/{account_id}/{format}?from=YYYY-MM-DD&to=YYYY-MM-DD */
    public function messages($account_id, $format='csv')
    {
        if ((int)$this->input->get('debug') === 1){
            $from = $this->input->get('from', true);
            $to   = $this->input->get('to', true);
            $this->db->from('tblwhatsapp_plus_messages')->where('account_id',(int)$account_id);
            if (!empty($from)) $this->db->where('DATE(created_at) >=',$from);
            if (!empty($to))   $this->db->where('DATE(created_at) <=',$to);
            $mcnt = $this->db->count_all_results();
            header('Content-Type: application/json');
            echo json_encode(['account_id'=>(int)$account_id,'messages_count'=>$mcnt], JSON_UNESCAPED_UNICODE);
            return;
        }

        $account_id = (int)$account_id;
        $format = strtolower($format);
        if ($account_id <= 0) show_error('Hesap bulunamadı', 404);
        if (!in_array($format, array('csv','xlsx','pdf'))) $format = 'csv';

        $from = $this->input->get('from', true);
        $to   = $this->input->get('to', true);

        // fetch messages
        $this->db->from('tblwhatsapp_plus_messages m');
        $this->db->where('m.account_id', $account_id);
        if (!empty($from)) $this->db->where('DATE(m.created_at) >=', $from);
        if (!empty($to))   $this->db->where('DATE(m.created_at) <=', $to);
        $this->db->order_by('m.created_at', 'ASC');
        $messages = $this->db->get()->result_array();

        $ids = array();
        foreach($messages as $r){ $ids[] = (int)$r['id']; }
        $mediaMap = array();
        if (!empty($ids)){
            $this->db->from('tblwhatsapp_plus_media');
            $this->db->where_in('message_id', $ids);
            $mm = $this->db->get()->result_array();
            foreach($mm as $row){
                $mid = (int)$row['message_id'];
                if (!isset($mediaMap[$mid])) $mediaMap[$mid] = array();
                $mediaMap[$mid][] = $row;
            }
        }

        if ($format === 'csv'){
            $this->_export_csv($account_id, $messages, $mediaMap, $from, $to);
        } elseif ($format === 'xlsx'){
            $this->_export_xlsx($account_id, $messages, $mediaMap, $from, $to);
        } else {
            $this->_export_pdf($account_id, $messages, $mediaMap, $from, $to);
        }
    }

    private function _rows_for_export($messages, $mediaMap){
        $rows = array();
        foreach($messages as $m){
            $mid = (int)$m['id'];
            $medias = isset($mediaMap[$mid]) ? $mediaMap[$mid] : array();
            $mediaNames = array();
            foreach($medias as $md){
                $nm = ($md['type'] ? $md['type'] : 'file') . ':' . ($md['filename'] ? $md['filename'] : basename($md['file_path']));
                $mediaNames[] = $nm;
            }
            $rows[] = array(
                'ID'            => $m['id'],
                'Tarih'         => $m['created_at'],
                'Yön'           => $m['direction'],
                'Telefon'       => $m['phone'],
                'Kişi'          => $m['contact_name'],
                'Tür'           => $m['type'],
                'Mesaj'         => $m['body'],
                'Durum'         => $m['status'],
                'Ekler'         => implode(', ', $mediaNames),
            );
        }
        return $rows;
    }

    private function _export_csv($account_id, $messages, $mediaMap, $from, $to)
    {
        $rows = $this->_rows_for_export($messages, $mediaMap);
        $fn = 'wp_messages_acc'.$account_id;
        if ($from || $to){ $fn .= '_' . ($from ? $from : '0000-00-00') . '_to_' . ($to ? $to : '9999-12-31'); }
        $fn .= '.csv';

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.$fn.'"');
        $out = fopen('php://output', 'w');
        // UTF-8 BOM for Excel
        fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
        if (!empty($rows)){
            fputcsv($out, array_keys($rows[0]), ';');
            foreach($rows as $r){
                fputcsv($out, $r, ';');
            }
        } else {
            fputcsv($out, array('Bilgi'), ';');
            fputcsv($out, array('Kayıt bulunamadı'), ';');
        }
        fclose($out);
        exit;
    }

    private function _export_xlsx($account_id, $messages, $mediaMap, $from, $to)
    {
        $rows = $this->_rows_for_export($messages, $mediaMap);
        $fn = 'wp_messages_acc'.$account_id;
        if ($from || $to){ $fn .= '_' . ($from ? $from : '0000-00-00') . '_to_' . ($to ? $to : '9999-12-31'); }
        $fn .= '.xlsx';

        // Prefer PhpSpreadsheet if available
        if (class_exists('\\PhpOffice\\PhpSpreadsheet\\Spreadsheet')){
            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle('Mesajlar');

            if (!empty($rows)){
                $headers = array_keys($rows[0]);
                $col = 1; foreach($headers as $h){ $sheet->setCellValueByColumnAndRow($col++, 1, $h); }
                $r = 2;
                foreach($rows as $row){
                    $c = 1; foreach($row as $v){ $sheet->setCellValueByColumnAndRow($c++, $r, $v); }
                    $r++;
                }
                for ($i=1; $i<=count($headers); $i++){ $sheet->getColumnDimensionByColumn($i)->setAutoSize(true); }
            } else {
                $sheet->setCellValue('A1','Kayıt bulunamadı');
            }

            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="'.$fn.'"');
            $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
            $writer->save('php://output');
            exit;
        }

        // Fallback: Excel 2003 XML (Excel açar)
        $headers = !empty($rows) ? array_keys($rows[0]) : array('Bilgi');
        $xml  = '<?xml version="1.0"?>';
        $xml .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" ';
        $xml .= 'xmlns:o="urn:schemas-microsoft-com:office:office" ';
        $xml .= 'xmlns:x="urn:schemas-microsoft-com:office:excel" ';
        $xml .= 'xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">';
        $xml .= '<Worksheet ss:Name="Mesajlar"><Table>';

        // headers
        $xml .= '<Row>';
        foreach($headers as $h){
            $xml .= '<Cell><Data ss:Type="String">'.htmlspecialchars($h).'</Data></Cell>';
        }
        $xml .= '</Row>';

        if (!empty($rows)){
            foreach($rows as $row){
                $xml .= '<Row>';
                foreach($row as $v){
                    $v = is_null($v) ? '' : (string)$v;
                    $xml .= '<Cell><Data ss:Type="String">'.htmlspecialchars($v).'</Data></Cell>';
                }
                $xml .= '</Row>';
            }
        } else {
            $xml .= '<Row><Cell><Data ss:Type="String">Kayıt bulunamadı</Data></Cell></Row>';
        }

        $xml .= '</Table></Worksheet></Workbook>';

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="'.$fn.'"');
        echo $xml;
        exit;
    }

    private function _export_pdf($account_id, $messages, $mediaMap, $from, $to)
    {
        $title = 'Whatsapp Mesajları - Hesap #'.$account_id;
        $period = ($from || $to) ? (' ('.($from ? $from : 'başlangıç').' — '.($to ? $to : 'bugün').')') : '';
        $css = '<style>
            body { font-family: DejaVu Sans, Arial, Helvetica, sans-serif; font-size: 12px; color: #111; }
            .header{ text-align:center; margin-bottom:14px; }
            .chip{ display:inline-block; padding:6px 10px; border-radius:999px; background:#eef2ff; color:#3730a3; font-weight:bold; }
            .chat{ width:100%; }
            .row{ margin:8px 0; clear:both; }
            .msg{ max-width: 75%; padding:10px 12px; border-radius:12px; position: relative; }
            .in { background:#f3f4f6; float:left; border-top-left-radius:2px; }
            .out{ background:#dcfce7; float:right; border-top-right-radius:2px; }
            .meta{ font-size:10px; color:#6b7280; margin-top:4px; }
            .sender{ font-weight:bold; margin-bottom:4px; }
            .attach{ font-size:11px; color:#1f2937; margin-top:6px; }
            .clearfix{ clear:both; }
        </style>';

        $html = '<html><head><meta charset="utf-8">'.$css.'</head><body>';
        $html .= '<div class="header"><div class="chip">'.$title.$period.'</div></div>';
        $html .= '<div class="chat">';
        foreach($messages as $m){
            $dir = ($m['direction']==='out') ? 'out' : 'in';
            $sender = ($m['direction']==='out') ? 'Siz' : ($m['contact_name'] ? $m['contact_name'] : $m['phone']);
            $body = $m['body'] ? nl2br(htmlspecialchars($m['body'])) : '';
            $dt = $m['created_at'];

            $html .= '<div class="row">';
            $html .= '<div class="msg '.$dir.'">';
            $html .= '<div class="sender">'.htmlspecialchars($sender).'</div>';
            if ($body !== ''){
                $html .= '<div class="text">'.$body.'</div>';
            }
            $mid = (int)$m['id'];
            if (!empty($mediaMap[$mid])){
                foreach($mediaMap[$mid] as $md){
                    $fn = $md['filename'] ? $md['filename'] : basename($md['file_path']);
                    $html .= '<div class="attach">📎 '.htmlspecialchars($md['type']).' — '.htmlspecialchars($fn).'</div>';
                }
            }
            $html .= '<div class="meta">'.htmlspecialchars($dt).' • '.($m['status'] ? htmlspecialchars($m['status']) : '').'</div>';
            $html .= '</div><div class="clearfix"></div></div>';
        }
        $html .= '</div></body></html>';

        $fn = 'wp_messages_acc'.$account_id;
        if ($from || $to){ $fn .= '_' . ($from ? $from : '0000-00-00') . '_to_' . ($to ? $to : '9999-12-31'); }
        $fn .= '.pdf';

        if (class_exists('\Dompdf\Dompdf')){
            $dompdf = new \Dompdf\Dompdf(array('isRemoteEnabled' => true));
            $dompdf->loadHtml($html, 'UTF-8');
            $dompdf->setPaper('A4', 'portrait');
            $dompdf->render();
            $dompdf->stream($fn, array('Attachment' => true));
            exit;
        }
        if (class_exists('TCPDF')){
            $pdf = new TCPDF('P', PDF_UNIT, 'A4', true, 'UTF-8', false);
            $pdf->SetCreator(PDF_CREATOR);
            $pdf->SetAuthor('Whatsapp Plus');
            $pdf->SetTitle($title);
            $pdf->SetMargins(10,10,10,true);
            $pdf->AddPage();
            $pdf->writeHTML($html, true, false, true, false, '');
            $pdf->Output($fn, 'D');
            exit;
        }

        // Fallback: HTML
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.str_replace('.pdf','.html',$fn).'"');
        echo $html;
        exit;
    }
}
