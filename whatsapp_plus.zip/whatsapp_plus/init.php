<?php
defined('BASEPATH') or exit('No direct script access allowed');


// === WhatsApp Plus: staff permissions ===
// Register permission group so it appears under Staff -> Permissions
hooks()->add_filter('staff_permissions', function($permissions){
    $capabilities = array();
    // Standard capabilities (keep compatibility with existing checks)
    $capabilities['view']      = _l('permission_view');       // Mesajları görüntüleme
    $capabilities['create']    = _l('permission_create');
    $capabilities['edit']      = _l('permission_edit');
    $capabilities['delete']    = _l('permission_delete');
    // Custom capabilities
    $capabilities['export_toolbar'] = 'Mesaj Dışa Aktarım Araç Çubuğu';
    $capabilities['view_logs']      = 'Logları Görüntüle';
    $capabilities['view_settings']  = 'Ayarları Görüntüle';

    $permissions['whatsapp_plus'] = array(
        'name' => 'WhatsApp Plus',
        'capabilities' => $capabilities
    );
    return $permissions;
});

// Helper to check current staff capability
if (!function_exists('wp_staff_can')){
    function wp_staff_can($cap){
        return function_exists('has_permission') ? has_permission('whatsapp_plus', '', $cap) : false;
    }
}


// === Export toolbar assets ===
// Also enqueue in footer for reliability (DOM ready, admin_url defined)
hooks()->add_action('app_admin_footer', function(){
    if (function_exists('has_permission') && has_permission('whatsapp_plus','', 'export_toolbar')) { echo '<script src="' . module_dir_url('whatsapp_plus','assets/js/wp_exports.js') . '?v=342"></script>'; }
});

// Export toolbar assets (head + footer)
hooks()->add_action('app_admin_head', function(){
    if (function_exists('has_permission') && has_permission('whatsapp_plus','', 'export_toolbar')) { echo '<script src="' . module_dir_url('whatsapp_plus','assets/js/wp_exports.js') . '?v=343"></script>'; }
});
hooks()->add_action('app_admin_footer', function(){
    if (function_exists('has_permission') && has_permission('whatsapp_plus','', 'export_toolbar')) { echo '<script src="' . module_dir_url('whatsapp_plus','assets/js/wp_exports.js') . '?v=343"></script>'; }
});

