<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['csrf_exclude_uris'] = [
    // QR (wa-lazy)
    'whatsapp_plus/qr_webhook',
    'index.php/whatsapp_plus/qr_webhook',

    // Cloud API
    'whatsapp_plus/webhook',
    'index.php/whatsapp_plus/webhook'
];
