<?php
defined('BASEPATH') or exit('No direct script access allowed');

// Whatsapp Plus Exports
$route['whatsapp_plus/export/media/(:num)']           = 'whatsapp_plus/Exports/media_zip/$1';
$route['whatsapp_plus/export/messages/(:num)/(:any)'] = 'whatsapp_plus/Exports/messages/$1/$2';


$route['whatsapp_plus/exports/media_zip/(:num)'] = 'whatsapp_plus/Exports/media_zip/$1';
$route['whatsapp_plus/exports/messages/(:num)/(:any)'] = 'whatsapp_plus/Exports/messages/$1/$2';

$route['whatsapp_plus/account_save']      = 'whatsapp_plus/Whatsapp_plus/account_save';
$route['whatsapp_plus/account_delete/(:num)'] = 'whatsapp_plus/Whatsapp_plus/account_delete/$1';
