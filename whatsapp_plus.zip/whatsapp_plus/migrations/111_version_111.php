<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * No-op migration to align DB with module Version 1.1.1
 */
class Migration_Version_111 extends App_module_migration
{
    public function up()
    {
        // Nothing to change. This migration only bumps the installed version.
        // You can add schema changes here later if needed.
    }
}
