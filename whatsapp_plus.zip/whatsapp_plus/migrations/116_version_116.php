<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_116 extends CI_Migration {
    public function up() {
        $prefix = db_prefix();
        if ($this->db->table_exists($prefix.'whatsapp_plus_contacts')) {
            $fields = $this->db->list_fields($prefix.'whatsapp_plus_contacts');
            if (!in_array('last_open_at', $fields, true)) {
                $this->db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD COLUMN `last_open_at` DATETIME NULL AFTER `updated_at`");
            }
        }
    }
    public function down(){ /* no-op */ }
}
