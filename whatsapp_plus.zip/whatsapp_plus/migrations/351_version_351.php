<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_351 extends CI_Migration
{
    public function up()
    {
        $tbl = db_prefix().'whatsapp_plus_messages';
        if ($this->db->table_exists($tbl)) {
            // Indexes helpful for account/thread queries
            $this->db->query("CREATE INDEX IF NOT EXISTS idx_wp_msg_acc_chat_time ON {$tbl} (account_id, phone_e164, created_at)");
            $this->db->query("CREATE INDEX IF NOT EXISTS idx_wp_msg_acc_dir ON {$tbl} (account_id, direction)");
            // Opportunistic backfill: if meta_json contains '"fromMe":true' then mark as out (only when currently 'in')
            if ($this->db->field_exists('meta_json', $tbl)) {
                $this->db->query("UPDATE {$tbl} SET direction='out' WHERE direction='in' AND meta_json LIKE '%"fromMe":true%'");
            }
        }
    }

    public function down(){}
}
