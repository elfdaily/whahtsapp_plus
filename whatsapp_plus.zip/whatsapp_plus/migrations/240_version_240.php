<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_240 extends CI_Migration
{
    public function up()
    {
        $this->ensure_option('wp_qr_enabled','0');
        $this->ensure_option('wp_cloud_enabled','0');
        $this->ensure_option('wp_channel','qr');
        $this->ensure_option('wp_active_provider','qr');
        $this->dedupe('wp_qr_enabled');
        $this->dedupe('wp_cloud_enabled');
        $this->dedupe('wp_channel');
        $this->dedupe('wp_active_provider');
    }

    public function down(){}

    private function ensure_option($name,$default){
        if (!$this->db->table_exists(db_prefix().'options')) return;
        $row = $this->db->where('name',$name)->get(db_prefix().'options')->row();
        if (!$row){
            $this->db->insert(db_prefix().'options', [
                'name' => $name,
                'value'=> $default,
                'autoload' => 1
            ]);
        }
    }

    private function dedupe($name){
        if (!$this->db->table_exists(db_prefix().'options')) return;
        $rows = $this->db->where('name',$name)->order_by('id','ASC')->get(db_prefix().'options')->result_array();
        if (count($rows) <= 1) return;
        $keepId = $rows[0]['id'];
        foreach ($rows as $i=>$row){
            if ($row['id'] != $keepId){
                $this->db->where('id',$row['id'])->delete(db_prefix().'options');
            }
        }
    }
}
