<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_200 extends CI_Migration
{
    public function up()
    {
        // Ensure logs table exists by reusing installer (idempotent)
        if (function_exists('whatsapp_plus_install')) { whatsapp_plus_install(); }

        // Ensure options created
        $this->add_option('wp_qr_enabled','0');
        $this->add_option('wp_qr_api_url','');
        $this->add_option('wp_qr_api_key','');
        $this->add_option('wp_qr_device','');
        $this->add_option('wp_qr_send_text_path','/api/send-text');
        $this->add_option('wp_qr_send_media_path','/api/send-media');
    }

    public function down()
    {
        // keep options
    }

    private function add_option($name, $value)
    {
        if (!$this->db->table_exists(db_prefix().'options')) return;
        $exists = $this->db->where('name',$name)->get(db_prefix().'options')->row();
        if (!$exists) {
            $this->db->insert(db_prefix().'options', ['name'=>$name,'value'=>$value,'autoload'=>1]);
        }
    }
}
