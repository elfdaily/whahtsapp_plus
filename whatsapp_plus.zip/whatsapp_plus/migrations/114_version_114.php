<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_114 extends CI_Migration {
    public function up() {
        $prefix = db_prefix();
        // Normalize messages.phone_e164 to always start with +
        if ($this->db->table_exists($prefix.'whatsapp_plus_messages')) {
            $rows = $this->db->get($prefix.'whatsapp_plus_messages')->result_array();
            foreach ($rows as $r) {
                $p = isset($r['phone_e164']) ? $r['phone_e164'] : $r['phone'];
                if (!function_exists('wp_normalize_phone')) {
                    $p = '+' . preg_replace('/\D+/', '', (string)$p);
                } else {
                    $p = wp_normalize_phone($p);
                }
                $this->db->where('id', $r['id'])->update($prefix.'whatsapp_plus_messages', ['phone_e164' => $p]);
            }
        }
        // Normalize contacts
        if ($this->db->table_exists($prefix.'whatsapp_plus_contacts')) {
            $rows = $this->db->get($prefix.'whatsapp_plus_contacts')->result_array();
            foreach ($rows as $r) {
                $p = isset($r['phone_e164']) ? $r['phone_e164'] : '';
                if (!function_exists('wp_normalize_phone')) {
                    $p = '+' . preg_replace('/\D+/', '', (string)$p);
                } else {
                    $p = wp_normalize_phone($p);
                }
                $this->db->where('id', $r['id'])->update($prefix.'whatsapp_plus_contacts', ['phone_e164' => $p]);
            }
            // Unique index (silently ignore if exists)
            try { $this->db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD UNIQUE KEY `uniq_phone` (`phone_e164`)"); } catch (Exception $e) {}
        }
    }
    public function down(){ /* no-op */ }
}
