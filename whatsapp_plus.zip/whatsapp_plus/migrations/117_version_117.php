<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_117 extends CI_Migration {
    public function up() {
        $prefix = db_prefix();

        if ($this->db->table_exists($prefix.'whatsapp_plus_contacts')) {
            $fields = $this->db->list_fields($prefix.'whatsapp_plus_contacts');
            if (!in_array('last_open_at', $fields, true)) {
                $this->db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD COLUMN `last_open_at` DATETIME NULL AFTER `updated_at`");
            }
            // Backfill contact names from latest messages.contact_name when empty
            if ($this->db->table_exists($prefix.'whatsapp_plus_messages')) {
                $contacts = $this->db->get($prefix.'whatsapp_plus_contacts')->result_array();
                foreach ($contacts as $c) {
                    if (empty($c['name'])) {
                        $this->db->order_by('id','DESC');
                        $this->db->limit(1);
                        $row = $this->db->where('phone_e164', $c['phone_e164'])->get($prefix.'whatsapp_plus_messages')->row_array();
                        if ($row && !empty($row['contact_name'])) {
                            $this->db->where('id', $c['id'])->update($prefix.'whatsapp_plus_contacts', ['name'=>$row['contact_name']]);
                        }
                    }
                }
            }
        }
    }
    public function down(){ /* no-op */ }
}
