<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_203 extends CI_Migration
{
    public function up()
    {
        $this->add_option('wp_cloud_enabled','1');
        $this->add_option('wp_qr_enabled','0');
    }

    public function down(){}

    private function add_option($name,$value){
        if (!$this->db->table_exists(db_prefix().'options')) return;
        $row = $this->db->where('name',$name)->get(db_prefix().'options')->row();
        if (!$row){ $this->db->insert(db_prefix().'options',['name'=>$name,'value'=>$value,'autoload'=>1]); }
    }
}
