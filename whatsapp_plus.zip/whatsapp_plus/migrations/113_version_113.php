<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_113 extends CI_Migration {
    public function up() {
        $prefix = db_prefix();
        if ($this->db->table_exists($prefix.'whatsapp_plus_messages')) {
            $fields = $this->db->list_fields($prefix.'whatsapp_plus_messages');
            if (!in_array('contact_name', $fields, true)) {
                $this->db->query("ALTER TABLE `{$prefix}whatsapp_plus_messages` ADD COLUMN `contact_name` VARCHAR(191) NULL AFTER `phone_e164`");
            }
        }
    }
    public function down() { /* no-op */ }
}
