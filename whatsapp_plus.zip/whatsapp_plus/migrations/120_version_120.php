<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Migration_Version_120 extends CI_Migration {
    public function up() {
        // Perfex options
        if (!function_exists('add_option')) {
            function add_option($name,$value){ if(get_option($name)===false){ update_option($name,$value); } }
        }
        add_option('wp_realtime_mode', 'sse');
        add_option('wp_poll_interval_sec', '3');
    }
    public function down(){ /* no-op */ }
}
