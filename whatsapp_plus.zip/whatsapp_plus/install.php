<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Idempotent installer – tablo yoksa oluşturur; eksik sütunları ekler.
 * DB silindiğinde admin panel her açıldığında tekrar çalışır.
 */
function whatsapp_plus_install()
{
    $CI = &get_instance();
    $db = $CI->db;
    $prefix = db_prefix();

    // Logs
    if (!$db->table_exists($prefix . 'whatsapp_plus_logs')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_logs` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `source` VARCHAR(32) NOT NULL,      -- tools | webhook | system
            `tag` VARCHAR(32) NULL,             -- INFO | PAYLOAD | RESP | etc
            `text` TEXT NULL,
            `meta_json` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX (`created_at`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_logs');
        $ensure = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_logs` ADD COLUMN {$sql}");
            }
        };
        $ensure('meta_json', " `meta_json` MEDIUMTEXT NULL AFTER `text`");
    }

    // Contacts
    if (!$db->table_exists($prefix . 'whatsapp_plus_contacts')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_contacts` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `phone_e164` VARCHAR(32) NOT NULL,
            `name` VARCHAR(191) NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NULL,
            `last_open_at` DATETIME NULL,
            UNIQUE KEY `uniq_phone` (`phone_e164`),
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_contacts');
        $ensureC = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD COLUMN {$sql}");
            }
        };
        $ensureC('name', " `name` VARCHAR(191) NULL AFTER `phone_e164`");
        $ensureC('updated_at', " `updated_at` DATETIME NULL,
            `last_open_at` DATETIME NULL AFTER `created_at`");
        try { $db->query("ALTER TABLE `{$prefix}whatsapp_plus_contacts` ADD UNIQUE KEY `uniq_phone` (`phone_e164`)"); } catch (Exception $e) {}
    }

    // Accounts
    if (!$db->table_exists($prefix . 'whatsapp_plus_accounts')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_accounts` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(191) NOT NULL DEFAULT 'default',
            `waba_id` VARCHAR(191) NULL,
            `phone_number_id` VARCHAR(191) NULL,
            `access_token` TEXT NULL,
            `verify_token` VARCHAR(191) NULL,
            `status` TINYINT(1) NOT NULL DEFAULT 1,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    }

    
    else {
        // Add missing columns for wa-lazy/QR accounts (v3.3.4)
        $fields = $db->list_fields($prefix . 'whatsapp_plus_accounts');
        $ensureA = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                try { $db->query("ALTER TABLE `{$prefix}whatsapp_plus_accounts` ADD COLUMN {$sql}"); } catch (Exception $e) {}
            }
        };
        $ensureA('label', " `label` VARCHAR(191) NULL AFTER `name`");
        $ensureA('provider', " `provider` VARCHAR(32) NULL DEFAULT 'qr' AFTER `label`");
        $ensureA('qr_api_url', " `qr_api_url` VARCHAR(255) NULL AFTER `provider`");
        $ensureA('qr_api_key', " `qr_api_key` VARCHAR(255) NULL AFTER `qr_api_url`");
        $ensureA('qr_device', " `qr_device` VARCHAR(191) NULL AFTER `qr_api_key`");
        $ensureA('qr_payload_mode', " `qr_payload_mode` VARCHAR(16) NULL DEFAULT 'form' AFTER `qr_device`");
        $ensureA('qr_send_text_path', " `qr_send_text_path` VARCHAR(191) NULL DEFAULT '/api/send-text' AFTER `qr_payload_mode`");
        $ensureA('qr_send_media_path', " `qr_send_media_path` VARCHAR(191) NULL DEFAULT '/api/send-media' AFTER `qr_send_text_path`");
        $ensureA('webhook_token', " `webhook_token` VARCHAR(191) NULL AFTER `qr_send_media_path`");
        $ensureA('is_default', " `is_default` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`");
        $ensureA('updated_at', " `updated_at` DATETIME NULL AFTER `created_at`");
    }
// Messages
    if (!$db->table_exists($prefix . 'whatsapp_plus_messages')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_messages` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `account_id` INT UNSIGNED NOT NULL DEFAULT 0,
            `direction` ENUM('in','out') NOT NULL,
            `phone` VARCHAR(32) NOT NULL,
            `phone_e164` VARCHAR(32) NULL,
            `contact_name` VARCHAR(191) NULL,
            `type` VARCHAR(32) NOT NULL DEFAULT 'text',
            `body` MEDIUMTEXT NULL,
            `wa_message_id` VARCHAR(128) NULL,
            `status` VARCHAR(32) NULL,              -- sent, delivered, read, error, received
            `error` TEXT NULL,
            `meta_json` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            `received_at` DATETIME NULL,
            `sent_at` DATETIME NULL,
            `delivered_at` DATETIME NULL,
            `read_at` DATETIME NULL,
            PRIMARY KEY (`id`),
            INDEX (`phone`), INDEX(`phone_e164`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } else {
        // Eksik kolonları ekle
        $fields = $db->list_fields($prefix . 'whatsapp_plus_messages');
        $ensure = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_messages` ADD COLUMN {$sql}");
            }
        };

        $ensure('account_id',  " `account_id` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `id`");
        $ensure('direction',   " `direction` ENUM('in','out') NOT NULL DEFAULT 'out' AFTER `account_id`");
        $ensure('phone',       " `phone` VARCHAR(32) NULL AFTER `direction`");
        $ensure('phone_e164',  " `phone_e164` VARCHAR(32) NULL AFTER `phone`");
        $ensure('contact_name'," `contact_name` VARCHAR(191) NULL AFTER `phone_e164`");
        $ensure('type',        " `type` VARCHAR(32) NULL DEFAULT 'text' AFTER `contact_name`");
        $ensure('body',        " `body` MEDIUMTEXT NULL AFTER `type`");
        $ensure('wa_message_id', " `wa_message_id` VARCHAR(128) NULL AFTER `body`");
        $ensure('status',       " `status` VARCHAR(32) NULL AFTER `wa_message_id`");
        $ensure('error',        " `error` TEXT NULL AFTER `status`");
        $ensure('meta_json',    " `meta_json` MEDIUMTEXT NULL AFTER `error`");
        $ensure('provider',     " `provider` VARCHAR(16) NULL DEFAULT 'qr' AFTER `meta_json`");
        $ensure('created_at',   " `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP AFTER `meta_json`");
        $ensure('sent_at',      " `sent_at` DATETIME NULL AFTER `created_at`");
        $ensure('received_at',  " `received_at` DATETIME NULL AFTER `created_at`");
        $ensure('delivered_at', " `delivered_at` DATETIME NULL AFTER `sent_at`");
        $ensure('read_at',      " `read_at` DATETIME NULL AFTER `delivered_at`");
        $ensure('is_important', " `is_important` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`");

        // Migrate legacy `message` column into `body` if present
        $fields_now = $db->list_fields($prefix . 'whatsapp_plus_messages');
        if (in_array('message', $fields_now, true) && !in_array('body', $fields_now, true)) {
            try { $db->query("ALTER TABLE `{$prefix}whatsapp_plus_messages` ADD COLUMN `body` MEDIUMTEXT NULL"); } catch (Exception $e) {}
            try { $db->query("UPDATE `{$prefix}whatsapp_plus_messages` SET `body` = `message` WHERE (`body` IS NULL OR `body` = '') AND `message` IS NOT NULL"); } catch (Exception $e) {}
        }

    }

    
    // Media table (stores files associated with messages)
    if (!$db->table_exists($prefix . 'whatsapp_plus_media')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_media` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `message_id` BIGINT UNSIGNED NULL,
            `type` VARCHAR(32) NOT NULL,
            `media_id` VARCHAR(191) NULL,
            `file_path` VARCHAR(512) NULL,
            `filename` VARCHAR(191) NULL,
            `mime` VARCHAR(128) NULL,
            `size` BIGINT NULL,
            `sha1` CHAR(40) NULL,
            `caption` TEXT NULL,
            `meta_json` MEDIUMTEXT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            INDEX (`message_id`),
            INDEX (`type`),
            INDEX (`sha1`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    }


    else {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_media');
        $ensureM = function($name, $sql) use ($fields, $db, $prefix) {
            if (!in_array($name, $fields, true)) {
                $db->query("ALTER TABLE `{$prefix}whatsapp_plus_media` ADD COLUMN {$sql}");
            }
        };
        $ensureM('media_id',  " `media_id` VARCHAR(191) NULL AFTER `type`");
        $ensureM('filename',  " `filename` VARCHAR(191) NULL AFTER `file_path`");
        $ensureM('size',      " `size` BIGINT NULL AFTER `mime`");
        $ensureM('sha1',      " `sha1` CHAR(40) NULL AFTER `size`");
        $ensureM('caption',   " `caption` TEXT NULL AFTER `sha1`");
        $ensureM('meta_json', " `meta_json` MEDIUMTEXT NULL AFTER `caption`");
    }


    // Ayarlar (Perfex options)
    add_option('wp_access_token',   get_option('wp_access_token') ?: '');
    add_option('wp_waba_id',        get_option('wp_waba_id') ?: '');
    add_option('wp_phone_number_id',get_option('wp_phone_number_id') ?: '');
    add_option('wp_verify_token',   get_option('wp_verify_token') ?: '');

    // Important threads table
    if (!$db->table_exists($prefix . 'whatsapp_plus_important_threads')) {
        $db->query('CREATE TABLE `' . $prefix . "whatsapp_plus_important_threads` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `phone_e164` VARCHAR(32) NOT NULL,
            `created_at` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_phone` (`phone_e164`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    }

    // Ensure is_important column on messages
    if ($db->table_exists($prefix . 'whatsapp_plus_messages')) {
        $fields = $db->list_fields($prefix . 'whatsapp_plus_messages');
        if (!in_array('is_important', $fields, true)) {
            $db->query("ALTER TABLE `{$prefix}whatsapp_plus_messages` ADD COLUMN `is_important` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`");
        }
    }
    }

function whatsapp_plus_uninstall()
{
    delete_option('wp_access_token');
    delete_option('wp_waba_id');
    delete_option('wp_phone_number_id');
    delete_option('wp_verify_token');
}
